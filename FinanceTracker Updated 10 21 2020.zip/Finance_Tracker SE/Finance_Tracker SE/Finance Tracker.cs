﻿/***

Program:  Finance Tracker

Purpose: To allow Business to keep Track of there Expensices,Sales and profit 

Author:  Tyler Scott, Aaliyah Ortiz, Steven Renfree

Date: October 12,2020

*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
 
            
        }

        private void Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Page_Click(object sender, EventArgs e)
        {
            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
        }

        private void DataInput_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = true;
            Data.Visible = false;
        }

        private void DataPage_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = true;
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = true;
            InputData.Visible = false;
            Data.Visible = false;

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Graph_Page_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void FinancePanel_Paint(object sender, PaintEventArgs e)
        {
            
        }


        private void Item_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Input_Click_1(object sender, EventArgs e)
        {
        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void InputData_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Input_Click(object sender, EventArgs e)
        {
            //Clears the error labels
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
            spMark.Text = "";
            amMark.Text = "";
            asMark.Text = "";
            msMark.Text = "";
            ysMark.Text = "";
            dataAdded.Text = "";

            //Checks inputs
            if (ItemId.Text.Length <= 0)
            {
                ItemId.Text = "";
                idMark.Text = "* Item ID: Is Required";
            }
            if ((Item_Name.Text.Length >= 31) || (Item_Name.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemName length plz input item name with 30 chars or less";
                Item_Name.Text = "";
            }

            if (Cost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost: Is Required";
                Cost.Text = "";
            }

            if (Selling_Price.Text.Length <= 0)
            {
                spMark.Text = "* Selling Price: Is Required";
                Selling_Price.Text = "";
            }

            if (Amount_Sold.Text.Length <= 0)
            {
                asMark.Text = "* Amount Sold: Is Required";
                Amount_Sold.Text = "";
            }

            if (Amount_Made.Text.Length <= 0)
            {
                amMark.Text = "* Amount Made: Is Required";
                Amount_Made.Text = "";
            }

            if (Month.Text.Length <= 0 || Month.Text.Length >= 31 || Convert.ToInt32(Month.Text) >= 13 || Convert.ToInt32(Month.Text) <= 0)
            {
                msMark.Text = "* Month: Input Range between 0 and 30 in length or a number between 1 and 12";
                Cost.Text = "";
            }

            if (Year.Text.Length <= 0)
            {
                ysMark.Text = "* Year: Is Required";
                Selling_Price.Text = "";
            }
            else 
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=User; password = Password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into item(document,id,name,costToMake,sellingPrice,AmountSold,AmountMade,Month,Year) Values('" +"0" + "','" + Item_Id.Text + "','" + Item_Name.Text + "','" + Convert.ToDouble(Cost.Text) + "','" + Convert.ToDouble(Selling_Price.Text) + "','" + Amount_Sold.Text + "','" + Amount_Made.Text + "','" + Month.Text + "','" + Year.Text + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                dataAdded.Text = "Data has been Inputed";
                con.Close();

            }
        }
    }

}
