﻿namespace Software_Engineering_Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.Side1 = new System.Windows.Forms.Panel();
            this.Profile = new System.Windows.Forms.Button();
            this.DataPage = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Graph = new System.Windows.Forms.Button();
            this.DataInput = new System.Windows.Forms.Button();
            this.Home_Page = new System.Windows.Forms.Button();
            this.FinancePanel = new System.Windows.Forms.Panel();
            this.FinanceTracker = new System.Windows.Forms.Label();
            this.HomePage = new System.Windows.Forms.Panel();
            this.HomePg = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.Panel();
            this.Searchlabel = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costToMakeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellingPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountSoldDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountMadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.monthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet = new Finance_Tracker_SE.finance_trackerDataSet();
            this.Data_Search = new System.Windows.Forms.Label();
            this.InputData = new System.Windows.Forms.Panel();
            this.dataAdded = new System.Windows.Forms.Label();
            this.ysMark = new System.Windows.Forms.Label();
            this.msMark = new System.Windows.Forms.Label();
            this.asMark = new System.Windows.Forms.Label();
            this.amMark = new System.Windows.Forms.Label();
            this.spMark = new System.Windows.Forms.Label();
            this.ictmMark = new System.Windows.Forms.Label();
            this.inMark = new System.Windows.Forms.Label();
            this.idMark = new System.Windows.Forms.Label();
            this.MonthSold = new System.Windows.Forms.Label();
            this.YearSold = new System.Windows.Forms.Label();
            this.AmountSold = new System.Windows.Forms.Label();
            this.AmountMade = new System.Windows.Forms.Label();
            this.SoldPrice = new System.Windows.Forms.Label();
            this.CostItem = new System.Windows.Forms.Label();
            this.ItemName = new System.Windows.Forms.Label();
            this.ItemId = new System.Windows.Forms.Label();
            this.Amount_Made = new System.Windows.Forms.TextBox();
            this.Input = new System.Windows.Forms.Button();
            this.Year = new System.Windows.Forms.TextBox();
            this.Month = new System.Windows.Forms.TextBox();
            this.Selling_Price = new System.Windows.Forms.TextBox();
            this.Amount_Sold = new System.Windows.Forms.TextBox();
            this.Cost = new System.Windows.Forms.TextBox();
            this.Item_Name = new System.Windows.Forms.TextBox();
            this.Item_Id = new System.Windows.Forms.TextBox();
            this.Input_Page = new System.Windows.Forms.Label();
            this.itemTableAdapter = new Finance_Tracker_SE.finance_trackerDataSetTableAdapters.itemTableAdapter();
            this.Profile_Page = new System.Windows.Forms.Panel();
            this.Profilelab = new System.Windows.Forms.Label();
            this.Part_Input = new System.Windows.Forms.Panel();
            this.edit_Part = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Part_Amount = new System.Windows.Forms.Label();
            this.Part_Name = new System.Windows.Forms.Label();
            this.ProductId = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.Parts_input_page = new System.Windows.Forms.Label();
            this.Graph_Page = new System.Windows.Forms.Panel();
            this.Graphpg = new System.Windows.Forms.Label();
            this.GraphData = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Monthly_Data = new System.Windows.Forms.Button();
            this.Yearly_Data = new System.Windows.Forms.Button();
            this.Side1.SuspendLayout();
            this.FinancePanel.SuspendLayout();
            this.HomePage.SuspendLayout();
            this.Data.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet)).BeginInit();
            this.InputData.SuspendLayout();
            this.Profile_Page.SuspendLayout();
            this.Part_Input.SuspendLayout();
            this.Graph_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GraphData)).BeginInit();
            this.SuspendLayout();
            // 
            // Side1
            // 
            this.Side1.BackColor = System.Drawing.Color.Transparent;
            this.Side1.Controls.Add(this.Profile);
            this.Side1.Controls.Add(this.DataPage);
            this.Side1.Controls.Add(this.Exit);
            this.Side1.Controls.Add(this.Graph);
            this.Side1.Controls.Add(this.DataInput);
            this.Side1.Controls.Add(this.Home_Page);
            this.Side1.Controls.Add(this.FinancePanel);
            this.Side1.Location = new System.Drawing.Point(0, 0);
            this.Side1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Side1.Name = "Side1";
            this.Side1.Size = new System.Drawing.Size(199, 773);
            this.Side1.TabIndex = 1;
            // 
            // Profile
            // 
            this.Profile.BackColor = System.Drawing.Color.Transparent;
            this.Profile.FlatAppearance.BorderSize = 0;
            this.Profile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Profile.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Profile.ForeColor = System.Drawing.Color.White;
            this.Profile.Image = ((System.Drawing.Image)(resources.GetObject("Profile.Image")));
            this.Profile.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Profile.Location = new System.Drawing.Point(-2, 177);
            this.Profile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Profile.Name = "Profile";
            this.Profile.Size = new System.Drawing.Size(199, 137);
            this.Profile.TabIndex = 6;
            this.Profile.Text = "Profile";
            this.Profile.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Profile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Profile.UseVisualStyleBackColor = false;
            this.Profile.Click += new System.EventHandler(this.Profile_Click);
            // 
            // DataPage
            // 
            this.DataPage.BackColor = System.Drawing.Color.Transparent;
            this.DataPage.FlatAppearance.BorderSize = 0;
            this.DataPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataPage.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataPage.ForeColor = System.Drawing.Color.White;
            this.DataPage.Image = ((System.Drawing.Image)(resources.GetObject("DataPage.Image")));
            this.DataPage.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataPage.Location = new System.Drawing.Point(3, 435);
            this.DataPage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataPage.Name = "DataPage";
            this.DataPage.Size = new System.Drawing.Size(199, 113);
            this.DataPage.TabIndex = 5;
            this.DataPage.Text = "Data Page";
            this.DataPage.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataPage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataPage.UseVisualStyleBackColor = false;
            this.DataPage.Click += new System.EventHandler(this.DataPage_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Exit.Location = new System.Drawing.Point(3, 657);
            this.Exit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(193, 114);
            this.Exit.TabIndex = 4;
            this.Exit.Text = "Exit";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Graph
            // 
            this.Graph.BackColor = System.Drawing.Color.Transparent;
            this.Graph.FlatAppearance.BorderSize = 0;
            this.Graph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Graph.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graph.ForeColor = System.Drawing.Color.White;
            this.Graph.Image = ((System.Drawing.Image)(resources.GetObject("Graph.Image")));
            this.Graph.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Graph.Location = new System.Drawing.Point(1, 552);
            this.Graph.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Graph.Name = "Graph";
            this.Graph.Size = new System.Drawing.Size(196, 101);
            this.Graph.TabIndex = 3;
            this.Graph.Text = "Graph";
            this.Graph.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Graph.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Graph.UseVisualStyleBackColor = false;
            this.Graph.Click += new System.EventHandler(this.Graph_Click);
            // 
            // DataInput
            // 
            this.DataInput.BackColor = System.Drawing.Color.Transparent;
            this.DataInput.FlatAppearance.BorderSize = 0;
            this.DataInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataInput.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataInput.ForeColor = System.Drawing.Color.White;
            this.DataInput.Image = ((System.Drawing.Image)(resources.GetObject("DataInput.Image")));
            this.DataInput.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataInput.Location = new System.Drawing.Point(-2, 318);
            this.DataInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataInput.Name = "DataInput";
            this.DataInput.Size = new System.Drawing.Size(199, 113);
            this.DataInput.TabIndex = 2;
            this.DataInput.Text = "Data Input";
            this.DataInput.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataInput.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataInput.UseVisualStyleBackColor = false;
            this.DataInput.Click += new System.EventHandler(this.DataInput_Click);
            // 
            // Home_Page
            // 
            this.Home_Page.BackColor = System.Drawing.Color.Transparent;
            this.Home_Page.FlatAppearance.BorderSize = 0;
            this.Home_Page.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home_Page.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Home_Page.ForeColor = System.Drawing.Color.White;
            this.Home_Page.Image = ((System.Drawing.Image)(resources.GetObject("Home_Page.Image")));
            this.Home_Page.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Home_Page.Location = new System.Drawing.Point(0, 69);
            this.Home_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Home_Page.Name = "Home_Page";
            this.Home_Page.Size = new System.Drawing.Size(199, 98);
            this.Home_Page.TabIndex = 1;
            this.Home_Page.Text = "Home Page";
            this.Home_Page.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Home_Page.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Home_Page.UseVisualStyleBackColor = false;
            this.Home_Page.Click += new System.EventHandler(this.Home_Page_Click);
            // 
            // FinancePanel
            // 
            this.FinancePanel.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.FinancePanel.Controls.Add(this.FinanceTracker);
            this.FinancePanel.Location = new System.Drawing.Point(0, 0);
            this.FinancePanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FinancePanel.Name = "FinancePanel";
            this.FinancePanel.Size = new System.Drawing.Size(199, 74);
            this.FinancePanel.TabIndex = 0;
            this.FinancePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.FinancePanel_Paint);
            // 
            // FinanceTracker
            // 
            this.FinanceTracker.AutoSize = true;
            this.FinanceTracker.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.FinanceTracker.ForeColor = System.Drawing.Color.White;
            this.FinanceTracker.Location = new System.Drawing.Point(11, 14);
            this.FinanceTracker.Name = "FinanceTracker";
            this.FinanceTracker.Size = new System.Drawing.Size(179, 28);
            this.FinanceTracker.TabIndex = 0;
            this.FinanceTracker.Text = "Finance Tracker";
            // 
            // HomePage
            // 
            this.HomePage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.HomePage.Controls.Add(this.HomePg);
            this.HomePage.Location = new System.Drawing.Point(203, 0);
            this.HomePage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.HomePage.Name = "HomePage";
            this.HomePage.Size = new System.Drawing.Size(1107, 773);
            this.HomePage.TabIndex = 2;
            // 
            // HomePg
            // 
            this.HomePg.AutoSize = true;
            this.HomePg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.HomePg.ForeColor = System.Drawing.Color.White;
            this.HomePg.Location = new System.Drawing.Point(300, 9);
            this.HomePg.Name = "HomePg";
            this.HomePg.Size = new System.Drawing.Size(457, 44);
            this.HomePg.TabIndex = 18;
            this.HomePg.Text = "Welcome to the Home Page";
            // 
            // Data
            // 
            this.Data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Data.Controls.Add(this.Searchlabel);
            this.Data.Controls.Add(this.richTextBox1);
            this.Data.Controls.Add(this.dataGridView1);
            this.Data.Controls.Add(this.Data_Search);
            this.Data.Location = new System.Drawing.Point(203, 0);
            this.Data.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(1107, 773);
            this.Data.TabIndex = 37;
            // 
            // Searchlabel
            // 
            this.Searchlabel.AutoSize = true;
            this.Searchlabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchlabel.ForeColor = System.Drawing.Color.White;
            this.Searchlabel.Location = new System.Drawing.Point(633, 69);
            this.Searchlabel.Name = "Searchlabel";
            this.Searchlabel.Size = new System.Drawing.Size(104, 32);
            this.Searchlabel.TabIndex = 24;
            this.Searchlabel.Text = "Search:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(749, 73);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(304, 26);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.costToMakeDataGridViewTextBoxColumn,
            this.sellingPriceDataGridViewTextBoxColumn,
            this.amountSoldDataGridViewTextBoxColumn,
            this.amountMadeDataGridViewTextBoxColumn,
            this.monthDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.itemBindingSource;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(51, 118);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1004, 466);
            this.dataGridView1.TabIndex = 19;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Item Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // costToMakeDataGridViewTextBoxColumn
            // 
            this.costToMakeDataGridViewTextBoxColumn.DataPropertyName = "costToMake";
            this.costToMakeDataGridViewTextBoxColumn.HeaderText = "Cost to Make";
            this.costToMakeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.costToMakeDataGridViewTextBoxColumn.Name = "costToMakeDataGridViewTextBoxColumn";
            this.costToMakeDataGridViewTextBoxColumn.ReadOnly = true;
            this.costToMakeDataGridViewTextBoxColumn.Width = 125;
            // 
            // sellingPriceDataGridViewTextBoxColumn
            // 
            this.sellingPriceDataGridViewTextBoxColumn.DataPropertyName = "sellingPrice";
            this.sellingPriceDataGridViewTextBoxColumn.HeaderText = "Selling Price";
            this.sellingPriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sellingPriceDataGridViewTextBoxColumn.Name = "sellingPriceDataGridViewTextBoxColumn";
            this.sellingPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.sellingPriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountSoldDataGridViewTextBoxColumn
            // 
            this.amountSoldDataGridViewTextBoxColumn.DataPropertyName = "AmountSold";
            this.amountSoldDataGridViewTextBoxColumn.HeaderText = "Amount Sold";
            this.amountSoldDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountSoldDataGridViewTextBoxColumn.Name = "amountSoldDataGridViewTextBoxColumn";
            this.amountSoldDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountSoldDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountMadeDataGridViewTextBoxColumn
            // 
            this.amountMadeDataGridViewTextBoxColumn.DataPropertyName = "AmountMade";
            this.amountMadeDataGridViewTextBoxColumn.HeaderText = "Amount Made";
            this.amountMadeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountMadeDataGridViewTextBoxColumn.Name = "amountMadeDataGridViewTextBoxColumn";
            this.amountMadeDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountMadeDataGridViewTextBoxColumn.Width = 125;
            // 
            // monthDataGridViewTextBoxColumn
            // 
            this.monthDataGridViewTextBoxColumn.DataPropertyName = "Month";
            this.monthDataGridViewTextBoxColumn.HeaderText = "Month";
            this.monthDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.monthDataGridViewTextBoxColumn.Name = "monthDataGridViewTextBoxColumn";
            this.monthDataGridViewTextBoxColumn.ReadOnly = true;
            this.monthDataGridViewTextBoxColumn.Width = 125;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.ReadOnly = true;
            this.yearDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemBindingSource
            // 
            this.itemBindingSource.DataMember = "item";
            this.itemBindingSource.DataSource = this.finance_trackerDataSet;
            // 
            // finance_trackerDataSet
            // 
            this.finance_trackerDataSet.DataSetName = "finance_trackerDataSet";
            this.finance_trackerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Data_Search
            // 
            this.Data_Search.AutoSize = true;
            this.Data_Search.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Data_Search.ForeColor = System.Drawing.Color.White;
            this.Data_Search.Location = new System.Drawing.Point(300, 9);
            this.Data_Search.Name = "Data_Search";
            this.Data_Search.Size = new System.Drawing.Size(436, 44);
            this.Data_Search.TabIndex = 18;
            this.Data_Search.Text = "Welcome to the Data Page";
            // 
            // InputData
            // 
            this.InputData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.InputData.Controls.Add(this.dataAdded);
            this.InputData.Controls.Add(this.ysMark);
            this.InputData.Controls.Add(this.msMark);
            this.InputData.Controls.Add(this.asMark);
            this.InputData.Controls.Add(this.amMark);
            this.InputData.Controls.Add(this.spMark);
            this.InputData.Controls.Add(this.ictmMark);
            this.InputData.Controls.Add(this.inMark);
            this.InputData.Controls.Add(this.idMark);
            this.InputData.Controls.Add(this.MonthSold);
            this.InputData.Controls.Add(this.YearSold);
            this.InputData.Controls.Add(this.AmountSold);
            this.InputData.Controls.Add(this.AmountMade);
            this.InputData.Controls.Add(this.SoldPrice);
            this.InputData.Controls.Add(this.CostItem);
            this.InputData.Controls.Add(this.ItemName);
            this.InputData.Controls.Add(this.ItemId);
            this.InputData.Controls.Add(this.Amount_Made);
            this.InputData.Controls.Add(this.Input);
            this.InputData.Controls.Add(this.Year);
            this.InputData.Controls.Add(this.Month);
            this.InputData.Controls.Add(this.Selling_Price);
            this.InputData.Controls.Add(this.Amount_Sold);
            this.InputData.Controls.Add(this.Cost);
            this.InputData.Controls.Add(this.Item_Name);
            this.InputData.Controls.Add(this.Item_Id);
            this.InputData.Controls.Add(this.Input_Page);
            this.InputData.Location = new System.Drawing.Point(203, 0);
            this.InputData.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.InputData.Name = "InputData";
            this.InputData.Size = new System.Drawing.Size(1107, 773);
            this.InputData.TabIndex = 38;
            this.InputData.Paint += new System.Windows.Forms.PaintEventHandler(this.InputData_Paint);
            // 
            // dataAdded
            // 
            this.dataAdded.AutoSize = true;
            this.dataAdded.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataAdded.ForeColor = System.Drawing.Color.White;
            this.dataAdded.Location = new System.Drawing.Point(416, 458);
            this.dataAdded.Name = "dataAdded";
            this.dataAdded.Size = new System.Drawing.Size(0, 22);
            this.dataAdded.TabIndex = 43;
            // 
            // ysMark
            // 
            this.ysMark.AutoSize = true;
            this.ysMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ysMark.ForeColor = System.Drawing.Color.Red;
            this.ysMark.Location = new System.Drawing.Point(679, 300);
            this.ysMark.Name = "ysMark";
            this.ysMark.Size = new System.Drawing.Size(0, 22);
            this.ysMark.TabIndex = 42;
            // 
            // msMark
            // 
            this.msMark.AutoSize = true;
            this.msMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msMark.ForeColor = System.Drawing.Color.Red;
            this.msMark.Location = new System.Drawing.Point(311, 300);
            this.msMark.Name = "msMark";
            this.msMark.Size = new System.Drawing.Size(0, 22);
            this.msMark.TabIndex = 41;
            // 
            // asMark
            // 
            this.asMark.AutoSize = true;
            this.asMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asMark.ForeColor = System.Drawing.Color.Red;
            this.asMark.Location = new System.Drawing.Point(679, 247);
            this.asMark.Name = "asMark";
            this.asMark.Size = new System.Drawing.Size(0, 22);
            this.asMark.TabIndex = 40;
            // 
            // amMark
            // 
            this.amMark.AutoSize = true;
            this.amMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amMark.ForeColor = System.Drawing.Color.Red;
            this.amMark.Location = new System.Drawing.Point(311, 247);
            this.amMark.Name = "amMark";
            this.amMark.Size = new System.Drawing.Size(0, 22);
            this.amMark.TabIndex = 39;
            // 
            // spMark
            // 
            this.spMark.AutoSize = true;
            this.spMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spMark.ForeColor = System.Drawing.Color.Red;
            this.spMark.Location = new System.Drawing.Point(679, 197);
            this.spMark.Name = "spMark";
            this.spMark.Size = new System.Drawing.Size(0, 22);
            this.spMark.TabIndex = 38;
            // 
            // ictmMark
            // 
            this.ictmMark.AutoSize = true;
            this.ictmMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ictmMark.ForeColor = System.Drawing.Color.Red;
            this.ictmMark.Location = new System.Drawing.Point(311, 197);
            this.ictmMark.Name = "ictmMark";
            this.ictmMark.Size = new System.Drawing.Size(0, 22);
            this.ictmMark.TabIndex = 37;
            // 
            // inMark
            // 
            this.inMark.AutoSize = true;
            this.inMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inMark.ForeColor = System.Drawing.Color.Red;
            this.inMark.Location = new System.Drawing.Point(679, 146);
            this.inMark.Name = "inMark";
            this.inMark.Size = new System.Drawing.Size(0, 22);
            this.inMark.TabIndex = 36;
            // 
            // idMark
            // 
            this.idMark.AutoSize = true;
            this.idMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idMark.ForeColor = System.Drawing.Color.Red;
            this.idMark.Location = new System.Drawing.Point(311, 145);
            this.idMark.Name = "idMark";
            this.idMark.Size = new System.Drawing.Size(0, 22);
            this.idMark.TabIndex = 35;
            // 
            // MonthSold
            // 
            this.MonthSold.AutoSize = true;
            this.MonthSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonthSold.ForeColor = System.Drawing.Color.Transparent;
            this.MonthSold.Location = new System.Drawing.Point(179, 322);
            this.MonthSold.Name = "MonthSold";
            this.MonthSold.Size = new System.Drawing.Size(108, 22);
            this.MonthSold.TabIndex = 34;
            this.MonthSold.Text = "Month Sold:";
            // 
            // YearSold
            // 
            this.YearSold.AutoSize = true;
            this.YearSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YearSold.ForeColor = System.Drawing.Color.Transparent;
            this.YearSold.Location = new System.Drawing.Point(569, 324);
            this.YearSold.Name = "YearSold";
            this.YearSold.Size = new System.Drawing.Size(95, 22);
            this.YearSold.TabIndex = 33;
            this.YearSold.Text = "Year Sold:";
            // 
            // AmountSold
            // 
            this.AmountSold.AutoSize = true;
            this.AmountSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountSold.ForeColor = System.Drawing.Color.Transparent;
            this.AmountSold.Location = new System.Drawing.Point(549, 271);
            this.AmountSold.Name = "AmountSold";
            this.AmountSold.Size = new System.Drawing.Size(119, 22);
            this.AmountSold.TabIndex = 32;
            this.AmountSold.Text = "Amount Sold:";
            // 
            // AmountMade
            // 
            this.AmountMade.AutoSize = true;
            this.AmountMade.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountMade.ForeColor = System.Drawing.Color.Transparent;
            this.AmountMade.Location = new System.Drawing.Point(168, 271);
            this.AmountMade.Name = "AmountMade";
            this.AmountMade.Size = new System.Drawing.Size(127, 22);
            this.AmountMade.TabIndex = 31;
            this.AmountMade.Text = "Amount Made:";
            // 
            // SoldPrice
            // 
            this.SoldPrice.AutoSize = true;
            this.SoldPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoldPrice.ForeColor = System.Drawing.Color.Transparent;
            this.SoldPrice.Location = new System.Drawing.Point(569, 220);
            this.SoldPrice.Name = "SoldPrice";
            this.SoldPrice.Size = new System.Drawing.Size(100, 22);
            this.SoldPrice.TabIndex = 30;
            this.SoldPrice.Text = "Sold Price:";
            // 
            // CostItem
            // 
            this.CostItem.AutoSize = true;
            this.CostItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostItem.ForeColor = System.Drawing.Color.Transparent;
            this.CostItem.Location = new System.Drawing.Point(131, 222);
            this.CostItem.Name = "CostItem";
            this.CostItem.Size = new System.Drawing.Size(157, 22);
            this.CostItem.TabIndex = 29;
            this.CostItem.Text = "Item Cost to make:";
            // 
            // ItemName
            // 
            this.ItemName.AutoSize = true;
            this.ItemName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemName.ForeColor = System.Drawing.Color.Transparent;
            this.ItemName.Location = new System.Drawing.Point(569, 171);
            this.ItemName.Name = "ItemName";
            this.ItemName.Size = new System.Drawing.Size(101, 22);
            this.ItemName.TabIndex = 28;
            this.ItemName.Text = "Item Name:";
            // 
            // ItemId
            // 
            this.ItemId.AutoSize = true;
            this.ItemId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemId.ForeColor = System.Drawing.Color.Transparent;
            this.ItemId.Location = new System.Drawing.Point(216, 170);
            this.ItemId.Name = "ItemId";
            this.ItemId.Size = new System.Drawing.Size(71, 22);
            this.ItemId.TabIndex = 27;
            this.ItemId.Text = "Item Id:";
            // 
            // Amount_Made
            // 
            this.Amount_Made.Location = new System.Drawing.Point(315, 271);
            this.Amount_Made.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Amount_Made.Name = "Amount_Made";
            this.Amount_Made.Size = new System.Drawing.Size(177, 22);
            this.Amount_Made.TabIndex = 5;
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(412, 484);
            this.Input.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(267, 46);
            this.Input.TabIndex = 9;
            this.Input.Text = "Input Data";
            this.Input.UseVisualStyleBackColor = true;
            this.Input.Click += new System.EventHandler(this.Input_Click);
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(677, 324);
            this.Year.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(177, 22);
            this.Year.TabIndex = 8;
            // 
            // Month
            // 
            this.Month.Location = new System.Drawing.Point(315, 324);
            this.Month.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(177, 22);
            this.Month.TabIndex = 7;
            // 
            // Selling_Price
            // 
            this.Selling_Price.Location = new System.Drawing.Point(677, 222);
            this.Selling_Price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Selling_Price.Name = "Selling_Price";
            this.Selling_Price.Size = new System.Drawing.Size(177, 22);
            this.Selling_Price.TabIndex = 4;
            // 
            // Amount_Sold
            // 
            this.Amount_Sold.Location = new System.Drawing.Point(677, 271);
            this.Amount_Sold.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Amount_Sold.Name = "Amount_Sold";
            this.Amount_Sold.Size = new System.Drawing.Size(177, 22);
            this.Amount_Sold.TabIndex = 6;
            // 
            // Cost
            // 
            this.Cost.Location = new System.Drawing.Point(315, 222);
            this.Cost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(177, 22);
            this.Cost.TabIndex = 3;
            // 
            // Item_Name
            // 
            this.Item_Name.Location = new System.Drawing.Point(677, 171);
            this.Item_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Item_Name.Name = "Item_Name";
            this.Item_Name.Size = new System.Drawing.Size(177, 22);
            this.Item_Name.TabIndex = 2;
            // 
            // Item_Id
            // 
            this.Item_Id.Location = new System.Drawing.Point(315, 171);
            this.Item_Id.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Item_Id.Name = "Item_Id";
            this.Item_Id.Size = new System.Drawing.Size(177, 22);
            this.Item_Id.TabIndex = 1;
            // 
            // Input_Page
            // 
            this.Input_Page.AutoSize = true;
            this.Input_Page.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Input_Page.ForeColor = System.Drawing.Color.White;
            this.Input_Page.Location = new System.Drawing.Point(469, 46);
            this.Input_Page.Name = "Input_Page";
            this.Input_Page.Size = new System.Drawing.Size(195, 44);
            this.Input_Page.TabIndex = 17;
            this.Input_Page.Text = "Input Page";
            // 
            // itemTableAdapter
            // 
            this.itemTableAdapter.ClearBeforeFill = true;
            // 
            // Profile_Page
            // 
            this.Profile_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Profile_Page.Controls.Add(this.Profilelab);
            this.Profile_Page.Location = new System.Drawing.Point(203, 0);
            this.Profile_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Profile_Page.Name = "Profile_Page";
            this.Profile_Page.Size = new System.Drawing.Size(1107, 773);
            this.Profile_Page.TabIndex = 39;
            // 
            // Profilelab
            // 
            this.Profilelab.AutoSize = true;
            this.Profilelab.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Profilelab.ForeColor = System.Drawing.Color.White;
            this.Profilelab.Location = new System.Drawing.Point(300, 9);
            this.Profilelab.Name = "Profilelab";
            this.Profilelab.Size = new System.Drawing.Size(492, 44);
            this.Profilelab.TabIndex = 18;
            this.Profilelab.Text = "Welcome to your Profile Page";
            // 
            // Part_Input
            // 
            this.Part_Input.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Part_Input.Controls.Add(this.edit_Part);
            this.Part_Input.Controls.Add(this.label6);
            this.Part_Input.Controls.Add(this.label7);
            this.Part_Input.Controls.Add(this.label8);
            this.Part_Input.Controls.Add(this.label9);
            this.Part_Input.Controls.Add(this.label14);
            this.Part_Input.Controls.Add(this.Part_Amount);
            this.Part_Input.Controls.Add(this.Part_Name);
            this.Part_Input.Controls.Add(this.ProductId);
            this.Part_Input.Controls.Add(this.button1);
            this.Part_Input.Controls.Add(this.textBox4);
            this.Part_Input.Controls.Add(this.textBox6);
            this.Part_Input.Controls.Add(this.textBox7);
            this.Part_Input.Controls.Add(this.textBox8);
            this.Part_Input.Controls.Add(this.Parts_input_page);
            this.Part_Input.Location = new System.Drawing.Point(203, 0);
            this.Part_Input.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Part_Input.Name = "Part_Input";
            this.Part_Input.Size = new System.Drawing.Size(1107, 773);
            this.Part_Input.TabIndex = 46;
            // 
            // edit_Part
            // 
            this.edit_Part.Location = new System.Drawing.Point(587, 338);
            this.edit_Part.Name = "edit_Part";
            this.edit_Part.Size = new System.Drawing.Size(267, 44);
            this.edit_Part.TabIndex = 44;
            this.edit_Part.Text = "Edit Part Data";
            this.edit_Part.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(679, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 22);
            this.label6.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(311, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 22);
            this.label7.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(679, 146);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 22);
            this.label8.TabIndex = 36;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(311, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 22);
            this.label9.TabIndex = 35;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Transparent;
            this.label14.Location = new System.Drawing.Point(543, 222);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(128, 22);
            this.label14.TabIndex = 30;
            this.label14.Text = "Delivery Date:";
            // 
            // Part_Amount
            // 
            this.Part_Amount.AutoSize = true;
            this.Part_Amount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Part_Amount.ForeColor = System.Drawing.Color.Transparent;
            this.Part_Amount.Location = new System.Drawing.Point(190, 222);
            this.Part_Amount.Name = "Part_Amount";
            this.Part_Amount.Size = new System.Drawing.Size(113, 22);
            this.Part_Amount.TabIndex = 29;
            this.Part_Amount.Text = "Part Amount:";
            // 
            // Part_Name
            // 
            this.Part_Name.AutoSize = true;
            this.Part_Name.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Part_Name.ForeColor = System.Drawing.Color.Transparent;
            this.Part_Name.Location = new System.Drawing.Point(564, 170);
            this.Part_Name.Name = "Part_Name";
            this.Part_Name.Size = new System.Drawing.Size(99, 22);
            this.Part_Name.TabIndex = 28;
            this.Part_Name.Text = "Part Name:";
            // 
            // ProductId
            // 
            this.ProductId.AutoSize = true;
            this.ProductId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductId.ForeColor = System.Drawing.Color.Transparent;
            this.ProductId.Location = new System.Drawing.Point(211, 170);
            this.ProductId.Name = "ProductId";
            this.ProductId.Size = new System.Drawing.Size(98, 22);
            this.ProductId.TabIndex = 27;
            this.ProductId.Text = "Product Id:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(225, 338);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(267, 46);
            this.button1.TabIndex = 9;
            this.button1.Text = "Input Data";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(677, 222);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(177, 22);
            this.textBox4.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(315, 222);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(177, 22);
            this.textBox6.TabIndex = 3;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(677, 171);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(177, 22);
            this.textBox7.TabIndex = 2;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(315, 171);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(177, 22);
            this.textBox8.TabIndex = 1;
            // 
            // Parts_input_page
            // 
            this.Parts_input_page.AutoSize = true;
            this.Parts_input_page.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Parts_input_page.ForeColor = System.Drawing.Color.White;
            this.Parts_input_page.Location = new System.Drawing.Point(469, 46);
            this.Parts_input_page.Name = "Parts_input_page";
            this.Parts_input_page.Size = new System.Drawing.Size(288, 44);
            this.Parts_input_page.TabIndex = 17;
            this.Parts_input_page.Text = "Parts Input Page";
            // 
            // Graph_Page
            // 
            this.Graph_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Graph_Page.Controls.Add(this.Yearly_Data);
            this.Graph_Page.Controls.Add(this.Monthly_Data);
            this.Graph_Page.Controls.Add(this.Graphpg);
            this.Graph_Page.Controls.Add(this.GraphData);
            this.Graph_Page.Location = new System.Drawing.Point(203, 0);
            this.Graph_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Graph_Page.Name = "Graph_Page";
            this.Graph_Page.Size = new System.Drawing.Size(1107, 773);
            this.Graph_Page.TabIndex = 47;
            // 
            // Graphpg
            // 
            this.Graphpg.AutoSize = true;
            this.Graphpg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graphpg.ForeColor = System.Drawing.Color.White;
            this.Graphpg.Location = new System.Drawing.Point(367, 9);
            this.Graphpg.Name = "Graphpg";
            this.Graphpg.Size = new System.Drawing.Size(209, 44);
            this.Graphpg.TabIndex = 18;
            this.Graphpg.Text = "Graph Page";
            // 
            // GraphData
            // 
            chartArea1.Name = "ChartArea1";
            this.GraphData.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.GraphData.Legends.Add(legend1);
            this.GraphData.Location = new System.Drawing.Point(19, 69);
            this.GraphData.Name = "GraphData";
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(115)))), ((int)(((byte)(142)))));
            series1.Legend = "Legend1";
            series1.Name = "Sales";
            series2.ChartArea = "ChartArea1";
            series2.Color = System.Drawing.Color.Maroon;
            series2.Legend = "Legend1";
            series2.Name = "Costs";
            series3.ChartArea = "ChartArea1";
            series3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(55)))), ((int)(((byte)(38)))));
            series3.Legend = "Legend1";
            series3.Name = "Profit";
            this.GraphData.Series.Add(series1);
            this.GraphData.Series.Add(series2);
            this.GraphData.Series.Add(series3);
            this.GraphData.Size = new System.Drawing.Size(1063, 566);
            this.GraphData.TabIndex = 45;
            this.GraphData.Text = "chart1";
            title1.Name = "Monthly";
            this.GraphData.Titles.Add(title1);
            // 
            // Monthly_Data
            // 
            this.Monthly_Data.Location = new System.Drawing.Point(339, 689);
            this.Monthly_Data.Name = "Monthly_Data";
            this.Monthly_Data.Size = new System.Drawing.Size(153, 46);
            this.Monthly_Data.TabIndex = 46;
            this.Monthly_Data.Text = "Monthly";
            this.Monthly_Data.UseVisualStyleBackColor = true;
            this.Monthly_Data.Click += new System.EventHandler(this.Monthly_Data_Click);
            // 
            // Yearly_Data
            // 
            this.Yearly_Data.Location = new System.Drawing.Point(518, 689);
            this.Yearly_Data.Name = "Yearly_Data";
            this.Yearly_Data.Size = new System.Drawing.Size(153, 46);
            this.Yearly_Data.TabIndex = 47;
            this.Yearly_Data.Text = "Yearly";
            this.Yearly_Data.UseVisualStyleBackColor = true;
            this.Yearly_Data.Click += new System.EventHandler(this.Yearly_Data_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1307, 774);
            this.Controls.Add(this.Graph_Page);
            this.Controls.Add(this.Part_Input);
            this.Controls.Add(this.Profile_Page);
            this.Controls.Add(this.InputData);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.HomePage);
            this.Controls.Add(this.Side1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Finance Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompleteClosing);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.Enter += new System.EventHandler(this.Form1_Load_1);
            this.Side1.ResumeLayout(false);
            this.FinancePanel.ResumeLayout(false);
            this.FinancePanel.PerformLayout();
            this.HomePage.ResumeLayout(false);
            this.HomePage.PerformLayout();
            this.Data.ResumeLayout(false);
            this.Data.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet)).EndInit();
            this.InputData.ResumeLayout(false);
            this.InputData.PerformLayout();
            this.Profile_Page.ResumeLayout(false);
            this.Profile_Page.PerformLayout();
            this.Part_Input.ResumeLayout(false);
            this.Part_Input.PerformLayout();
            this.Graph_Page.ResumeLayout(false);
            this.Graph_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GraphData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel Side1;
        private System.Windows.Forms.Panel FinancePanel;
        private System.Windows.Forms.Button Home_Page;
        private System.Windows.Forms.Button DataInput;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Graph;
        private System.Windows.Forms.Label FinanceTracker;
        private System.Windows.Forms.Panel HomePage;
        private System.Windows.Forms.Label HomePg;
        private System.Windows.Forms.Button DataPage;
        private System.Windows.Forms.Panel Data;
        private System.Windows.Forms.Label Data_Search;
        private System.Windows.Forms.Label Searchlabel;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel InputData;
        private System.Windows.Forms.Label MonthSold;
        private System.Windows.Forms.Label YearSold;
        private System.Windows.Forms.Label AmountSold;
        private System.Windows.Forms.Label AmountMade;
        private System.Windows.Forms.Label SoldPrice;
        private System.Windows.Forms.Label CostItem;
        private System.Windows.Forms.Label ItemName;
        private System.Windows.Forms.Label ItemId;
        private System.Windows.Forms.TextBox Amount_Made;
        private System.Windows.Forms.Button Input;
        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.TextBox Month;
        private System.Windows.Forms.TextBox Selling_Price;
        private System.Windows.Forms.TextBox Amount_Sold;
        private System.Windows.Forms.TextBox Cost;
        private System.Windows.Forms.TextBox Item_Name;
        private System.Windows.Forms.TextBox Item_Id;
        private System.Windows.Forms.Label Input_Page;
        private System.Windows.Forms.Label ictmMark;
        private System.Windows.Forms.Label inMark;
        private System.Windows.Forms.Label idMark;
        private System.Windows.Forms.Label msMark;
        private System.Windows.Forms.Label asMark;
        private System.Windows.Forms.Label amMark;
        private System.Windows.Forms.Label spMark;
        private System.Windows.Forms.Label ysMark;
        private System.Windows.Forms.Label dataAdded;
        private Finance_Tracker_SE.finance_trackerDataSet finance_trackerDataSet;
        private System.Windows.Forms.BindingSource itemBindingSource;
        private Finance_Tracker_SE.finance_trackerDataSetTableAdapters.itemTableAdapter itemTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costToMakeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellingPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountSoldDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountMadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn monthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Profile;
        private System.Windows.Forms.Panel Profile_Page;
        private System.Windows.Forms.Label Profilelab;
        private System.Windows.Forms.Panel Part_Input;
        private System.Windows.Forms.Button edit_Part;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label Part_Amount;
        private System.Windows.Forms.Label Part_Name;
        private System.Windows.Forms.Label ProductId;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label Parts_input_page;
        private System.Windows.Forms.Panel Graph_Page;
        private System.Windows.Forms.Button Yearly_Data;
        private System.Windows.Forms.Button Monthly_Data;
        private System.Windows.Forms.Label Graphpg;
        private System.Windows.Forms.DataVisualization.Charting.Chart GraphData;
    }
}

