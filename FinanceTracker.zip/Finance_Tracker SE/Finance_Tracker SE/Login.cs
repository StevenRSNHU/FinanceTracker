﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using MySql.Data.MySqlClient;

namespace Software_Engineering_Project
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Username_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_Input_TextChanged(object sender, EventArgs e)
        {

        }

        int remaining_Attemps = 8; // Attemps need to be out of button so it keeps count

        private void Login_Click(object sender, EventArgs e)
        {
            
            //Variables
            string b_Password = Password_Input.Text;
            string b_Username = Username_Input.Text;
            string b_Email = Username_Input.Text;
            int b_Attemps = 0;
         

            MySqlConnection con = new MySqlConnection("server=127.0.0.1;user id=User; password = Password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            cmd.CommandText = "SELECT * FROM userinfo where userName='" + b_Username + "' AND password ='" + b_Password + "'"; // the camand
            MySqlDataReader dRead; // to read the data base
             

            if (remaining_Attemps <= 0) //the users attemps
            {
                MessageBox.Show("Sorry You have attemped way to many times");
                MessageBox.Show("try again  in 10 minutes:");

            }
            else // if it works and they have a attemp
            {
                con.Open(); // opens connection
                    
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read()) // if it is in it
                        {
                            dRead.Read();
                            Username.Text = "";
                            Password.Text = "";
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Access Denied!");
                            Username.Text = "";
                            Password.Text = "";
                        b_Attemps++;
                        remaining_Attemps = remaining_Attemps - b_Attemps;
                        MessageBox.Show(" Your Password or Username/Email is Incorrect. You have " + remaining_Attemps + " remaining!");
                    }
                    }
               
                con.Close();
                
            }
        }
    

        private void SignUp_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form3 F3 = new Form3();
            F3.Show();
            this.Close();   
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


    }
}
