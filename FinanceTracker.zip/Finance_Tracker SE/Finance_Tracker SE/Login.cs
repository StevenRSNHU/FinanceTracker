﻿/***

Program:  Finance Tracker

Purpose: To allow Business to keep Track of there Expensices,Sales and profit 

Author:  Tyler Scott, Aaliyah Ortiz, Steven Renfree

Date: October 12,2020

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using MySql.Data.MySqlClient;

namespace Software_Engineering_Project
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Username_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_Input_TextChanged(object sender, EventArgs e)
        {

        }

        int remaining_Attemps = 8; // Attemps need to be out of button so it keeps count
        public static int userID;

        private void Login_Click(object sender, EventArgs e)
        {

            //Variables
            string b_Password = Password_Input.Text;
            string b_Username = Username_Input.Text;
            int b_Attemps = 0;

            if (b_Password == "" || b_Username == "")
            {
                MessageBox.Show("Requires both Username and Password");
            }

            else
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=user; password = password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "SELECT * FROM userinfo where userName='" + b_Username + "' AND password ='" + b_Password + "'"; // the camand
                MySqlDataReader dRead; // to read the data base


                if (remaining_Attemps <= 0) //the users attemps
                {
                    MessageBox.Show("Sorry You have attemped way to many times");
                    MessageBox.Show("try again  in 10 minutes:");

                }
                else // if it works and they have a attemp
                {
                    con.Open(); // opens connection

                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read()) // Checks if username and password is in it
                        {
                            dRead.Read();
                            Username.Text = ""; //reset input box
                            Password.Text = "";
                            this.Hide();
                            Form1 F1 = new Form1(); // creates and show signup form
                            F1.Show();
                        }
                        else
                        {
                            MessageBox.Show("Access Denied!");
                            Username.Text = ""; //reset input box
                            Password.Text = "";
                            b_Attemps++;
                            remaining_Attemps = remaining_Attemps - b_Attemps;
                            MessageBox.Show(" Your Password or Username/Email is Incorrect. You have " + remaining_Attemps + " remaining!");
                        }
                    }

                    con.Close();

                }
            }
        }

        private void SignUp_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form3 F3 = new Form3(); // creates and show signup form
            F3.Show();
            this.Hide();   
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
