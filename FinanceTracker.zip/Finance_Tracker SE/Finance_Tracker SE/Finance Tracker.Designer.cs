﻿namespace Software_Engineering_Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Side1 = new System.Windows.Forms.Panel();
            this.Exit = new System.Windows.Forms.Button();
            this.Graph = new System.Windows.Forms.Button();
            this.DataInput = new System.Windows.Forms.Button();
            this.Home_Page = new System.Windows.Forms.Button();
            this.FinancePanel = new System.Windows.Forms.Panel();
            this.FinanceTracker = new System.Windows.Forms.Label();
            this.HomePage = new System.Windows.Forms.Panel();
            this.InputData = new System.Windows.Forms.Panel();
            this.MonthSold = new System.Windows.Forms.Label();
            this.YearSold = new System.Windows.Forms.Label();
            this.AmountSold = new System.Windows.Forms.Label();
            this.AmountMade = new System.Windows.Forms.Label();
            this.SoldPrice = new System.Windows.Forms.Label();
            this.CostItem = new System.Windows.Forms.Label();
            this.ItemName = new System.Windows.Forms.Label();
            this.ItemId = new System.Windows.Forms.Label();
            this.Amount_Made = new System.Windows.Forms.TextBox();
            this.Input = new System.Windows.Forms.Button();
            this.Year = new System.Windows.Forms.TextBox();
            this.Month = new System.Windows.Forms.TextBox();
            this.Selling_Price = new System.Windows.Forms.TextBox();
            this.Amount_Item = new System.Windows.Forms.TextBox();
            this.Cost = new System.Windows.Forms.TextBox();
            this.Item_Name = new System.Windows.Forms.TextBox();
            this.Item_Id = new System.Windows.Forms.TextBox();
            this.Input_Page = new System.Windows.Forms.Label();
            this.Graph_Page = new System.Windows.Forms.Panel();
            this.Graphpg = new System.Windows.Forms.Label();
            this.HomePg = new System.Windows.Forms.Label();
            this.start = new System.Windows.Forms.Button();
            this.Side1.SuspendLayout();
            this.FinancePanel.SuspendLayout();
            this.HomePage.SuspendLayout();
            this.InputData.SuspendLayout();
            this.Graph_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // Side1
            // 
            this.Side1.BackColor = System.Drawing.Color.Transparent;
            this.Side1.Controls.Add(this.Exit);
            this.Side1.Controls.Add(this.Graph);
            this.Side1.Controls.Add(this.DataInput);
            this.Side1.Controls.Add(this.Home_Page);
            this.Side1.Controls.Add(this.FinancePanel);
            this.Side1.Location = new System.Drawing.Point(0, 0);
            this.Side1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Side1.Name = "Side1";
            this.Side1.Size = new System.Drawing.Size(199, 482);
            this.Side1.TabIndex = 1;
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Exit.Location = new System.Drawing.Point(0, 372);
            this.Exit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(199, 98);
            this.Exit.TabIndex = 3;
            this.Exit.Text = "Graph";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Graph
            // 
            this.Graph.BackColor = System.Drawing.Color.Transparent;
            this.Graph.FlatAppearance.BorderSize = 0;
            this.Graph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Graph.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graph.ForeColor = System.Drawing.Color.White;
            this.Graph.Image = ((System.Drawing.Image)(resources.GetObject("Graph.Image")));
            this.Graph.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Graph.Location = new System.Drawing.Point(0, 278);
            this.Graph.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Graph.Name = "Graph";
            this.Graph.Size = new System.Drawing.Size(199, 98);
            this.Graph.TabIndex = 3;
            this.Graph.Text = "Graph";
            this.Graph.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Graph.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Graph.UseVisualStyleBackColor = false;
            this.Graph.Click += new System.EventHandler(this.Graph_Click);
            // 
            // DataInput
            // 
            this.DataInput.BackColor = System.Drawing.Color.Transparent;
            this.DataInput.FlatAppearance.BorderSize = 0;
            this.DataInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataInput.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataInput.ForeColor = System.Drawing.Color.White;
            this.DataInput.Image = ((System.Drawing.Image)(resources.GetObject("DataInput.Image")));
            this.DataInput.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataInput.Location = new System.Drawing.Point(0, 175);
            this.DataInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataInput.Name = "DataInput";
            this.DataInput.Size = new System.Drawing.Size(199, 98);
            this.DataInput.TabIndex = 3;
            this.DataInput.Text = "Data Input";
            this.DataInput.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataInput.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataInput.UseVisualStyleBackColor = false;
            this.DataInput.Click += new System.EventHandler(this.DataInput_Click);
            // 
            // Home_Page
            // 
            this.Home_Page.BackColor = System.Drawing.Color.Transparent;
            this.Home_Page.FlatAppearance.BorderSize = 0;
            this.Home_Page.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home_Page.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Home_Page.ForeColor = System.Drawing.Color.White;
            this.Home_Page.Image = ((System.Drawing.Image)(resources.GetObject("Home_Page.Image")));
            this.Home_Page.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Home_Page.Location = new System.Drawing.Point(0, 73);
            this.Home_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Home_Page.Name = "Home_Page";
            this.Home_Page.Size = new System.Drawing.Size(199, 98);
            this.Home_Page.TabIndex = 3;
            this.Home_Page.Text = "Home Page";
            this.Home_Page.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Home_Page.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Home_Page.UseVisualStyleBackColor = false;
            this.Home_Page.Click += new System.EventHandler(this.Home_Page_Click);
            // 
            // FinancePanel
            // 
            this.FinancePanel.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.FinancePanel.Controls.Add(this.FinanceTracker);
            this.FinancePanel.Location = new System.Drawing.Point(0, 0);
            this.FinancePanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FinancePanel.Name = "FinancePanel";
            this.FinancePanel.Size = new System.Drawing.Size(199, 74);
            this.FinancePanel.TabIndex = 2;
            // 
            // FinanceTracker
            // 
            this.FinanceTracker.AutoSize = true;
            this.FinanceTracker.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.FinanceTracker.ForeColor = System.Drawing.Color.White;
            this.FinanceTracker.Location = new System.Drawing.Point(11, 13);
            this.FinanceTracker.Name = "FinanceTracker";
            this.FinanceTracker.Size = new System.Drawing.Size(179, 28);
            this.FinanceTracker.TabIndex = 0;
            this.FinanceTracker.Text = "Finance Tracker";
            // 
            // HomePage
            // 
            this.HomePage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.HomePage.Controls.Add(this.HomePg);
            this.HomePage.Location = new System.Drawing.Point(202, 0);
            this.HomePage.Name = "HomePage";
            this.HomePage.Size = new System.Drawing.Size(1107, 482);
            this.HomePage.TabIndex = 2;
            // 
            // InputData
            // 
            this.InputData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.InputData.Controls.Add(this.MonthSold);
            this.InputData.Controls.Add(this.YearSold);
            this.InputData.Controls.Add(this.AmountSold);
            this.InputData.Controls.Add(this.AmountMade);
            this.InputData.Controls.Add(this.SoldPrice);
            this.InputData.Controls.Add(this.CostItem);
            this.InputData.Controls.Add(this.ItemName);
            this.InputData.Controls.Add(this.ItemId);
            this.InputData.Controls.Add(this.Amount_Made);
            this.InputData.Controls.Add(this.Input);
            this.InputData.Controls.Add(this.Year);
            this.InputData.Controls.Add(this.Month);
            this.InputData.Controls.Add(this.Selling_Price);
            this.InputData.Controls.Add(this.Amount_Item);
            this.InputData.Controls.Add(this.Cost);
            this.InputData.Controls.Add(this.Item_Name);
            this.InputData.Controls.Add(this.Item_Id);
            this.InputData.Controls.Add(this.Input_Page);
            this.InputData.Location = new System.Drawing.Point(202, 0);
            this.InputData.Name = "InputData";
            this.InputData.Size = new System.Drawing.Size(1107, 482);
            this.InputData.TabIndex = 6;
            // 
            // MonthSold
            // 
            this.MonthSold.AutoSize = true;
            this.MonthSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonthSold.ForeColor = System.Drawing.Color.Transparent;
            this.MonthSold.Location = new System.Drawing.Point(178, 267);
            this.MonthSold.Name = "MonthSold";
            this.MonthSold.Size = new System.Drawing.Size(108, 22);
            this.MonthSold.TabIndex = 34;
            this.MonthSold.Text = "Month Sold:";
            // 
            // YearSold
            // 
            this.YearSold.AutoSize = true;
            this.YearSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YearSold.ForeColor = System.Drawing.Color.Transparent;
            this.YearSold.Location = new System.Drawing.Point(568, 268);
            this.YearSold.Name = "YearSold";
            this.YearSold.Size = new System.Drawing.Size(95, 22);
            this.YearSold.TabIndex = 33;
            this.YearSold.Text = "Year Sold:";
            // 
            // AmountSold
            // 
            this.AmountSold.AutoSize = true;
            this.AmountSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountSold.ForeColor = System.Drawing.Color.Transparent;
            this.AmountSold.Location = new System.Drawing.Point(549, 228);
            this.AmountSold.Name = "AmountSold";
            this.AmountSold.Size = new System.Drawing.Size(119, 22);
            this.AmountSold.TabIndex = 32;
            this.AmountSold.Text = "Amount Sold:";
            // 
            // AmountMade
            // 
            this.AmountMade.AutoSize = true;
            this.AmountMade.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountMade.ForeColor = System.Drawing.Color.Transparent;
            this.AmountMade.Location = new System.Drawing.Point(167, 228);
            this.AmountMade.Name = "AmountMade";
            this.AmountMade.Size = new System.Drawing.Size(127, 22);
            this.AmountMade.TabIndex = 31;
            this.AmountMade.Text = "Amount Made:";
            // 
            // SoldPrice
            // 
            this.SoldPrice.AutoSize = true;
            this.SoldPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoldPrice.ForeColor = System.Drawing.Color.Transparent;
            this.SoldPrice.Location = new System.Drawing.Point(568, 186);
            this.SoldPrice.Name = "SoldPrice";
            this.SoldPrice.Size = new System.Drawing.Size(100, 22);
            this.SoldPrice.TabIndex = 30;
            this.SoldPrice.Text = "Sold Price:";
            // 
            // CostItem
            // 
            this.CostItem.AutoSize = true;
            this.CostItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostItem.ForeColor = System.Drawing.Color.Transparent;
            this.CostItem.Location = new System.Drawing.Point(129, 187);
            this.CostItem.Name = "CostItem";
            this.CostItem.Size = new System.Drawing.Size(157, 22);
            this.CostItem.TabIndex = 29;
            this.CostItem.Text = "Item Cost to make:";
            // 
            // ItemName
            // 
            this.ItemName.AutoSize = true;
            this.ItemName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemName.ForeColor = System.Drawing.Color.Transparent;
            this.ItemName.Location = new System.Drawing.Point(568, 146);
            this.ItemName.Name = "ItemName";
            this.ItemName.Size = new System.Drawing.Size(101, 22);
            this.ItemName.TabIndex = 28;
            this.ItemName.Text = "Item Name:";
            // 
            // ItemId
            // 
            this.ItemId.AutoSize = true;
            this.ItemId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemId.ForeColor = System.Drawing.Color.Transparent;
            this.ItemId.Location = new System.Drawing.Point(215, 145);
            this.ItemId.Name = "ItemId";
            this.ItemId.Size = new System.Drawing.Size(71, 22);
            this.ItemId.TabIndex = 27;
            this.ItemId.Text = "Item Id:";
            // 
            // Amount_Made
            // 
            this.Amount_Made.Location = new System.Drawing.Point(314, 228);
            this.Amount_Made.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Amount_Made.Name = "Amount_Made";
            this.Amount_Made.Size = new System.Drawing.Size(178, 22);
            this.Amount_Made.TabIndex = 25;
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(451, 337);
            this.Input.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(267, 46);
            this.Input.TabIndex = 26;
            this.Input.Text = "Input Data";
            this.Input.UseVisualStyleBackColor = true;
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(676, 268);
            this.Year.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(178, 22);
            this.Year.TabIndex = 23;
            // 
            // Month
            // 
            this.Month.Location = new System.Drawing.Point(314, 268);
            this.Month.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(178, 22);
            this.Month.TabIndex = 22;
            // 
            // Selling_Price
            // 
            this.Selling_Price.Location = new System.Drawing.Point(676, 187);
            this.Selling_Price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Selling_Price.Name = "Selling_Price";
            this.Selling_Price.Size = new System.Drawing.Size(178, 22);
            this.Selling_Price.TabIndex = 21;
            // 
            // Amount_Item
            // 
            this.Amount_Item.Location = new System.Drawing.Point(676, 228);
            this.Amount_Item.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Amount_Item.Name = "Amount_Item";
            this.Amount_Item.Size = new System.Drawing.Size(178, 22);
            this.Amount_Item.TabIndex = 20;
            // 
            // Cost
            // 
            this.Cost.Location = new System.Drawing.Point(314, 187);
            this.Cost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(178, 22);
            this.Cost.TabIndex = 19;
            // 
            // Item_Name
            // 
            this.Item_Name.Location = new System.Drawing.Point(676, 146);
            this.Item_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Item_Name.Name = "Item_Name";
            this.Item_Name.Size = new System.Drawing.Size(178, 22);
            this.Item_Name.TabIndex = 18;
            // 
            // Item_Id
            // 
            this.Item_Id.Location = new System.Drawing.Point(314, 146);
            this.Item_Id.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Item_Id.Name = "Item_Id";
            this.Item_Id.Size = new System.Drawing.Size(178, 22);
            this.Item_Id.TabIndex = 24;
            // 
            // Input_Page
            // 
            this.Input_Page.AutoSize = true;
            this.Input_Page.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Input_Page.ForeColor = System.Drawing.Color.White;
            this.Input_Page.Location = new System.Drawing.Point(484, 68);
            this.Input_Page.Name = "Input_Page";
            this.Input_Page.Size = new System.Drawing.Size(195, 44);
            this.Input_Page.TabIndex = 17;
            this.Input_Page.Text = "Input Page";
            // 
            // Graph_Page
            // 
            this.Graph_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Graph_Page.Controls.Add(this.Graphpg);
            this.Graph_Page.Location = new System.Drawing.Point(202, 0);
            this.Graph_Page.Name = "Graph_Page";
            this.Graph_Page.Size = new System.Drawing.Size(1107, 482);
            this.Graph_Page.TabIndex = 36;
            // 
            // Graphpg
            // 
            this.Graphpg.AutoSize = true;
            this.Graphpg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graphpg.ForeColor = System.Drawing.Color.White;
            this.Graphpg.Location = new System.Drawing.Point(367, 9);
            this.Graphpg.Name = "Graphpg";
            this.Graphpg.Size = new System.Drawing.Size(209, 44);
            this.Graphpg.TabIndex = 18;
            this.Graphpg.Text = "Graph Page";
            // 
            // HomePg
            // 
            this.HomePg.AutoSize = true;
            this.HomePg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.HomePg.ForeColor = System.Drawing.Color.White;
            this.HomePg.Location = new System.Drawing.Point(300, 9);
            this.HomePg.Name = "HomePg";
            this.HomePg.Size = new System.Drawing.Size(457, 44);
            this.HomePg.TabIndex = 18;
            this.HomePg.Text = "Welcome to the Home Page";
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(520, 218);
            this.start.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(267, 46);
            this.start.TabIndex = 37;
            this.start.Text = "Start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Visible = false;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1306, 483);
            this.Controls.Add(this.start);
            this.Controls.Add(this.Graph_Page);
            this.Controls.Add(this.InputData);
            this.Controls.Add(this.HomePage);
            this.Controls.Add(this.Side1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Finance Tracker";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.Side1.ResumeLayout(false);
            this.FinancePanel.ResumeLayout(false);
            this.FinancePanel.PerformLayout();
            this.HomePage.ResumeLayout(false);
            this.HomePage.PerformLayout();
            this.InputData.ResumeLayout(false);
            this.InputData.PerformLayout();
            this.Graph_Page.ResumeLayout(false);
            this.Graph_Page.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel Side1;
        private System.Windows.Forms.Panel FinancePanel;
        private System.Windows.Forms.Button Home_Page;
        private System.Windows.Forms.Button DataInput;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Graph;
        private System.Windows.Forms.Label FinanceTracker;
        private System.Windows.Forms.Panel HomePage;
        private System.Windows.Forms.Panel InputData;
        private System.Windows.Forms.Label MonthSold;
        private System.Windows.Forms.Label YearSold;
        private System.Windows.Forms.Label AmountSold;
        private System.Windows.Forms.Label AmountMade;
        private System.Windows.Forms.Label SoldPrice;
        private System.Windows.Forms.Label CostItem;
        private System.Windows.Forms.Label ItemName;
        private System.Windows.Forms.Label ItemId;
        private System.Windows.Forms.TextBox Amount_Made;
        private System.Windows.Forms.Button Input;
        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.TextBox Month;
        private System.Windows.Forms.TextBox Selling_Price;
        private System.Windows.Forms.TextBox Amount_Item;
        private System.Windows.Forms.TextBox Cost;
        private System.Windows.Forms.TextBox Item_Name;
        private System.Windows.Forms.TextBox Item_Id;
        private System.Windows.Forms.Label Input_Page;
        private System.Windows.Forms.Panel Graph_Page;
        private System.Windows.Forms.Label HomePg;
        private System.Windows.Forms.Label Graphpg;
        private System.Windows.Forms.Button start;
    }
}

