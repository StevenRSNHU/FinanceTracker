﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
        }


        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void SignUp_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("server=127.0.0.1;user id=User; password = Password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            cmd.CommandText = "Insert into userinfo(firstName,lastName,username,password,email,zipCode,nameOfBusiness) Values('"  + First_Name.Text + "','" + Last_Name.Text + "','" + Username.Text + "','" + Password.Text + "','" + Email.Text + "','" + Convert.ToInt32(zipCode.Text) + "','" + Business.Text + "')"; // the command
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Account Created");
            con.Close();

        }

        private void Login_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Close();
        }


    }    
}
