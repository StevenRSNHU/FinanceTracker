﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
        }


        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void SignUp_Click(object sender, EventArgs e)
        {

            if (First_Name.Text.Length <= 0 || First_Name.Text.Length >= 31)
            {
                MessageBox.Show("Invaild Username: input username that is between 1 and 30 in length");
                First_Name.Text = "";
            }

            if (Last_Name.Text.Length <= 0 || Last_Name.Text.Length >= 31)
            {
                MessageBox.Show("Invaild Password: input Password that is between 1 and 30 in length");
                Last_Name.Text = "";
            }

            if (Username.Text.Length <= 0 || Username.Text.Length >= 31)
            {
                MessageBox.Show("Invaild Username: input username that is between 1 and 30 in length");
                Username.Text = "";
            }

            if (Password.Text.Length <= 0 || Password.Text.Length >= 31)
            {
                MessageBox.Show("Invaild Password: input Password that is between 1 and 30 in length");
                Password.Text = "";
            }

            if (Email.Text.Length <= 0 || Email.Text.Length >= 31)
            {
                MessageBox.Show("Invaild Email: input Email that is between 1 and 30 in length");
                Email.Text = "";
            }

            if (zipCode.Text.Length != 5)
            {
                MessageBox.Show("Invaild Zipcode : input the 5 digit Zipcode");
                zipCode.Text = "";
            }

            if (Business.Text.Length <= 0 || Business.Text.Length >= 31)
            {
                MessageBox.Show("Invaild Password: input Password that is between 1 and 30 in length");
                Business.Text = "";
            }
           

            else if(!((First_Name.Text.Length <= 0 || First_Name.Text.Length >= 31) || (Last_Name.Text.Length <= 0 || Last_Name.Text.Length >= 31) || (Username.Text.Length <= 0 || Username.Text.Length >= 31) || (Password.Text.Length <= 0 || Password.Text.Length >= 31) || (Email.Text.Length <= 0 || Email.Text.Length >= 31) || (zipCode.Text.Length != 5) || (zipCode.Text.Length != 5)) || (Business.Text.Length <= 0 || Business.Text.Length >= 31))
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=user; password = password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into userinfo(firstName,lastName,username,password,email,zipCode,nameOfBusiness) Values('" + First_Name.Text + "','" + Last_Name.Text + "','" + Username.Text + "','" + Password.Text + "','" + Email.Text + "','" + Convert.ToInt32(zipCode.Text) + "','" + Business.Text + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Account Created");
                con.Close();
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();

            }

        }

        private void Login_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void CompleteClose(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

    }    
}
