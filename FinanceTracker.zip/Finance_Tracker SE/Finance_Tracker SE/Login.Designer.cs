﻿namespace Software_Engineering_Project
{
    partial class Form2
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.Login = new System.Windows.Forms.Button();
            this.Username_Input = new System.Windows.Forms.TextBox();
            this.Password_Input = new System.Windows.Forms.TextBox();
            this.SignUp_Label = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.Finance_Tracker = new System.Windows.Forms.PictureBox();
            this.Username = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Finance_Tracker)).BeginInit();
            this.SuspendLayout();
            // 
            // Login
            // 
            this.Login.BackColor = System.Drawing.Color.White;
            this.Login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Login.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Login.ForeColor = System.Drawing.Color.Black;
            this.Login.Location = new System.Drawing.Point(288, 360);
            this.Login.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(302, 69);
            this.Login.TabIndex = 5;
            this.Login.Text = "Login";
            this.Login.UseVisualStyleBackColor = false;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // Username_Input
            // 
            this.Username_Input.Location = new System.Drawing.Point(288, 240);
            this.Username_Input.Name = "Username_Input";
            this.Username_Input.Size = new System.Drawing.Size(301, 30);
            this.Username_Input.TabIndex = 1;
            this.Username_Input.TextChanged += new System.EventHandler(this.Username_Input_TextChanged);
            // 
            // Password_Input
            // 
            this.Password_Input.Location = new System.Drawing.Point(287, 300);
            this.Password_Input.Name = "Password_Input";
            this.Password_Input.Size = new System.Drawing.Size(301, 30);
            this.Password_Input.TabIndex = 2;
            this.Password_Input.UseSystemPasswordChar = true;
            this.Password_Input.TextChanged += new System.EventHandler(this.Password_Input_TextChanged);
            // 
            // SignUp_Label
            // 
            this.SignUp_Label.ActiveLinkColor = System.Drawing.Color.DimGray;
            this.SignUp_Label.AutoSize = true;
            this.SignUp_Label.BackColor = System.Drawing.Color.Transparent;
            this.SignUp_Label.ForeColor = System.Drawing.Color.White;
            this.SignUp_Label.Location = new System.Drawing.Point(484, 437);
            this.SignUp_Label.Name = "SignUp_Label";
            this.SignUp_Label.Size = new System.Drawing.Size(73, 22);
            this.SignUp_Label.TabIndex = 4;
            this.SignUp_Label.TabStop = true;
            this.SignUp_Label.Text = "Sign Up";
            this.SignUp_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SignUp_Label_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(287, 437);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Don\'t have an Account? ";
            // 
            // Finance_Tracker
            // 
            this.Finance_Tracker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Finance_Tracker.Cursor = System.Windows.Forms.Cursors.Default;
            this.Finance_Tracker.Image = ((System.Drawing.Image)(resources.GetObject("Finance_Tracker.Image")));
            this.Finance_Tracker.Location = new System.Drawing.Point(223, 20);
            this.Finance_Tracker.Name = "Finance_Tracker";
            this.Finance_Tracker.Size = new System.Drawing.Size(436, 194);
            this.Finance_Tracker.TabIndex = 6;
            this.Finance_Tracker.TabStop = false;
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username.Location = new System.Drawing.Point(157, 240);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(114, 27);
            this.Username.TabIndex = 8;
            this.Username.Text = "Username:";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.Location = new System.Drawing.Point(157, 303);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(110, 27);
            this.Password.TabIndex = 9;
            this.Password.Text = "Password:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(882, 549);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.Finance_Tracker);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SignUp_Label);
            this.Controls.Add(this.Password_Input);
            this.Controls.Add(this.Username_Input);
            this.Controls.Add(this.Login);
            this.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.ForeColor = System.Drawing.Color.White;
            this.Location = new System.Drawing.Point(960, 520);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form2";
            this.Text = "Finance Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompleteClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Finance_Tracker)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.TextBox Username_Input;
        private System.Windows.Forms.TextBox Password_Input;
        private System.Windows.Forms.LinkLabel SignUp_Label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Finance_Tracker;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Label Password;
    }
}

