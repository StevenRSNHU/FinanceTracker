﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Login.PerformClick();
        }

        private void Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Page_Click(object sender, EventArgs e)
        {
            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
        }

        private void DataInput_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = true;
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = true;
            InputData.Visible = false;

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Input_Click(object sender, EventArgs e)
        {

            MySqlConnection con = new MySqlConnection("server=127.0.0.1;user id= User; password = Password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            cmd.CommandText = "Insert into item(name,costToMake,sellingPrice,AmountSold,MonthAndYear) Values('" + ItemName.Text + "','" + Convert.ToDouble(Cost.Text) + "','" + Convert.ToDouble(Selling_Price.Text) + "','" + AmountSold.Text + "','" + Month.Text + Year.Text + "')"; // the command
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Save Sucess");
            con.Close();
        }

        private void Graph_Page_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void FinancePanel_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Login_Click(object sender, EventArgs e)
        {

            Form2 otherForm = new Form2();
            otherForm.FormClosed += new FormClosedEventHandler(otherForm_FormClosed);
            this.Hide();
            otherForm.Show();
            Login.Visible = false;

        }
        void otherForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Login.Visible == false)
            {
                this.Show();
            }
        }

        private void Item_Name_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
