﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;

 
            
        }

        private void Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Page_Click(object sender, EventArgs e)
        {
            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
        }

        private void DataInput_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = true;
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = true;
            InputData.Visible = false;
            
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Graph_Page_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void FinancePanel_Paint(object sender, PaintEventArgs e)
        {
            
        }


        private void Item_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Input_Click_1(object sender, EventArgs e)
        {
            //Checks inputs
            if (ItemId.Text.Length <= 0 )
            {
                MessageBox.Show("Item ID: Is Required");
                ItemId.Text = "";
            }
            if ((ItemName.Text.Length >= 31 )|| (ItemName.Text.Length <= 0) )
            {
                MessageBox.Show("Invalid ItemName length plz input item name with 30 chars or less");
                ItemName.Text = "";
            }

            if  (Cost.Text.Length <= 0)
            {
                MessageBox.Show("Cost: Is Required");
                Cost.Text = "";
            }

            if (Selling_Price.Text.Length <= 0)
            {
                MessageBox.Show("Selling Price: Is Required");
                Selling_Price.Text = "";
            }

            if (Amount_Sold.Text.Length <= 0)
            {
                MessageBox.Show("Amount Sold: Is Required");
                Amount_Sold.Text = "";
            }

            if (Amount_Made.Text.Length <= 0)
            {
                MessageBox.Show("Amount Made: Is Required");
                Amount_Made.Text = "";
            }

            if (Month.Text.Length <= 0 || Month.Text.Length >= 31 || Convert.ToInt32(Month.Text) >=13 || Convert.ToInt32(Month.Text) <= 0)
            {
                MessageBox.Show("Month: Input the month in a valid range between 0 and 30 in length or a numer between 1 and 12");
                Cost.Text = "";
            }

            if (Year.Text.Length <= 0)
            {
                MessageBox.Show("Year: Is Required");
                Selling_Price.Text = "";
            }
            else if(!(((ItemName.Text.Length >= 31) || (ItemName.Text.Length <= 0)) || (Cost.Text.Length <= 0) || (Selling_Price.Text.Length <= 0) || (Amount_Sold.Text.Length <= 0) || (Amount_Made.Text.Length <= 0) || (Month.Text.Length <= 0 || Month.Text.Length >= 31 || Convert.ToInt32(Month.Text) >= 13 || Convert.ToInt32(Month.Text) <= 0)))
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=user; password = password; persistsecurityinfo=True;database=Finance_Tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into item(id,name,costToMake,sellingPrice,AmountSold,AmountMade,Month,Year) Values('" + ItemId.Text + "','" + ItemName.Text + "','" + Convert.ToDouble(Cost.Text) + "','" + Convert.ToDouble(Selling_Price.Text) + "','" + Amount_Sold.Text + "','" + Amount_Made.Text + "','" + Month.Text + "','" + Year.Text + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data has been Inputed");
                con.Close();

            }
        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }

}
