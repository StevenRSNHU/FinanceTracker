﻿namespace Finance_Tracker_SE
{
    partial class Item_Part_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemPartViewLbl = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.partId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costOfPart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // itemPartViewLbl
            // 
            this.itemPartViewLbl.AutoSize = true;
            this.itemPartViewLbl.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemPartViewLbl.ForeColor = System.Drawing.Color.Transparent;
            this.itemPartViewLbl.Location = new System.Drawing.Point(246, 26);
            this.itemPartViewLbl.Name = "itemPartViewLbl";
            this.itemPartViewLbl.Size = new System.Drawing.Size(171, 31);
            this.itemPartViewLbl.TabIndex = 0;
            this.itemPartViewLbl.Text = "Item Part Info ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(32)))), ((int)(((byte)(53)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.partId,
            this.itemId,
            this.itemName,
            this.partName,
            this.costOfPart});
            this.dataGridView1.Location = new System.Drawing.Point(36, 83);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(616, 315);
            this.dataGridView1.TabIndex = 1;
            // 
            // partId
            // 
            this.partId.HeaderText = "Part ID";
            this.partId.Name = "partId";
            this.partId.ReadOnly = true;
            // 
            // itemId
            // 
            this.itemId.HeaderText = "Item ID";
            this.itemId.Name = "itemId";
            this.itemId.ReadOnly = true;
            // 
            // itemName
            // 
            this.itemName.HeaderText = "Name of Item";
            this.itemName.Name = "itemName";
            this.itemName.ReadOnly = true;
            // 
            // partName
            // 
            this.partName.HeaderText = "Name of Part";
            this.partName.Name = "partName";
            this.partName.ReadOnly = true;
            // 
            // costOfPart
            // 
            this.costOfPart.HeaderText = "Cost of Part";
            this.costOfPart.Name = "costOfPart";
            this.costOfPart.ReadOnly = true;
            // 
            // Item_Part_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(32)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(693, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.itemPartViewLbl);
            this.Name = "Item_Part_View";
            this.Text = "Item_Part_View";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label itemPartViewLbl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn partId;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemId;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn partName;
        private System.Windows.Forms.DataGridViewTextBoxColumn costOfPart;
    }
}