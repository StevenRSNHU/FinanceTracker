﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Finance_Tracker_SE;
using Finance_Tracker_SE.Resources;
using Software_Engineering_Project;

namespace Finance_Tracker_SE
{
    public partial class Item_Part_View : Form
    {
        public Item_Part_View()
        {
            InitializeComponent();
        }
        int userId = Form2.userID;

    }
}
