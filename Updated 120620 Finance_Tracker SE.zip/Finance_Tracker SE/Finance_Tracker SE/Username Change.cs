﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Finance_Tracker_SE;
using Finance_Tracker_SE.Resources;
using Software_Engineering_Project;


namespace Finance_Tracker_SE
{
    public partial class Username_Change : Form
    {
        public Username_Change()
        {
            InitializeComponent();
        }
        int userId = Form2.userID;

        private void changeUsername_Click(object sender, EventArgs e)
        {

            if (newUsername.Text.Length <= 0 || newUsername.Text.Length >= 31 || confirmUsername.Text != confirmUsername.Text || password.Text.Length <= 0 || password.Text.Length >= 31)
            {
                if (confirmUsername.Text != newUsername.Text)
                {
                    username_Confirm.Text = ("* Usernames Do Not Match");
                    confirmUsername.Text = "";

                }
                else
                {
                    usMark.Text = ("* Invaild Username: input Username that is between 1 and 30 in length");
                    newUsername.Text = "";
                }
            }
            if (password.Text == "")
            {
                passMark.Text = "* Requires Password";
            }
            else if (!(newUsername.Text.Length <= 0 || newUsername.Text.Length >= 31 || confirmUsername.Text != confirmUsername.Text || password.Text.Length <= 0 || password.Text.Length >= 31))
            {
                {
                    MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                    MySqlCommand cmd = new MySqlCommand(); //makes cmd
                    cmd.Connection = con; // makes command connection to con
                    MySqlDataReader dRead; // to read the data base
                    string password1 = " ";
                    con.Open(); // opens connection

                    cmd.CommandText = "SELECT password FROM userinfo where id='" + userId + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {
                            password1 = Convert.ToString(dRead.GetValue(0).ToString());
                        }
                    }
                    con.Close();
                    dRead.Close();
                    if (password.Text == password1)
                    {
                            cmd.Connection = con; // makes command connection to con
                            cmd.CommandText = "update userinfo SET username ='" + newUsername.Text + "' Where id ='" + userId + "' AND password = '" + password.Text + "'"; // the command

                            con.Open();
                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Username Changed");

                            con.Close();
                            this.Close();   
                    }

                    else
                    {
                        passMark.Text = "* Incorrect Password";
                    }
                }
            }

        }

        private void Username_Change_Load(object sender, EventArgs e)
        {

        }
    }
}
