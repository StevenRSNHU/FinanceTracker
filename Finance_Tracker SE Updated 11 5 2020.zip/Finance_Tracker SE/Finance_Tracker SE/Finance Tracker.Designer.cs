﻿namespace Software_Engineering_Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Side1 = new System.Windows.Forms.Panel();
            this.Exit = new System.Windows.Forms.Button();
            this.FinancePanel = new System.Windows.Forms.Panel();
            this.FinanceTracker = new System.Windows.Forms.Label();
            this.HomePage = new System.Windows.Forms.Panel();
            this.HomePg = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.Panel();
            this.itemInfoPanel = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costToMakeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellingPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountSoldDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountMadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.monthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet2 = new Finance_Tracker_SE.finance_trackerDataSet2();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Searchlabel = new System.Windows.Forms.Label();
            this.itemPartPanel = new System.Windows.Forms.Panel();
            this.itemSearchLbl = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.partIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partArrival = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itempartBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet3 = new Finance_Tracker_SE.finance_trackerDataSet3();
            this.profitSalesPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.profitSalesBttn = new System.Windows.Forms.Button();
            this.itemPartsBttn = new System.Windows.Forms.Button();
            this.itemInfoBttn = new System.Windows.Forms.Button();
            this.Data_Search = new System.Windows.Forms.Label();
            this.itempartBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet1 = new Finance_Tracker_SE.finance_trackerDataSet1();
            this.Profile_Page = new System.Windows.Forms.Panel();
            this.Profilelab = new System.Windows.Forms.Label();
            this.itempartTableAdapter = new Finance_Tracker_SE.finance_trackerDataSet1TableAdapters.itempartTableAdapter();
            this.itemTableAdapter1 = new Finance_Tracker_SE.finance_trackerDataSet2TableAdapters.itemTableAdapter();
            this.itempartTableAdapter1 = new Finance_Tracker_SE.finance_trackerDataSet3TableAdapters.itempartTableAdapter();
            this.itemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet = new Finance_Tracker_SE.finance_trackerDataSet();
            this.itemTableAdapter = new Finance_Tracker_SE.finance_trackerDataSetTableAdapters.itemTableAdapter();
            this.Graph_Page = new System.Windows.Forms.Panel();
            this.YearGraphBttn = new System.Windows.Forms.Button();
            this.MonthGraphBttn = new System.Windows.Forms.Button();
            this.GraphData = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Graphpg = new System.Windows.Forms.Label();
            this.InputData = new System.Windows.Forms.Panel();
            this.input_MD = new System.Windows.Forms.Panel();
            this.costMark = new System.Windows.Forms.Label();
            this.mainInput = new System.Windows.Forms.Button();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.weekDatelb = new System.Windows.Forms.Label();
            this.weekSaleslb = new System.Windows.Forms.Label();
            this.weekSales = new System.Windows.Forms.TextBox();
            this.saleMark = new System.Windows.Forms.Label();
            this.weekCostlb = new System.Windows.Forms.Label();
            this.weekCost = new System.Windows.Forms.TextBox();
            this.itemInputPanel = new System.Windows.Forms.Panel();
            this.MonthSold = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Amount_Made = new System.Windows.Forms.TextBox();
            this.dataAdded = new System.Windows.Forms.Label();
            this.Item_Id = new System.Windows.Forms.TextBox();
            this.Item_Name = new System.Windows.Forms.TextBox();
            this.dateMark = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.TextBox();
            this.asMark = new System.Windows.Forms.Label();
            this.Amount_Sold = new System.Windows.Forms.TextBox();
            this.amMark = new System.Windows.Forms.Label();
            this.Selling_Price = new System.Windows.Forms.TextBox();
            this.spMark = new System.Windows.Forms.Label();
            this.ictmMark = new System.Windows.Forms.Label();
            this.inMark = new System.Windows.Forms.Label();
            this.Input = new System.Windows.Forms.Button();
            this.idMark = new System.Windows.Forms.Label();
            this.ItemId = new System.Windows.Forms.Label();
            this.ItemName = new System.Windows.Forms.Label();
            this.CostItem = new System.Windows.Forms.Label();
            this.AmountSold = new System.Windows.Forms.Label();
            this.SoldPrice = new System.Windows.Forms.Label();
            this.AmountMade = new System.Windows.Forms.Label();
            this.partInputPanel = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.NumOfPartsInput = new System.Windows.Forms.TextBox();
            this.partDataAdded = new System.Windows.Forms.Label();
            this.inputPartBttn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PartName = new System.Windows.Forms.TextBox();
            this.ItemNameInput = new System.Windows.Forms.TextBox();
            this.PartCost = new System.Windows.Forms.TextBox();
            this.PartId = new System.Windows.Forms.TextBox();
            this.ItemIdInput = new System.Windows.Forms.TextBox();
            this.mainInput_Button = new System.Windows.Forms.Button();
            this.InputPartInfoBttn = new System.Windows.Forms.Button();
            this.InputItemInfoBttn = new System.Windows.Forms.Button();
            this.Input_Page = new System.Windows.Forms.Label();
            this.Profile = new System.Windows.Forms.Button();
            this.DataPage = new System.Windows.Forms.Button();
            this.Graph = new System.Windows.Forms.Button();
            this.DataInput = new System.Windows.Forms.Button();
            this.Home_Page = new System.Windows.Forms.Button();
            this.Side1.SuspendLayout();
            this.FinancePanel.SuspendLayout();
            this.HomePage.SuspendLayout();
            this.Data.SuspendLayout();
            this.itemInfoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet2)).BeginInit();
            this.itemPartPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itempartBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet3)).BeginInit();
            this.profitSalesPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itempartBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet1)).BeginInit();
            this.Profile_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet)).BeginInit();
            this.Graph_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GraphData)).BeginInit();
            this.InputData.SuspendLayout();
            this.input_MD.SuspendLayout();
            this.itemInputPanel.SuspendLayout();
            this.partInputPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Side1
            // 
            this.Side1.BackColor = System.Drawing.Color.Transparent;
            this.Side1.Controls.Add(this.Profile);
            this.Side1.Controls.Add(this.DataPage);
            this.Side1.Controls.Add(this.Exit);
            this.Side1.Controls.Add(this.Graph);
            this.Side1.Controls.Add(this.DataInput);
            this.Side1.Controls.Add(this.Home_Page);
            this.Side1.Controls.Add(this.FinancePanel);
            this.Side1.Location = new System.Drawing.Point(0, 0);
            this.Side1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Side1.Name = "Side1";
            this.Side1.Size = new System.Drawing.Size(199, 773);
            this.Side1.TabIndex = 1;
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Exit.Location = new System.Drawing.Point(3, 657);
            this.Exit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(116, 114);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "Exit";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            this.Exit.MouseLeave += new System.EventHandler(this.Exit_MouseLeave);
            this.Exit.MouseHover += new System.EventHandler(this.Exit_MouseHover);
            // 
            // FinancePanel
            // 
            this.FinancePanel.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.FinancePanel.Controls.Add(this.FinanceTracker);
            this.FinancePanel.Location = new System.Drawing.Point(0, 0);
            this.FinancePanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FinancePanel.Name = "FinancePanel";
            this.FinancePanel.Size = new System.Drawing.Size(199, 74);
            this.FinancePanel.TabIndex = 0;
            this.FinancePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.FinancePanel_Paint);
            // 
            // FinanceTracker
            // 
            this.FinanceTracker.AutoSize = true;
            this.FinanceTracker.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.FinanceTracker.ForeColor = System.Drawing.Color.White;
            this.FinanceTracker.Location = new System.Drawing.Point(11, 14);
            this.FinanceTracker.Name = "FinanceTracker";
            this.FinanceTracker.Size = new System.Drawing.Size(179, 28);
            this.FinanceTracker.TabIndex = 0;
            this.FinanceTracker.Text = "Finance Tracker";
            // 
            // HomePage
            // 
            this.HomePage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.HomePage.Controls.Add(this.HomePg);
            this.HomePage.Location = new System.Drawing.Point(201, 0);
            this.HomePage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.HomePage.Name = "HomePage";
            this.HomePage.Size = new System.Drawing.Size(1107, 773);
            this.HomePage.TabIndex = 2;
            // 
            // HomePg
            // 
            this.HomePg.AutoSize = true;
            this.HomePg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.HomePg.ForeColor = System.Drawing.Color.White;
            this.HomePg.Location = new System.Drawing.Point(300, 9);
            this.HomePg.Name = "HomePg";
            this.HomePg.Size = new System.Drawing.Size(457, 44);
            this.HomePg.TabIndex = 18;
            this.HomePg.Text = "Welcome to the Home Page";
            // 
            // Data
            // 
            this.Data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Data.Controls.Add(this.itemInfoPanel);
            this.Data.Controls.Add(this.itemPartPanel);
            this.Data.Controls.Add(this.profitSalesPanel);
            this.Data.Controls.Add(this.profitSalesBttn);
            this.Data.Controls.Add(this.itemPartsBttn);
            this.Data.Controls.Add(this.itemInfoBttn);
            this.Data.Controls.Add(this.Data_Search);
            this.Data.Location = new System.Drawing.Point(202, 0);
            this.Data.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(1105, 773);
            this.Data.TabIndex = 37;
            this.Data.Paint += new System.Windows.Forms.PaintEventHandler(this.Data_Paint);
            // 
            // itemInfoPanel
            // 
            this.itemInfoPanel.Controls.Add(this.dataGridView1);
            this.itemInfoPanel.Controls.Add(this.richTextBox1);
            this.itemInfoPanel.Controls.Add(this.Searchlabel);
            this.itemInfoPanel.Location = new System.Drawing.Point(48, 153);
            this.itemInfoPanel.Margin = new System.Windows.Forms.Padding(4);
            this.itemInfoPanel.Name = "itemInfoPanel";
            this.itemInfoPanel.Size = new System.Drawing.Size(1001, 576);
            this.itemInfoPanel.TabIndex = 29;
            this.itemInfoPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.itemInfoPanel_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.costToMakeDataGridViewTextBoxColumn,
            this.sellingPriceDataGridViewTextBoxColumn,
            this.amountSoldDataGridViewTextBoxColumn,
            this.amountMadeDataGridViewTextBoxColumn,
            this.monthDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.itemBindingSource1;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(4, 53);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(997, 556);
            this.dataGridView1.TabIndex = 19;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "itemName";
            this.dataGridViewTextBoxColumn1.HeaderText = "Name";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // costToMakeDataGridViewTextBoxColumn
            // 
            this.costToMakeDataGridViewTextBoxColumn.DataPropertyName = "costToMake";
            this.costToMakeDataGridViewTextBoxColumn.HeaderText = "Cost to Make";
            this.costToMakeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.costToMakeDataGridViewTextBoxColumn.Name = "costToMakeDataGridViewTextBoxColumn";
            this.costToMakeDataGridViewTextBoxColumn.ReadOnly = true;
            this.costToMakeDataGridViewTextBoxColumn.Width = 125;
            // 
            // sellingPriceDataGridViewTextBoxColumn
            // 
            this.sellingPriceDataGridViewTextBoxColumn.DataPropertyName = "sellingPrice";
            this.sellingPriceDataGridViewTextBoxColumn.HeaderText = "Selling Price";
            this.sellingPriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sellingPriceDataGridViewTextBoxColumn.Name = "sellingPriceDataGridViewTextBoxColumn";
            this.sellingPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.sellingPriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountSoldDataGridViewTextBoxColumn
            // 
            this.amountSoldDataGridViewTextBoxColumn.DataPropertyName = "AmountSold";
            this.amountSoldDataGridViewTextBoxColumn.HeaderText = "Amount Sold";
            this.amountSoldDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountSoldDataGridViewTextBoxColumn.Name = "amountSoldDataGridViewTextBoxColumn";
            this.amountSoldDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountSoldDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountMadeDataGridViewTextBoxColumn
            // 
            this.amountMadeDataGridViewTextBoxColumn.DataPropertyName = "AmountMade";
            this.amountMadeDataGridViewTextBoxColumn.HeaderText = "Amount Made";
            this.amountMadeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountMadeDataGridViewTextBoxColumn.Name = "amountMadeDataGridViewTextBoxColumn";
            this.amountMadeDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountMadeDataGridViewTextBoxColumn.Width = 125;
            // 
            // monthDataGridViewTextBoxColumn
            // 
            this.monthDataGridViewTextBoxColumn.DataPropertyName = "Month";
            this.monthDataGridViewTextBoxColumn.HeaderText = "Month";
            this.monthDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.monthDataGridViewTextBoxColumn.Name = "monthDataGridViewTextBoxColumn";
            this.monthDataGridViewTextBoxColumn.ReadOnly = true;
            this.monthDataGridViewTextBoxColumn.Width = 125;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.ReadOnly = true;
            this.yearDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemBindingSource1
            // 
            this.itemBindingSource1.DataMember = "item";
            this.itemBindingSource1.DataSource = this.finance_trackerDataSet2;
            // 
            // finance_trackerDataSet2
            // 
            this.finance_trackerDataSet2.DataSetName = "finance_trackerDataSet2";
            this.finance_trackerDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(693, 7);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(304, 26);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Searchlabel
            // 
            this.Searchlabel.AutoSize = true;
            this.Searchlabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchlabel.ForeColor = System.Drawing.Color.White;
            this.Searchlabel.Location = new System.Drawing.Point(577, 4);
            this.Searchlabel.Name = "Searchlabel";
            this.Searchlabel.Size = new System.Drawing.Size(104, 32);
            this.Searchlabel.TabIndex = 24;
            this.Searchlabel.Text = "Search:";
            this.Searchlabel.Click += new System.EventHandler(this.Searchlabel_Click);
            // 
            // itemPartPanel
            // 
            this.itemPartPanel.Controls.Add(this.itemSearchLbl);
            this.itemPartPanel.Controls.Add(this.richTextBox2);
            this.itemPartPanel.Controls.Add(this.dataGridView2);
            this.itemPartPanel.Location = new System.Drawing.Point(47, 151);
            this.itemPartPanel.Margin = new System.Windows.Forms.Padding(4);
            this.itemPartPanel.Name = "itemPartPanel";
            this.itemPartPanel.Size = new System.Drawing.Size(1003, 578);
            this.itemPartPanel.TabIndex = 30;
            this.itemPartPanel.Visible = false;
            // 
            // itemSearchLbl
            // 
            this.itemSearchLbl.AutoSize = true;
            this.itemSearchLbl.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemSearchLbl.ForeColor = System.Drawing.Color.White;
            this.itemSearchLbl.Location = new System.Drawing.Point(577, 1);
            this.itemSearchLbl.Name = "itemSearchLbl";
            this.itemSearchLbl.Size = new System.Drawing.Size(104, 32);
            this.itemSearchLbl.TabIndex = 26;
            this.itemSearchLbl.Text = "Search:";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(693, 5);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(304, 26);
            this.richTextBox2.TabIndex = 25;
            this.richTextBox2.Text = "";
            this.richTextBox2.TextChanged += new System.EventHandler(this.richTextBox2_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.partIdDataGridViewTextBoxColumn,
            this.itemIdDataGridViewTextBoxColumn,
            this.itemNameDataGridViewTextBoxColumn,
            this.partNameDataGridViewTextBoxColumn,
            this.partCostDataGridViewTextBoxColumn,
            this.partArrival});
            this.dataGridView2.DataSource = this.itempartBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(0, 48);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(999, 559);
            this.dataGridView2.TabIndex = 0;
            // 
            // partIdDataGridViewTextBoxColumn
            // 
            this.partIdDataGridViewTextBoxColumn.DataPropertyName = "partId";
            this.partIdDataGridViewTextBoxColumn.HeaderText = "Part ID";
            this.partIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.partIdDataGridViewTextBoxColumn.Name = "partIdDataGridViewTextBoxColumn";
            this.partIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.partIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemIdDataGridViewTextBoxColumn
            // 
            this.itemIdDataGridViewTextBoxColumn.DataPropertyName = "itemId";
            this.itemIdDataGridViewTextBoxColumn.HeaderText = "Item ID";
            this.itemIdDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.itemIdDataGridViewTextBoxColumn.Name = "itemIdDataGridViewTextBoxColumn";
            this.itemIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemIdDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemNameDataGridViewTextBoxColumn
            // 
            this.itemNameDataGridViewTextBoxColumn.DataPropertyName = "itemName";
            this.itemNameDataGridViewTextBoxColumn.HeaderText = "Name of Item";
            this.itemNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.itemNameDataGridViewTextBoxColumn.Name = "itemNameDataGridViewTextBoxColumn";
            this.itemNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // partNameDataGridViewTextBoxColumn
            // 
            this.partNameDataGridViewTextBoxColumn.DataPropertyName = "partName";
            this.partNameDataGridViewTextBoxColumn.HeaderText = "Name of Part";
            this.partNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.partNameDataGridViewTextBoxColumn.Name = "partNameDataGridViewTextBoxColumn";
            this.partNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.partNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // partCostDataGridViewTextBoxColumn
            // 
            this.partCostDataGridViewTextBoxColumn.DataPropertyName = "partCost";
            this.partCostDataGridViewTextBoxColumn.HeaderText = "Cost of Part";
            this.partCostDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.partCostDataGridViewTextBoxColumn.Name = "partCostDataGridViewTextBoxColumn";
            this.partCostDataGridViewTextBoxColumn.ReadOnly = true;
            this.partCostDataGridViewTextBoxColumn.Width = 125;
            // 
            // partArrival
            // 
            this.partArrival.DataPropertyName = "partArrival";
            this.partArrival.HeaderText = "Delivery Date";
            this.partArrival.MinimumWidth = 6;
            this.partArrival.Name = "partArrival";
            this.partArrival.ReadOnly = true;
            this.partArrival.Width = 125;
            // 
            // itempartBindingSource1
            // 
            this.itempartBindingSource1.DataMember = "itempart";
            this.itempartBindingSource1.DataSource = this.finance_trackerDataSet3;
            // 
            // finance_trackerDataSet3
            // 
            this.finance_trackerDataSet3.DataSetName = "finance_trackerDataSet3";
            this.finance_trackerDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // profitSalesPanel
            // 
            this.profitSalesPanel.Controls.Add(this.label2);
            this.profitSalesPanel.Location = new System.Drawing.Point(47, 154);
            this.profitSalesPanel.Margin = new System.Windows.Forms.Padding(4);
            this.profitSalesPanel.Name = "profitSalesPanel";
            this.profitSalesPanel.Size = new System.Drawing.Size(1003, 576);
            this.profitSalesPanel.TabIndex = 31;
            this.profitSalesPanel.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(31, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "profits / sales panel add datagridview for table";
            // 
            // profitSalesBttn
            // 
            this.profitSalesBttn.Location = new System.Drawing.Point(0, 0);
            this.profitSalesBttn.Name = "profitSalesBttn";
            this.profitSalesBttn.Size = new System.Drawing.Size(75, 23);
            this.profitSalesBttn.TabIndex = 32;
            // 
            // itemPartsBttn
            // 
            this.itemPartsBttn.Location = new System.Drawing.Point(0, 0);
            this.itemPartsBttn.Name = "itemPartsBttn";
            this.itemPartsBttn.Size = new System.Drawing.Size(75, 23);
            this.itemPartsBttn.TabIndex = 33;
            // 
            // itemInfoBttn
            // 
            this.itemInfoBttn.Location = new System.Drawing.Point(0, 0);
            this.itemInfoBttn.Name = "itemInfoBttn";
            this.itemInfoBttn.Size = new System.Drawing.Size(75, 23);
            this.itemInfoBttn.TabIndex = 34;
            // 
            // Data_Search
            // 
            this.Data_Search.AutoSize = true;
            this.Data_Search.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Data_Search.ForeColor = System.Drawing.Color.White;
            this.Data_Search.Location = new System.Drawing.Point(300, 9);
            this.Data_Search.Name = "Data_Search";
            this.Data_Search.Size = new System.Drawing.Size(436, 44);
            this.Data_Search.TabIndex = 18;
            this.Data_Search.Text = "Welcome to the Data Page";
            // 
            // itempartBindingSource
            // 
            this.itempartBindingSource.DataMember = "itempart";
            this.itempartBindingSource.DataSource = this.finance_trackerDataSet1;
            // 
            // finance_trackerDataSet1
            // 
            this.finance_trackerDataSet1.DataSetName = "finance_trackerDataSet1";
            this.finance_trackerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Profile_Page
            // 
            this.Profile_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Profile_Page.Controls.Add(this.Profilelab);
            this.Profile_Page.Location = new System.Drawing.Point(203, 0);
            this.Profile_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Profile_Page.Name = "Profile_Page";
            this.Profile_Page.Size = new System.Drawing.Size(1107, 773);
            this.Profile_Page.TabIndex = 39;
            // 
            // Profilelab
            // 
            this.Profilelab.AutoSize = true;
            this.Profilelab.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Profilelab.ForeColor = System.Drawing.Color.White;
            this.Profilelab.Location = new System.Drawing.Point(300, 9);
            this.Profilelab.Name = "Profilelab";
            this.Profilelab.Size = new System.Drawing.Size(492, 44);
            this.Profilelab.TabIndex = 18;
            this.Profilelab.Text = "Welcome to your Profile Page";
            // 
            // itempartTableAdapter
            // 
            this.itempartTableAdapter.ClearBeforeFill = true;
            // 
            // itemTableAdapter1
            // 
            this.itemTableAdapter1.ClearBeforeFill = true;
            // 
            // itempartTableAdapter1
            // 
            this.itempartTableAdapter1.ClearBeforeFill = true;
            // 
            // itemBindingSource
            // 
            this.itemBindingSource.DataMember = "item";
            this.itemBindingSource.DataSource = this.finance_trackerDataSet;
            // 
            // finance_trackerDataSet
            // 
            this.finance_trackerDataSet.DataSetName = "finance_trackerDataSet";
            this.finance_trackerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemTableAdapter
            // 
            this.itemTableAdapter.ClearBeforeFill = true;
            // 
            // Graph_Page
            // 
            this.Graph_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Graph_Page.Controls.Add(this.YearGraphBttn);
            this.Graph_Page.Controls.Add(this.MonthGraphBttn);
            this.Graph_Page.Controls.Add(this.GraphData);
            this.Graph_Page.Controls.Add(this.Graphpg);
            this.Graph_Page.Location = new System.Drawing.Point(203, 0);
            this.Graph_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Graph_Page.Name = "Graph_Page";
            this.Graph_Page.Size = new System.Drawing.Size(1107, 771);
            this.Graph_Page.TabIndex = 41;
            // 
            // YearGraphBttn
            // 
            this.YearGraphBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.YearGraphBttn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.YearGraphBttn.FlatAppearance.BorderSize = 0;
            this.YearGraphBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.YearGraphBttn.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YearGraphBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.YearGraphBttn.Location = new System.Drawing.Point(572, 706);
            this.YearGraphBttn.Margin = new System.Windows.Forms.Padding(4);
            this.YearGraphBttn.Name = "YearGraphBttn";
            this.YearGraphBttn.Size = new System.Drawing.Size(144, 43);
            this.YearGraphBttn.TabIndex = 2;
            this.YearGraphBttn.Text = "Yearly";
            this.YearGraphBttn.UseVisualStyleBackColor = false;
            this.YearGraphBttn.Click += new System.EventHandler(this.YearGraphBttn_Click_1);
            // 
            // MonthGraphBttn
            // 
            this.MonthGraphBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MonthGraphBttn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MonthGraphBttn.FlatAppearance.BorderSize = 0;
            this.MonthGraphBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MonthGraphBttn.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonthGraphBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.MonthGraphBttn.Location = new System.Drawing.Point(384, 706);
            this.MonthGraphBttn.Margin = new System.Windows.Forms.Padding(4);
            this.MonthGraphBttn.Name = "MonthGraphBttn";
            this.MonthGraphBttn.Size = new System.Drawing.Size(144, 43);
            this.MonthGraphBttn.TabIndex = 1;
            this.MonthGraphBttn.Text = "Monthly";
            this.MonthGraphBttn.UseVisualStyleBackColor = false;
            this.MonthGraphBttn.Click += new System.EventHandler(this.MonthGraphBttn_Click_1);
            // 
            // GraphData
            // 
            chartArea1.Name = "ChartArea1";
            this.GraphData.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.GraphData.Legends.Add(legend1);
            this.GraphData.Location = new System.Drawing.Point(41, 105);
            this.GraphData.Margin = new System.Windows.Forms.Padding(4);
            this.GraphData.Name = "GraphData";
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.Maroon;
            series1.Legend = "Legend1";
            series1.Name = "Costs";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
            series2.ChartArea = "ChartArea1";
            series2.Color = System.Drawing.Color.Teal;
            series2.Legend = "Legend1";
            series2.Name = "Sales";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
            series3.ChartArea = "ChartArea1";
            series3.Color = System.Drawing.Color.Green;
            series3.Legend = "Legend1";
            series3.Name = "Profit";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
            this.GraphData.Series.Add(series1);
            this.GraphData.Series.Add(series2);
            this.GraphData.Series.Add(series3);
            this.GraphData.Size = new System.Drawing.Size(1029, 569);
            this.GraphData.TabIndex = 19;
            this.GraphData.Text = "chart1";
            this.GraphData.Click += new System.EventHandler(this.GraphData_Click_1);
            // 
            // Graphpg
            // 
            this.Graphpg.AutoSize = true;
            this.Graphpg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graphpg.ForeColor = System.Drawing.Color.White;
            this.Graphpg.Location = new System.Drawing.Point(367, 9);
            this.Graphpg.Name = "Graphpg";
            this.Graphpg.Size = new System.Drawing.Size(209, 44);
            this.Graphpg.TabIndex = 18;
            this.Graphpg.Text = "Graph Page";
            // 
            // InputData
            // 
            this.InputData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.InputData.Controls.Add(this.input_MD);
            this.InputData.Controls.Add(this.itemInputPanel);
            this.InputData.Controls.Add(this.partInputPanel);
            this.InputData.Controls.Add(this.mainInput_Button);
            this.InputData.Controls.Add(this.InputPartInfoBttn);
            this.InputData.Controls.Add(this.InputItemInfoBttn);
            this.InputData.Controls.Add(this.Input_Page);
            this.InputData.Location = new System.Drawing.Point(203, 0);
            this.InputData.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.InputData.Name = "InputData";
            this.InputData.Size = new System.Drawing.Size(1107, 773);
            this.InputData.TabIndex = 42;
            // 
            // input_MD
            // 
            this.input_MD.Controls.Add(this.costMark);
            this.input_MD.Controls.Add(this.mainInput);
            this.input_MD.Controls.Add(this.dateTimePicker3);
            this.input_MD.Controls.Add(this.weekDatelb);
            this.input_MD.Controls.Add(this.weekSaleslb);
            this.input_MD.Controls.Add(this.weekSales);
            this.input_MD.Controls.Add(this.saleMark);
            this.input_MD.Controls.Add(this.weekCostlb);
            this.input_MD.Controls.Add(this.weekCost);
            this.input_MD.Location = new System.Drawing.Point(83, 160);
            this.input_MD.Margin = new System.Windows.Forms.Padding(4);
            this.input_MD.Name = "input_MD";
            this.input_MD.Size = new System.Drawing.Size(923, 533);
            this.input_MD.TabIndex = 48;
            this.input_MD.Visible = false;
            // 
            // costMark
            // 
            this.costMark.AutoSize = true;
            this.costMark.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costMark.ForeColor = System.Drawing.Color.White;
            this.costMark.Location = new System.Drawing.Point(254, 38);
            this.costMark.Name = "costMark";
            this.costMark.Size = new System.Drawing.Size(0, 16);
            this.costMark.TabIndex = 52;
            // 
            // mainInput
            // 
            this.mainInput.Location = new System.Drawing.Point(328, 243);
            this.mainInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mainInput.Name = "mainInput";
            this.mainInput.Size = new System.Drawing.Size(267, 46);
            this.mainInput.TabIndex = 51;
            this.mainInput.Text = "Input Data";
            this.mainInput.UseVisualStyleBackColor = true;
            this.mainInput.Click += new System.EventHandler(this.mainInput_Click_1);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Location = new System.Drawing.Point(246, 140);
            this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(225, 23);
            this.dateTimePicker3.TabIndex = 50;
            this.dateTimePicker3.Value = new System.DateTime(2020, 10, 29, 0, 0, 0, 0);
            // 
            // weekDatelb
            // 
            this.weekDatelb.AutoSize = true;
            this.weekDatelb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weekDatelb.ForeColor = System.Drawing.Color.Transparent;
            this.weekDatelb.Location = new System.Drawing.Point(133, 140);
            this.weekDatelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.weekDatelb.Name = "weekDatelb";
            this.weekDatelb.Size = new System.Drawing.Size(101, 22);
            this.weekDatelb.TabIndex = 49;
            this.weekDatelb.Text = "Week Date:";
            // 
            // weekSaleslb
            // 
            this.weekSaleslb.AutoSize = true;
            this.weekSaleslb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weekSaleslb.ForeColor = System.Drawing.Color.Transparent;
            this.weekSaleslb.Location = new System.Drawing.Point(467, 58);
            this.weekSaleslb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.weekSaleslb.Name = "weekSaleslb";
            this.weekSaleslb.Size = new System.Drawing.Size(119, 22);
            this.weekSaleslb.TabIndex = 48;
            this.weekSaleslb.Text = "Week\'s Sales:";
            // 
            // weekSales
            // 
            this.weekSales.Location = new System.Drawing.Point(594, 59);
            this.weekSales.Margin = new System.Windows.Forms.Padding(4);
            this.weekSales.Name = "weekSales";
            this.weekSales.Size = new System.Drawing.Size(177, 22);
            this.weekSales.TabIndex = 46;
            // 
            // saleMark
            // 
            this.saleMark.AutoSize = true;
            this.saleMark.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saleMark.ForeColor = System.Drawing.Color.White;
            this.saleMark.Location = new System.Drawing.Point(595, 46);
            this.saleMark.Name = "saleMark";
            this.saleMark.Size = new System.Drawing.Size(0, 16);
            this.saleMark.TabIndex = 43;
            // 
            // weekCostlb
            // 
            this.weekCostlb.AutoSize = true;
            this.weekCostlb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weekCostlb.ForeColor = System.Drawing.Color.Transparent;
            this.weekCostlb.Location = new System.Drawing.Point(128, 57);
            this.weekCostlb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.weekCostlb.Name = "weekCostlb";
            this.weekCostlb.Size = new System.Drawing.Size(112, 22);
            this.weekCostlb.TabIndex = 7;
            this.weekCostlb.Text = "Week\'s Cost:";
            // 
            // weekCost
            // 
            this.weekCost.Location = new System.Drawing.Point(246, 57);
            this.weekCost.Margin = new System.Windows.Forms.Padding(4);
            this.weekCost.Name = "weekCost";
            this.weekCost.Size = new System.Drawing.Size(177, 22);
            this.weekCost.TabIndex = 2;
            // 
            // itemInputPanel
            // 
            this.itemInputPanel.Controls.Add(this.MonthSold);
            this.itemInputPanel.Controls.Add(this.dateTimePicker1);
            this.itemInputPanel.Controls.Add(this.Amount_Made);
            this.itemInputPanel.Controls.Add(this.dataAdded);
            this.itemInputPanel.Controls.Add(this.Item_Id);
            this.itemInputPanel.Controls.Add(this.Item_Name);
            this.itemInputPanel.Controls.Add(this.dateMark);
            this.itemInputPanel.Controls.Add(this.Cost);
            this.itemInputPanel.Controls.Add(this.asMark);
            this.itemInputPanel.Controls.Add(this.Amount_Sold);
            this.itemInputPanel.Controls.Add(this.amMark);
            this.itemInputPanel.Controls.Add(this.Selling_Price);
            this.itemInputPanel.Controls.Add(this.spMark);
            this.itemInputPanel.Controls.Add(this.ictmMark);
            this.itemInputPanel.Controls.Add(this.inMark);
            this.itemInputPanel.Controls.Add(this.Input);
            this.itemInputPanel.Controls.Add(this.idMark);
            this.itemInputPanel.Controls.Add(this.ItemId);
            this.itemInputPanel.Controls.Add(this.ItemName);
            this.itemInputPanel.Controls.Add(this.CostItem);
            this.itemInputPanel.Controls.Add(this.AmountSold);
            this.itemInputPanel.Controls.Add(this.SoldPrice);
            this.itemInputPanel.Controls.Add(this.AmountMade);
            this.itemInputPanel.Location = new System.Drawing.Point(83, 160);
            this.itemInputPanel.Margin = new System.Windows.Forms.Padding(4);
            this.itemInputPanel.Name = "itemInputPanel";
            this.itemInputPanel.Size = new System.Drawing.Size(923, 533);
            this.itemInputPanel.TabIndex = 51;
            // 
            // MonthSold
            // 
            this.MonthSold.AutoSize = true;
            this.MonthSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonthSold.ForeColor = System.Drawing.Color.Transparent;
            this.MonthSold.Location = new System.Drawing.Point(139, 182);
            this.MonthSold.Name = "MonthSold";
            this.MonthSold.Size = new System.Drawing.Size(95, 22);
            this.MonthSold.TabIndex = 47;
            this.MonthSold.Text = "Date Sold:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "\"yyyy-MMMM-dd\"";
            this.dateTimePicker1.Location = new System.Drawing.Point(253, 181);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(220, 22);
            this.dateTimePicker1.TabIndex = 46;
            this.dateTimePicker1.Value = new System.DateTime(2020, 10, 29, 7, 42, 23, 0);
            // 
            // Amount_Made
            // 
            this.Amount_Made.Location = new System.Drawing.Point(253, 128);
            this.Amount_Made.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Amount_Made.Name = "Amount_Made";
            this.Amount_Made.Size = new System.Drawing.Size(177, 22);
            this.Amount_Made.TabIndex = 5;
            // 
            // dataAdded
            // 
            this.dataAdded.AutoSize = true;
            this.dataAdded.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataAdded.ForeColor = System.Drawing.Color.White;
            this.dataAdded.Location = new System.Drawing.Point(355, 315);
            this.dataAdded.Name = "dataAdded";
            this.dataAdded.Size = new System.Drawing.Size(0, 22);
            this.dataAdded.TabIndex = 43;
            // 
            // Item_Id
            // 
            this.Item_Id.Location = new System.Drawing.Point(253, 28);
            this.Item_Id.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Item_Id.Name = "Item_Id";
            this.Item_Id.Size = new System.Drawing.Size(177, 22);
            this.Item_Id.TabIndex = 1;
            // 
            // Item_Name
            // 
            this.Item_Name.Location = new System.Drawing.Point(616, 28);
            this.Item_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Item_Name.Name = "Item_Name";
            this.Item_Name.Size = new System.Drawing.Size(177, 22);
            this.Item_Name.TabIndex = 2;
            // 
            // dateMark
            // 
            this.dateMark.AutoSize = true;
            this.dateMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateMark.ForeColor = System.Drawing.Color.Red;
            this.dateMark.Location = new System.Drawing.Point(260, 156);
            this.dateMark.Name = "dateMark";
            this.dateMark.Size = new System.Drawing.Size(0, 22);
            this.dateMark.TabIndex = 41;
            // 
            // Cost
            // 
            this.Cost.Location = new System.Drawing.Point(253, 79);
            this.Cost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(177, 22);
            this.Cost.TabIndex = 3;
            // 
            // asMark
            // 
            this.asMark.AutoSize = true;
            this.asMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asMark.ForeColor = System.Drawing.Color.Red;
            this.asMark.Location = new System.Drawing.Point(617, 105);
            this.asMark.Name = "asMark";
            this.asMark.Size = new System.Drawing.Size(0, 22);
            this.asMark.TabIndex = 40;
            // 
            // Amount_Sold
            // 
            this.Amount_Sold.Location = new System.Drawing.Point(616, 128);
            this.Amount_Sold.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Amount_Sold.Name = "Amount_Sold";
            this.Amount_Sold.Size = new System.Drawing.Size(177, 22);
            this.Amount_Sold.TabIndex = 6;
            // 
            // amMark
            // 
            this.amMark.AutoSize = true;
            this.amMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amMark.ForeColor = System.Drawing.Color.Red;
            this.amMark.Location = new System.Drawing.Point(249, 105);
            this.amMark.Name = "amMark";
            this.amMark.Size = new System.Drawing.Size(0, 22);
            this.amMark.TabIndex = 39;
            // 
            // Selling_Price
            // 
            this.Selling_Price.Location = new System.Drawing.Point(616, 79);
            this.Selling_Price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Selling_Price.Name = "Selling_Price";
            this.Selling_Price.Size = new System.Drawing.Size(177, 22);
            this.Selling_Price.TabIndex = 4;
            // 
            // spMark
            // 
            this.spMark.AutoSize = true;
            this.spMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spMark.ForeColor = System.Drawing.Color.Red;
            this.spMark.Location = new System.Drawing.Point(617, 54);
            this.spMark.Name = "spMark";
            this.spMark.Size = new System.Drawing.Size(0, 22);
            this.spMark.TabIndex = 38;
            // 
            // ictmMark
            // 
            this.ictmMark.AutoSize = true;
            this.ictmMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ictmMark.ForeColor = System.Drawing.Color.Red;
            this.ictmMark.Location = new System.Drawing.Point(249, 54);
            this.ictmMark.Name = "ictmMark";
            this.ictmMark.Size = new System.Drawing.Size(0, 22);
            this.ictmMark.TabIndex = 37;
            // 
            // inMark
            // 
            this.inMark.AutoSize = true;
            this.inMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inMark.ForeColor = System.Drawing.Color.Red;
            this.inMark.Location = new System.Drawing.Point(636, 17);
            this.inMark.Name = "inMark";
            this.inMark.Size = new System.Drawing.Size(0, 22);
            this.inMark.TabIndex = 36;
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(351, 341);
            this.Input.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(267, 46);
            this.Input.TabIndex = 9;
            this.Input.Text = "Input Data";
            this.Input.UseVisualStyleBackColor = true;
            this.Input.Click += new System.EventHandler(this.Input_Click_2);
            // 
            // idMark
            // 
            this.idMark.AutoSize = true;
            this.idMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idMark.ForeColor = System.Drawing.Color.Red;
            this.idMark.Location = new System.Drawing.Point(268, 16);
            this.idMark.Name = "idMark";
            this.idMark.Size = new System.Drawing.Size(0, 22);
            this.idMark.TabIndex = 35;
            // 
            // ItemId
            // 
            this.ItemId.AutoSize = true;
            this.ItemId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemId.ForeColor = System.Drawing.Color.Transparent;
            this.ItemId.Location = new System.Drawing.Point(155, 27);
            this.ItemId.Name = "ItemId";
            this.ItemId.Size = new System.Drawing.Size(71, 22);
            this.ItemId.TabIndex = 27;
            this.ItemId.Text = "Item Id:";
            // 
            // ItemName
            // 
            this.ItemName.AutoSize = true;
            this.ItemName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemName.ForeColor = System.Drawing.Color.Transparent;
            this.ItemName.Location = new System.Drawing.Point(508, 28);
            this.ItemName.Name = "ItemName";
            this.ItemName.Size = new System.Drawing.Size(101, 22);
            this.ItemName.TabIndex = 28;
            this.ItemName.Text = "Item Name:";
            // 
            // CostItem
            // 
            this.CostItem.AutoSize = true;
            this.CostItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostItem.ForeColor = System.Drawing.Color.Transparent;
            this.CostItem.Location = new System.Drawing.Point(69, 79);
            this.CostItem.Name = "CostItem";
            this.CostItem.Size = new System.Drawing.Size(157, 22);
            this.CostItem.TabIndex = 29;
            this.CostItem.Text = "Item Cost to make:";
            // 
            // AmountSold
            // 
            this.AmountSold.AutoSize = true;
            this.AmountSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountSold.ForeColor = System.Drawing.Color.Transparent;
            this.AmountSold.Location = new System.Drawing.Point(488, 128);
            this.AmountSold.Name = "AmountSold";
            this.AmountSold.Size = new System.Drawing.Size(119, 22);
            this.AmountSold.TabIndex = 32;
            this.AmountSold.Text = "Amount Sold:";
            // 
            // SoldPrice
            // 
            this.SoldPrice.AutoSize = true;
            this.SoldPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoldPrice.ForeColor = System.Drawing.Color.Transparent;
            this.SoldPrice.Location = new System.Drawing.Point(508, 78);
            this.SoldPrice.Name = "SoldPrice";
            this.SoldPrice.Size = new System.Drawing.Size(100, 22);
            this.SoldPrice.TabIndex = 30;
            this.SoldPrice.Text = "Sold Price:";
            // 
            // AmountMade
            // 
            this.AmountMade.AutoSize = true;
            this.AmountMade.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountMade.ForeColor = System.Drawing.Color.Transparent;
            this.AmountMade.Location = new System.Drawing.Point(107, 128);
            this.AmountMade.Name = "AmountMade";
            this.AmountMade.Size = new System.Drawing.Size(127, 22);
            this.AmountMade.TabIndex = 31;
            this.AmountMade.Text = "Amount Made:";
            // 
            // partInputPanel
            // 
            this.partInputPanel.Controls.Add(this.dateTimePicker2);
            this.partInputPanel.Controls.Add(this.label10);
            this.partInputPanel.Controls.Add(this.label9);
            this.partInputPanel.Controls.Add(this.NumOfPartsInput);
            this.partInputPanel.Controls.Add(this.partDataAdded);
            this.partInputPanel.Controls.Add(this.inputPartBttn);
            this.partInputPanel.Controls.Add(this.label6);
            this.partInputPanel.Controls.Add(this.label5);
            this.partInputPanel.Controls.Add(this.label4);
            this.partInputPanel.Controls.Add(this.label3);
            this.partInputPanel.Controls.Add(this.label1);
            this.partInputPanel.Controls.Add(this.PartName);
            this.partInputPanel.Controls.Add(this.ItemNameInput);
            this.partInputPanel.Controls.Add(this.PartCost);
            this.partInputPanel.Controls.Add(this.PartId);
            this.partInputPanel.Controls.Add(this.ItemIdInput);
            this.partInputPanel.Location = new System.Drawing.Point(83, 160);
            this.partInputPanel.Margin = new System.Windows.Forms.Padding(4);
            this.partInputPanel.Name = "partInputPanel";
            this.partInputPanel.Size = new System.Drawing.Size(923, 533);
            this.partInputPanel.TabIndex = 52;
            this.partInputPanel.Visible = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(253, 175);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(225, 23);
            this.dateTimePicker2.TabIndex = 50;
            this.dateTimePicker2.Value = new System.DateTime(2020, 10, 29, 0, 0, 0, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(118, 174);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 22);
            this.label10.TabIndex = 49;
            this.label10.Text = "Delivery Date:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(508, 133);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 22);
            this.label9.TabIndex = 48;
            this.label9.Text = "# of Parts:";
            // 
            // NumOfPartsInput
            // 
            this.NumOfPartsInput.Location = new System.Drawing.Point(615, 132);
            this.NumOfPartsInput.Margin = new System.Windows.Forms.Padding(4);
            this.NumOfPartsInput.Name = "NumOfPartsInput";
            this.NumOfPartsInput.Size = new System.Drawing.Size(177, 22);
            this.NumOfPartsInput.TabIndex = 46;
            // 
            // partDataAdded
            // 
            this.partDataAdded.AutoSize = true;
            this.partDataAdded.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.partDataAdded.ForeColor = System.Drawing.Color.White;
            this.partDataAdded.Location = new System.Drawing.Point(355, 315);
            this.partDataAdded.Name = "partDataAdded";
            this.partDataAdded.Size = new System.Drawing.Size(0, 16);
            this.partDataAdded.TabIndex = 43;
            // 
            // inputPartBttn
            // 
            this.inputPartBttn.Location = new System.Drawing.Point(351, 341);
            this.inputPartBttn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.inputPartBttn.Name = "inputPartBttn";
            this.inputPartBttn.Size = new System.Drawing.Size(267, 46);
            this.inputPartBttn.TabIndex = 10;
            this.inputPartBttn.Text = "Input Data";
            this.inputPartBttn.UseVisualStyleBackColor = true;
            this.inputPartBttn.Click += new System.EventHandler(this.inputPartBttn_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(500, 81);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 22);
            this.label6.TabIndex = 9;
            this.label6.Text = "Part Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(499, 32);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 22);
            this.label5.TabIndex = 8;
            this.label5.Text = "Item Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(133, 121);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "Cost of Part:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(176, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Part Id:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(176, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 22);
            this.label1.TabIndex = 5;
            this.label1.Text = "Item Id:";
            // 
            // PartName
            // 
            this.PartName.Location = new System.Drawing.Point(616, 82);
            this.PartName.Margin = new System.Windows.Forms.Padding(4);
            this.PartName.Name = "PartName";
            this.PartName.Size = new System.Drawing.Size(177, 22);
            this.PartName.TabIndex = 4;
            // 
            // ItemNameInput
            // 
            this.ItemNameInput.Location = new System.Drawing.Point(616, 34);
            this.ItemNameInput.Margin = new System.Windows.Forms.Padding(4);
            this.ItemNameInput.Name = "ItemNameInput";
            this.ItemNameInput.Size = new System.Drawing.Size(177, 22);
            this.ItemNameInput.TabIndex = 3;
            // 
            // PartCost
            // 
            this.PartCost.Location = new System.Drawing.Point(273, 125);
            this.PartCost.Margin = new System.Windows.Forms.Padding(4);
            this.PartCost.Name = "PartCost";
            this.PartCost.Size = new System.Drawing.Size(177, 22);
            this.PartCost.TabIndex = 2;
            // 
            // PartId
            // 
            this.PartId.Location = new System.Drawing.Point(272, 79);
            this.PartId.Margin = new System.Windows.Forms.Padding(4);
            this.PartId.Name = "PartId";
            this.PartId.Size = new System.Drawing.Size(177, 22);
            this.PartId.TabIndex = 1;
            // 
            // ItemIdInput
            // 
            this.ItemIdInput.Location = new System.Drawing.Point(272, 33);
            this.ItemIdInput.Margin = new System.Windows.Forms.Padding(4);
            this.ItemIdInput.Name = "ItemIdInput";
            this.ItemIdInput.Size = new System.Drawing.Size(177, 22);
            this.ItemIdInput.TabIndex = 0;
            // 
            // mainInput_Button
            // 
            this.mainInput_Button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mainInput_Button.FlatAppearance.BorderSize = 0;
            this.mainInput_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainInput_Button.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainInput_Button.ForeColor = System.Drawing.Color.Goldenrod;
            this.mainInput_Button.Location = new System.Drawing.Point(88, 121);
            this.mainInput_Button.Margin = new System.Windows.Forms.Padding(4);
            this.mainInput_Button.Name = "mainInput_Button";
            this.mainInput_Button.Size = new System.Drawing.Size(151, 37);
            this.mainInput_Button.TabIndex = 49;
            this.mainInput_Button.Text = "Main Input";
            this.mainInput_Button.UseVisualStyleBackColor = false;
            this.mainInput_Button.Click += new System.EventHandler(this.mainInput_Button_Click_1);
            // 
            // InputPartInfoBttn
            // 
            this.InputPartInfoBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.InputPartInfoBttn.FlatAppearance.BorderSize = 0;
            this.InputPartInfoBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InputPartInfoBttn.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputPartInfoBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.InputPartInfoBttn.Location = new System.Drawing.Point(406, 121);
            this.InputPartInfoBttn.Margin = new System.Windows.Forms.Padding(4);
            this.InputPartInfoBttn.Name = "InputPartInfoBttn";
            this.InputPartInfoBttn.Size = new System.Drawing.Size(151, 37);
            this.InputPartInfoBttn.TabIndex = 47;
            this.InputPartInfoBttn.Text = "Item Part";
            this.InputPartInfoBttn.UseVisualStyleBackColor = false;
            this.InputPartInfoBttn.Click += new System.EventHandler(this.InputPartInfoBttn_Click);
            // 
            // InputItemInfoBttn
            // 
            this.InputItemInfoBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.InputItemInfoBttn.FlatAppearance.BorderSize = 0;
            this.InputItemInfoBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InputItemInfoBttn.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputItemInfoBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.InputItemInfoBttn.Location = new System.Drawing.Point(247, 121);
            this.InputItemInfoBttn.Margin = new System.Windows.Forms.Padding(4);
            this.InputItemInfoBttn.Name = "InputItemInfoBttn";
            this.InputItemInfoBttn.Size = new System.Drawing.Size(151, 37);
            this.InputItemInfoBttn.TabIndex = 46;
            this.InputItemInfoBttn.Text = "Item Info";
            this.InputItemInfoBttn.UseVisualStyleBackColor = false;
            this.InputItemInfoBttn.Click += new System.EventHandler(this.InputItemInfoBttn_Click);
            // 
            // Input_Page
            // 
            this.Input_Page.AutoSize = true;
            this.Input_Page.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Input_Page.ForeColor = System.Drawing.Color.White;
            this.Input_Page.Location = new System.Drawing.Point(469, 46);
            this.Input_Page.Name = "Input_Page";
            this.Input_Page.Size = new System.Drawing.Size(195, 44);
            this.Input_Page.TabIndex = 17;
            this.Input_Page.Text = "Input Page";
            // 
            // Profile
            // 
            this.Profile.BackColor = System.Drawing.Color.Transparent;
            this.Profile.FlatAppearance.BorderSize = 0;
            this.Profile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Profile.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Profile.ForeColor = System.Drawing.Color.White;
            this.Profile.Image = ((System.Drawing.Image)(resources.GetObject("Profile.Image")));
            this.Profile.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Profile.Location = new System.Drawing.Point(-3, 177);
            this.Profile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Profile.Name = "Profile";
            this.Profile.Size = new System.Drawing.Size(199, 137);
            this.Profile.TabIndex = 2;
            this.Profile.Text = "Profile";
            this.Profile.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Profile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Profile.UseVisualStyleBackColor = false;
            this.Profile.Click += new System.EventHandler(this.Profile_Click);
            // 
            // DataPage
            // 
            this.DataPage.BackColor = System.Drawing.Color.Transparent;
            this.DataPage.FlatAppearance.BorderSize = 0;
            this.DataPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataPage.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataPage.ForeColor = System.Drawing.Color.White;
            this.DataPage.Image = ((System.Drawing.Image)(resources.GetObject("DataPage.Image")));
            this.DataPage.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataPage.Location = new System.Drawing.Point(3, 434);
            this.DataPage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataPage.Name = "DataPage";
            this.DataPage.Size = new System.Drawing.Size(199, 113);
            this.DataPage.TabIndex = 4;
            this.DataPage.Text = "Data Page";
            this.DataPage.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataPage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataPage.UseVisualStyleBackColor = false;
            this.DataPage.Click += new System.EventHandler(this.DataPage_Click);
            // 
            // Graph
            // 
            this.Graph.BackColor = System.Drawing.Color.Transparent;
            this.Graph.FlatAppearance.BorderSize = 0;
            this.Graph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Graph.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graph.ForeColor = System.Drawing.Color.White;
            this.Graph.Image = ((System.Drawing.Image)(resources.GetObject("Graph.Image")));
            this.Graph.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Graph.Location = new System.Drawing.Point(1, 551);
            this.Graph.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Graph.Name = "Graph";
            this.Graph.Size = new System.Drawing.Size(196, 101);
            this.Graph.TabIndex = 5;
            this.Graph.Text = "Graph";
            this.Graph.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Graph.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Graph.UseVisualStyleBackColor = false;
            this.Graph.Click += new System.EventHandler(this.Graph_Click);
            // 
            // DataInput
            // 
            this.DataInput.BackColor = System.Drawing.Color.Transparent;
            this.DataInput.FlatAppearance.BorderSize = 0;
            this.DataInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataInput.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataInput.ForeColor = System.Drawing.Color.White;
            this.DataInput.Image = ((System.Drawing.Image)(resources.GetObject("DataInput.Image")));
            this.DataInput.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataInput.Location = new System.Drawing.Point(-3, 318);
            this.DataInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DataInput.Name = "DataInput";
            this.DataInput.Size = new System.Drawing.Size(199, 113);
            this.DataInput.TabIndex = 3;
            this.DataInput.Text = "Data Input";
            this.DataInput.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataInput.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataInput.UseVisualStyleBackColor = false;
            this.DataInput.Click += new System.EventHandler(this.DataInput_Click);
            // 
            // Home_Page
            // 
            this.Home_Page.BackColor = System.Drawing.Color.Transparent;
            this.Home_Page.FlatAppearance.BorderSize = 0;
            this.Home_Page.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home_Page.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Home_Page.ForeColor = System.Drawing.Color.White;
            this.Home_Page.Image = ((System.Drawing.Image)(resources.GetObject("Home_Page.Image")));
            this.Home_Page.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Home_Page.Location = new System.Drawing.Point(0, 69);
            this.Home_Page.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Home_Page.Name = "Home_Page";
            this.Home_Page.Size = new System.Drawing.Size(199, 98);
            this.Home_Page.TabIndex = 1;
            this.Home_Page.Text = "Home Page";
            this.Home_Page.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Home_Page.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Home_Page.UseVisualStyleBackColor = false;
            this.Home_Page.Click += new System.EventHandler(this.Home_Page_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1307, 772);
            this.Controls.Add(this.Graph_Page);
            this.Controls.Add(this.InputData);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.HomePage);
            this.Controls.Add(this.Profile_Page);
            this.Controls.Add(this.Side1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Finance Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompleteClosing);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.Enter += new System.EventHandler(this.Form1_Load_1);
            this.Side1.ResumeLayout(false);
            this.FinancePanel.ResumeLayout(false);
            this.FinancePanel.PerformLayout();
            this.HomePage.ResumeLayout(false);
            this.HomePage.PerformLayout();
            this.Data.ResumeLayout(false);
            this.Data.PerformLayout();
            this.itemInfoPanel.ResumeLayout(false);
            this.itemInfoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet2)).EndInit();
            this.itemPartPanel.ResumeLayout(false);
            this.itemPartPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itempartBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet3)).EndInit();
            this.profitSalesPanel.ResumeLayout(false);
            this.profitSalesPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itempartBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet1)).EndInit();
            this.Profile_Page.ResumeLayout(false);
            this.Profile_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet)).EndInit();
            this.Graph_Page.ResumeLayout(false);
            this.Graph_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GraphData)).EndInit();
            this.InputData.ResumeLayout(false);
            this.InputData.PerformLayout();
            this.input_MD.ResumeLayout(false);
            this.input_MD.PerformLayout();
            this.itemInputPanel.ResumeLayout(false);
            this.itemInputPanel.PerformLayout();
            this.partInputPanel.ResumeLayout(false);
            this.partInputPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel Side1;
        private System.Windows.Forms.Panel FinancePanel;
        private System.Windows.Forms.Button Home_Page;
        private System.Windows.Forms.Button DataInput;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Graph;
        private System.Windows.Forms.Label FinanceTracker;
        private System.Windows.Forms.Panel HomePage;
        private System.Windows.Forms.Label HomePg;
        private System.Windows.Forms.Button DataPage;
        private System.Windows.Forms.Panel Data;
        private System.Windows.Forms.Label Data_Search;
        private System.Windows.Forms.Label Searchlabel;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Finance_Tracker_SE.finance_trackerDataSet finance_trackerDataSet;
        private System.Windows.Forms.BindingSource itemBindingSource;
        private Finance_Tracker_SE.finance_trackerDataSetTableAdapters.itemTableAdapter itemTableAdapter;
        private System.Windows.Forms.Button Profile;
        private System.Windows.Forms.Panel Profile_Page;
        private System.Windows.Forms.Label Profilelab;
        private System.Windows.Forms.Button profitSalesBttn;
        private System.Windows.Forms.Button itemPartsBttn;
        private System.Windows.Forms.Button itemInfoBttn;
        private System.Windows.Forms.Panel itemInfoPanel;
        private System.Windows.Forms.Panel itemPartPanel;
        private System.Windows.Forms.Panel profitSalesPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Finance_Tracker_SE.finance_trackerDataSet1 finance_trackerDataSet1;
        private System.Windows.Forms.BindingSource itempartBindingSource;
        private Finance_Tracker_SE.finance_trackerDataSet1TableAdapters.itempartTableAdapter itempartTableAdapter;
        private System.Windows.Forms.Label itemSearchLbl;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private Finance_Tracker_SE.finance_trackerDataSet2 finance_trackerDataSet2;
        private System.Windows.Forms.BindingSource itemBindingSource1;
        private Finance_Tracker_SE.finance_trackerDataSet2TableAdapters.itemTableAdapter itemTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn costToMakeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellingPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountSoldDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountMadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn monthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private Finance_Tracker_SE.finance_trackerDataSet3 finance_trackerDataSet3;
        private System.Windows.Forms.BindingSource itempartBindingSource1;
        private Finance_Tracker_SE.finance_trackerDataSet3TableAdapters.itempartTableAdapter itempartTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn partIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partArrival;
        private System.Windows.Forms.Panel Graph_Page;
        private System.Windows.Forms.Button YearGraphBttn;
        private System.Windows.Forms.Button MonthGraphBttn;
        private System.Windows.Forms.DataVisualization.Charting.Chart GraphData;
        private System.Windows.Forms.Label Graphpg;
        private System.Windows.Forms.Panel InputData;
        private System.Windows.Forms.Panel input_MD;
        private System.Windows.Forms.Label costMark;
        private System.Windows.Forms.Button mainInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label weekDatelb;
        private System.Windows.Forms.Label weekSaleslb;
        private System.Windows.Forms.TextBox weekSales;
        private System.Windows.Forms.Label saleMark;
        private System.Windows.Forms.Label weekCostlb;
        private System.Windows.Forms.TextBox weekCost;
        private System.Windows.Forms.Panel partInputPanel;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox NumOfPartsInput;
        private System.Windows.Forms.Label partDataAdded;
        private System.Windows.Forms.Button inputPartBttn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PartName;
        private System.Windows.Forms.TextBox ItemNameInput;
        private System.Windows.Forms.TextBox PartCost;
        private System.Windows.Forms.TextBox PartId;
        private System.Windows.Forms.TextBox ItemIdInput;
        private System.Windows.Forms.Panel itemInputPanel;
        private System.Windows.Forms.Label MonthSold;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox Amount_Made;
        private System.Windows.Forms.Label dataAdded;
        private System.Windows.Forms.TextBox Item_Id;
        private System.Windows.Forms.TextBox Item_Name;
        private System.Windows.Forms.Label dateMark;
        private System.Windows.Forms.TextBox Cost;
        private System.Windows.Forms.Label asMark;
        private System.Windows.Forms.TextBox Amount_Sold;
        private System.Windows.Forms.Label amMark;
        private System.Windows.Forms.TextBox Selling_Price;
        private System.Windows.Forms.Label spMark;
        private System.Windows.Forms.Label ictmMark;
        private System.Windows.Forms.Label inMark;
        private System.Windows.Forms.Button Input;
        private System.Windows.Forms.Label idMark;
        private System.Windows.Forms.Label ItemId;
        private System.Windows.Forms.Label ItemName;
        private System.Windows.Forms.Label CostItem;
        private System.Windows.Forms.Label AmountSold;
        private System.Windows.Forms.Label SoldPrice;
        private System.Windows.Forms.Label AmountMade;
        private System.Windows.Forms.Button mainInput_Button;
        private System.Windows.Forms.Button InputPartInfoBttn;
        private System.Windows.Forms.Button InputItemInfoBttn;
        private System.Windows.Forms.Label Input_Page;
    }
}

