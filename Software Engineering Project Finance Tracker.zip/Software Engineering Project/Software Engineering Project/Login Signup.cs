﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Engineering_Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Username_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_Input_TextChanged(object sender, EventArgs e)
        {

        }

        int remaining_Attemps = 8; // Attemps need to be out of button so it keeps count

        private void Login_Click(object sender, EventArgs e)
        {
            //Variables
            string b_Password = "1";
            string b_Username = "2";
            string b_Email = "";
            int b_Attemps = 0;


            if (remaining_Attemps <= 0) //the users attemps
            {
                MessageBox.Show("Sorry You have attemped way to many times");
                MessageBox.Show("try again  in 10 minutes:");
               
            }
            else // if it works and they have a attemp
            {
                if (b_Username == Username_Input.Text || b_Email == Username_Input.Text)
                {
                    if (b_Password == Password_Input.Text)
                    {
                        Form1 F1 = new Form1();
                        F1.Show();
                    }
                }
                else
                {
                    b_Attemps++;
                    remaining_Attemps = remaining_Attemps - b_Attemps;
                    MessageBox.Show(" Your Password or Username/Email is Incorrect. You have " + remaining_Attemps +" remaining!");
                }
            }
        }


    }
}
