﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using MySql.Data.MySqlClient;

namespace Software_Engineering_Project
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Username_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_Input_TextChanged(object sender, EventArgs e)
        {

        }

        int remaining_Attemps = 8;// Attemps need to be out of button so it keeps count
        int numOfTimeout = 0;
        public static int userID;
        int timeLeft = 300; // for Timer 5 minutes in seconds

        private void Login_Click(object sender, EventArgs e)
        {
            //Variables
            string b_Password = Password_Input.Text;
            string b_Username = Username_Input.Text;


            unMark.Text = "";
            pdMark.Text = "";
            arMark.Text = "";

            if (b_Password == "" || b_Username == "")
            {

                if (b_Username == "")
                {
                    unMark.Text = "* Requires UserName";
                }

                if (b_Password == "")
                {
                    pdMark.Text = "* Requires Password";
                }

            }

            else
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "SELECT * FROM userinfo where username='" + b_Username + "' AND password ='" + b_Password + "'"; // the command
                MySqlDataReader dRead; // to read the data base

                con.Open(); // opens connection

                using (dRead = cmd.ExecuteReader()) // executes the search command
                {
                    if (dRead.Read()) // Checks if username and password is in it
                    {
                        dRead.Read();

                        Username_Input.Text = ""; //reset input box
                        Password_Input.Text = "";


                        dRead.Close();
                        cmd.CommandText = "SELECT id FROM userinfo where username='" + b_Username + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {
                                userID = Convert.ToInt32(dRead.GetValue(0).ToString());
                            }
                        }
                        con.Close();
                        dRead.Close();
                        this.Hide();
                        Form1 F1 = new Form1(); // creates and show signup form
                        F1.Show();
                    }
                    else
                    {
                        dRead.Close();
                        cmd.CommandText = "SELECT * FROM userinfo where username='" + b_Username + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {
                                pdMark.Text = "* Incorrect Password";
                                Password_Input.Text = "";
                            }
                            else
                            {
                                unMark.Text = "* Incorrect Username";
                                Username_Input.Text = ""; //reset input box

                            }
                        }
                        dRead.Close();

                        remaining_Attemps = remaining_Attemps - 1;
                        con.Close();

                        arMark.Text = "Attemps Remain: " + remaining_Attemps;

                        if (remaining_Attemps <= 0) //the users attemps
                        {
                            arMark.Text = "Sorry, Too many attemps try again in: 10 minutes";
                            Login.Enabled = false; // disables the button
                            SignUp_Label.Enabled = false;
                            attemp_Reset.Start(); // starts timer

                        }
                    }

                    con.Close();

                }
            }
        }

        private void SignUp_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form3 F3 = new Form3(); // creates and show signup form
            F3.Show();
            this.Hide();   
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); //Exits all forms
        }

        private void attemp_Reset_Tick(object sender, EventArgs e) // time for the attemp fail
        {
         
            if(timeLeft > 0)
            {
                timeLeft = timeLeft - 1; // subtracts one every one second 
                arMark.Text = timeLeft + " seconds";  //Displays the time remaining
            }
            else
            {
                attemp_Reset.Stop(); ;
                numOfTimeout = numOfTimeout + 1; // keeps track of login locks
                arMark.Text = "Time's up! Try Again!";
                Login.Enabled = true;
                SignUp_Label.Enabled = true;
                remaining_Attemps = 8;
                timeLeft = 600 + (300 * numOfTimeout); // add 5 minutes to the time before for every lock out
            }
        }
    }
}
