﻿namespace Finance_Tracker_SE
{
    partial class Email_Change
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.email_Confirm = new System.Windows.Forms.Label();
            this.emMark = new System.Windows.Forms.Label();
            this.changeEmail = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.confirmNewEmail_Input = new System.Windows.Forms.TextBox();
            this.newEmail_Input = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // email_Confirm
            // 
            this.email_Confirm.AutoSize = true;
            this.email_Confirm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_Confirm.ForeColor = System.Drawing.Color.Red;
            this.email_Confirm.Location = new System.Drawing.Point(191, 114);
            this.email_Confirm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.email_Confirm.Name = "email_Confirm";
            this.email_Confirm.Size = new System.Drawing.Size(0, 19);
            this.email_Confirm.TabIndex = 46;
            this.email_Confirm.Click += new System.EventHandler(this.email_Confirm_Click);
            // 
            // emMark
            // 
            this.emMark.AutoSize = true;
            this.emMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emMark.ForeColor = System.Drawing.Color.Red;
            this.emMark.Location = new System.Drawing.Point(191, 61);
            this.emMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.emMark.Name = "emMark";
            this.emMark.Size = new System.Drawing.Size(0, 19);
            this.emMark.TabIndex = 45;
            this.emMark.Click += new System.EventHandler(this.emMark_Click);
            // 
            // changeEmail
            // 
            this.changeEmail.Location = new System.Drawing.Point(250, 233);
            this.changeEmail.Name = "changeEmail";
            this.changeEmail.Size = new System.Drawing.Size(140, 46);
            this.changeEmail.TabIndex = 44;
            this.changeEmail.Text = "Change Email";
            this.changeEmail.UseVisualStyleBackColor = true;
            this.changeEmail.Click += new System.EventHandler(this.changeEmail_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(93, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 17);
            this.label2.TabIndex = 43;
            this.label2.Text = "Confirm Email:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(111, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 42;
            this.label1.Text = "New Email:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // confirmNewEmail_Input
            // 
            this.confirmNewEmail_Input.Location = new System.Drawing.Point(195, 136);
            this.confirmNewEmail_Input.Name = "confirmNewEmail_Input";
            this.confirmNewEmail_Input.Size = new System.Drawing.Size(321, 20);
            this.confirmNewEmail_Input.TabIndex = 41;
            this.confirmNewEmail_Input.TextChanged += new System.EventHandler(this.confirmNewEmail_Input_TextChanged);
            // 
            // newEmail_Input
            // 
            this.newEmail_Input.Location = new System.Drawing.Point(194, 83);
            this.newEmail_Input.Name = "newEmail_Input";
            this.newEmail_Input.Size = new System.Drawing.Size(321, 20);
            this.newEmail_Input.TabIndex = 40;
            this.newEmail_Input.TextChanged += new System.EventHandler(this.newEmail_Input_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(54, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 17);
            this.label3.TabIndex = 50;
            this.label3.Text = "Confirm w/Password:";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(194, 188);
            this.password.MaxLength = 31;
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(321, 20);
            this.password.TabIndex = 49;
            // 
            // Email_Change
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(32)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.password);
            this.Controls.Add(this.email_Confirm);
            this.Controls.Add(this.emMark);
            this.Controls.Add(this.changeEmail);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.confirmNewEmail_Input);
            this.Controls.Add(this.newEmail_Input);
            this.Name = "Email_Change";
            this.Text = "Email_Change";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label email_Confirm;
        private System.Windows.Forms.Label emMark;
        private System.Windows.Forms.Button changeEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox confirmNewEmail_Input;
        private System.Windows.Forms.TextBox newEmail_Input;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox password;
    }
}