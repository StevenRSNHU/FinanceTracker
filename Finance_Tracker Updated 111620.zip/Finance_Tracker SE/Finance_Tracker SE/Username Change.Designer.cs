﻿namespace Finance_Tracker_SE
{
    partial class Username_Change
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.username_Confirm = new System.Windows.Forms.Label();
            this.usMark = new System.Windows.Forms.Label();
            this.changeUsername = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.confirmUsername = new System.Windows.Forms.TextBox();
            this.newUsername = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // username_Confirm
            // 
            this.username_Confirm.AutoSize = true;
            this.username_Confirm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_Confirm.ForeColor = System.Drawing.Color.Red;
            this.username_Confirm.Location = new System.Drawing.Point(190, 121);
            this.username_Confirm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.username_Confirm.Name = "username_Confirm";
            this.username_Confirm.Size = new System.Drawing.Size(0, 19);
            this.username_Confirm.TabIndex = 46;
            // 
            // usMark
            // 
            this.usMark.AutoSize = true;
            this.usMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usMark.ForeColor = System.Drawing.Color.Red;
            this.usMark.Location = new System.Drawing.Point(190, 66);
            this.usMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.usMark.Name = "usMark";
            this.usMark.Size = new System.Drawing.Size(0, 19);
            this.usMark.TabIndex = 45;
            // 
            // changeUsername
            // 
            this.changeUsername.Location = new System.Drawing.Point(251, 246);
            this.changeUsername.Name = "changeUsername";
            this.changeUsername.Size = new System.Drawing.Size(141, 42);
            this.changeUsername.TabIndex = 44;
            this.changeUsername.Text = "Change Username";
            this.changeUsername.UseVisualStyleBackColor = true;
            this.changeUsername.Click += new System.EventHandler(this.changeUsername_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(64, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 17);
            this.label2.TabIndex = 43;
            this.label2.Text = "Confirm Username:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(116, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 17);
            this.label1.TabIndex = 42;
            this.label1.Text = "Username:";
            // 
            // confirmUsername
            // 
            this.confirmUsername.Location = new System.Drawing.Point(194, 143);
            this.confirmUsername.Name = "confirmUsername";
            this.confirmUsername.Size = new System.Drawing.Size(331, 20);
            this.confirmUsername.TabIndex = 41;
            // 
            // newUsername
            // 
            this.newUsername.Location = new System.Drawing.Point(194, 88);
            this.newUsername.Name = "newUsername";
            this.newUsername.Size = new System.Drawing.Size(331, 20);
            this.newUsername.TabIndex = 40;
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(194, 199);
            this.password.MaxLength = 31;
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(331, 20);
            this.password.TabIndex = 47;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(54, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 17);
            this.label3.TabIndex = 48;
            this.label3.Text = "Confirm w/Password:";
            // 
            // Username_Change
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(32)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.password);
            this.Controls.Add(this.username_Confirm);
            this.Controls.Add(this.usMark);
            this.Controls.Add(this.changeUsername);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.confirmUsername);
            this.Controls.Add(this.newUsername);
            this.Name = "Username_Change";
            this.Text = "Username_Change";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label username_Confirm;
        private System.Windows.Forms.Label usMark;
        private System.Windows.Forms.Button changeUsername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox confirmUsername;
        private System.Windows.Forms.TextBox newUsername;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label3;
    }
}