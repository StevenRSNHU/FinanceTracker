﻿namespace Software_Engineering_Project
{
    partial class Form3
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.SignUp = new System.Windows.Forms.Button();
            this.Username = new System.Windows.Forms.TextBox();
            this.First_Name = new System.Windows.Forms.TextBox();
            this.Last_Name = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.Business = new System.Windows.Forms.TextBox();
            this.Account = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.LinkLabel();
            this.zipCode = new System.Windows.Forms.TextBox();
            this.FN = new System.Windows.Forms.Label();
            this.LN = new System.Windows.Forms.Label();
            this.UN = new System.Windows.Forms.Label();
            this.PD = new System.Windows.Forms.Label();
            this.Emaillb = new System.Windows.Forms.Label();
            this.Businesslb = new System.Windows.Forms.Label();
            this.ZC = new System.Windows.Forms.Label();
            this.FnMark = new System.Windows.Forms.Label();
            this.lnMark = new System.Windows.Forms.Label();
            this.unMark = new System.Windows.Forms.Label();
            this.pdMark = new System.Windows.Forms.Label();
            this.BsMark = new System.Windows.Forms.Label();
            this.emailMark = new System.Windows.Forms.Label();
            this.zipMark = new System.Windows.Forms.Label();
            this.phoneMark = new System.Windows.Forms.Label();
            this.pnLabel = new System.Windows.Forms.Label();
            this.phoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.confirm_Pass = new System.Windows.Forms.Label();
            this.confirm_Passw = new System.Windows.Forms.TextBox();
            this.pass_Confirm = new System.Windows.Forms.Label();
            this.Finance_Tracker = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Finance_Tracker)).BeginInit();
            this.SuspendLayout();
            // 
            // SignUp
            // 
            this.SignUp.ForeColor = System.Drawing.Color.Black;
            this.SignUp.Location = new System.Drawing.Point(477, 576);
            this.SignUp.Name = "SignUp";
            this.SignUp.Size = new System.Drawing.Size(299, 38);
            this.SignUp.TabIndex = 9;
            this.SignUp.Text = "Sign up";
            this.SignUp.UseVisualStyleBackColor = true;
            this.SignUp.Click += new System.EventHandler(this.SignUp_Click);
            // 
            // Username
            // 
            this.Username.Location = new System.Drawing.Point(186, 326);
            this.Username.MaxLength = 30;
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(295, 30);
            this.Username.TabIndex = 3;
            // 
            // First_Name
            // 
            this.First_Name.Location = new System.Drawing.Point(186, 261);
            this.First_Name.MaxLength = 30;
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(295, 30);
            this.First_Name.TabIndex = 1;
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(725, 264);
            this.Last_Name.MaxLength = 30;
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(297, 30);
            this.Last_Name.TabIndex = 2;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(725, 453);
            this.Email.MaxLength = 30;
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(297, 30);
            this.Email.TabIndex = 8;
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(725, 329);
            this.Password.MaxLength = 30;
            this.Password.Name = "Password";
            this.Password.PasswordChar = '*';
            this.Password.Size = new System.Drawing.Size(297, 30);
            this.Password.TabIndex = 4;
            // 
            // Business
            // 
            this.Business.ForeColor = System.Drawing.Color.DimGray;
            this.Business.Location = new System.Drawing.Point(186, 391);
            this.Business.MaxLength = 30;
            this.Business.Name = "Business";
            this.Business.Size = new System.Drawing.Size(295, 30);
            this.Business.TabIndex = 5;
            // 
            // Account
            // 
            this.Account.AutoSize = true;
            this.Account.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Account.ForeColor = System.Drawing.Color.White;
            this.Account.Location = new System.Drawing.Point(478, 630);
            this.Account.Name = "Account";
            this.Account.Size = new System.Drawing.Size(186, 27);
            this.Account.TabIndex = 10;
            this.Account.Text = "Have an Account:";
            this.Account.Click += new System.EventHandler(this.Account_Click);
            // 
            // Login
            // 
            this.Login.ActiveLinkColor = System.Drawing.Color.DimGray;
            this.Login.AutoSize = true;
            this.Login.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login.ForeColor = System.Drawing.Color.Black;
            this.Login.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Login.Location = new System.Drawing.Point(618, 630);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(68, 27);
            this.Login.TabIndex = 11;
            this.Login.TabStop = true;
            this.Login.Text = "Login";
            this.Login.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Login_LinkClicked);
            // 
            // zipCode
            // 
            this.zipCode.Location = new System.Drawing.Point(186, 453);
            this.zipCode.MaxLength = 5;
            this.zipCode.Name = "zipCode";
            this.zipCode.Size = new System.Drawing.Size(295, 30);
            this.zipCode.TabIndex = 7;
            // 
            // FN
            // 
            this.FN.AutoSize = true;
            this.FN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FN.ForeColor = System.Drawing.Color.Transparent;
            this.FN.Location = new System.Drawing.Point(69, 264);
            this.FN.Name = "FN";
            this.FN.Size = new System.Drawing.Size(104, 22);
            this.FN.TabIndex = 12;
            this.FN.Text = "First Name:";
            // 
            // LN
            // 
            this.LN.AutoSize = true;
            this.LN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LN.ForeColor = System.Drawing.Color.Transparent;
            this.LN.Location = new System.Drawing.Point(619, 272);
            this.LN.Name = "LN";
            this.LN.Size = new System.Drawing.Size(100, 22);
            this.LN.TabIndex = 13;
            this.LN.Text = "Last Name:";
            // 
            // UN
            // 
            this.UN.AutoSize = true;
            this.UN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UN.ForeColor = System.Drawing.Color.Transparent;
            this.UN.Location = new System.Drawing.Point(78, 329);
            this.UN.Name = "UN";
            this.UN.Size = new System.Drawing.Size(94, 22);
            this.UN.TabIndex = 14;
            this.UN.Text = "Username:";
            // 
            // PD
            // 
            this.PD.AutoSize = true;
            this.PD.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PD.ForeColor = System.Drawing.Color.Transparent;
            this.PD.Location = new System.Drawing.Point(625, 337);
            this.PD.Name = "PD";
            this.PD.Size = new System.Drawing.Size(94, 22);
            this.PD.TabIndex = 15;
            this.PD.Text = "Password:";
            // 
            // Emaillb
            // 
            this.Emaillb.AutoSize = true;
            this.Emaillb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillb.ForeColor = System.Drawing.Color.Transparent;
            this.Emaillb.Location = new System.Drawing.Point(648, 456);
            this.Emaillb.Name = "Emaillb";
            this.Emaillb.Size = new System.Drawing.Size(63, 22);
            this.Emaillb.TabIndex = 17;
            this.Emaillb.Text = "Email:";
            // 
            // Businesslb
            // 
            this.Businesslb.AutoSize = true;
            this.Businesslb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Businesslb.ForeColor = System.Drawing.Color.Transparent;
            this.Businesslb.Location = new System.Drawing.Point(87, 404);
            this.Businesslb.Name = "Businesslb";
            this.Businesslb.Size = new System.Drawing.Size(86, 22);
            this.Businesslb.TabIndex = 18;
            this.Businesslb.Text = "Business:";
            // 
            // ZC
            // 
            this.ZC.AutoSize = true;
            this.ZC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ZC.ForeColor = System.Drawing.Color.Transparent;
            this.ZC.Location = new System.Drawing.Point(87, 461);
            this.ZC.Name = "ZC";
            this.ZC.Size = new System.Drawing.Size(85, 22);
            this.ZC.TabIndex = 19;
            this.ZC.Text = "ZipCode:";
            // 
            // FnMark
            // 
            this.FnMark.AutoSize = true;
            this.FnMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FnMark.ForeColor = System.Drawing.Color.Red;
            this.FnMark.Location = new System.Drawing.Point(182, 236);
            this.FnMark.Name = "FnMark";
            this.FnMark.Size = new System.Drawing.Size(0, 22);
            this.FnMark.TabIndex = 20;
            // 
            // lnMark
            // 
            this.lnMark.AutoSize = true;
            this.lnMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnMark.ForeColor = System.Drawing.Color.Red;
            this.lnMark.Location = new System.Drawing.Point(721, 239);
            this.lnMark.Name = "lnMark";
            this.lnMark.Size = new System.Drawing.Size(0, 22);
            this.lnMark.TabIndex = 21;
            // 
            // unMark
            // 
            this.unMark.AutoSize = true;
            this.unMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unMark.ForeColor = System.Drawing.Color.Red;
            this.unMark.Location = new System.Drawing.Point(182, 301);
            this.unMark.Name = "unMark";
            this.unMark.Size = new System.Drawing.Size(0, 22);
            this.unMark.TabIndex = 22;
            // 
            // pdMark
            // 
            this.pdMark.AutoSize = true;
            this.pdMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pdMark.ForeColor = System.Drawing.Color.Red;
            this.pdMark.Location = new System.Drawing.Point(721, 304);
            this.pdMark.Name = "pdMark";
            this.pdMark.Size = new System.Drawing.Size(0, 22);
            this.pdMark.TabIndex = 23;
            // 
            // BsMark
            // 
            this.BsMark.AutoSize = true;
            this.BsMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BsMark.ForeColor = System.Drawing.Color.Red;
            this.BsMark.Location = new System.Drawing.Point(182, 366);
            this.BsMark.Name = "BsMark";
            this.BsMark.Size = new System.Drawing.Size(0, 22);
            this.BsMark.TabIndex = 24;
            // 
            // emailMark
            // 
            this.emailMark.AutoSize = true;
            this.emailMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailMark.ForeColor = System.Drawing.Color.Red;
            this.emailMark.Location = new System.Drawing.Point(721, 428);
            this.emailMark.Name = "emailMark";
            this.emailMark.Size = new System.Drawing.Size(0, 22);
            this.emailMark.TabIndex = 25;
            // 
            // zipMark
            // 
            this.zipMark.AutoSize = true;
            this.zipMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zipMark.ForeColor = System.Drawing.Color.Red;
            this.zipMark.Location = new System.Drawing.Point(182, 428);
            this.zipMark.Name = "zipMark";
            this.zipMark.Size = new System.Drawing.Size(0, 22);
            this.zipMark.TabIndex = 26;
            // 
            // phoneMark
            // 
            this.phoneMark.AutoSize = true;
            this.phoneMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneMark.ForeColor = System.Drawing.Color.Red;
            this.phoneMark.Location = new System.Drawing.Point(182, 493);
            this.phoneMark.Name = "phoneMark";
            this.phoneMark.Size = new System.Drawing.Size(0, 22);
            this.phoneMark.TabIndex = 29;
            // 
            // pnLabel
            // 
            this.pnLabel.AutoSize = true;
            this.pnLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnLabel.ForeColor = System.Drawing.Color.Transparent;
            this.pnLabel.Location = new System.Drawing.Point(50, 524);
            this.pnLabel.Name = "pnLabel";
            this.pnLabel.Size = new System.Drawing.Size(132, 22);
            this.pnLabel.TabIndex = 28;
            this.pnLabel.Text = "Phone Number:";
            // 
            // phoneNumber
            // 
            this.phoneNumber.Location = new System.Drawing.Point(186, 516);
            this.phoneNumber.Mask = "(999) 000-0000";
            this.phoneNumber.Name = "phoneNumber";
            this.phoneNumber.Size = new System.Drawing.Size(137, 30);
            this.phoneNumber.TabIndex = 9;
            // 
            // confirm_Pass
            // 
            this.confirm_Pass.AutoSize = true;
            this.confirm_Pass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirm_Pass.ForeColor = System.Drawing.Color.Transparent;
            this.confirm_Pass.Location = new System.Drawing.Point(552, 394);
            this.confirm_Pass.Name = "confirm_Pass";
            this.confirm_Pass.Size = new System.Drawing.Size(169, 22);
            this.confirm_Pass.TabIndex = 30;
            this.confirm_Pass.Text = " Confirm Password:";
            // 
            // confirm_Passw
            // 
            this.confirm_Passw.Location = new System.Drawing.Point(727, 391);
            this.confirm_Passw.MaxLength = 30;
            this.confirm_Passw.Name = "confirm_Passw";
            this.confirm_Passw.PasswordChar = '*';
            this.confirm_Passw.Size = new System.Drawing.Size(297, 30);
            this.confirm_Passw.TabIndex = 6;
            // 
            // pass_Confirm
            // 
            this.pass_Confirm.AutoSize = true;
            this.pass_Confirm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_Confirm.ForeColor = System.Drawing.Color.Red;
            this.pass_Confirm.Location = new System.Drawing.Point(721, 366);
            this.pass_Confirm.Name = "pass_Confirm";
            this.pass_Confirm.Size = new System.Drawing.Size(0, 22);
            this.pass_Confirm.TabIndex = 32;
            // 
            // Finance_Tracker
            // 
            this.Finance_Tracker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Finance_Tracker.Cursor = System.Windows.Forms.Cursors.Default;
            this.Finance_Tracker.Image = ((System.Drawing.Image)(resources.GetObject("Finance_Tracker.Image")));
            this.Finance_Tracker.Location = new System.Drawing.Point(400, 20);
            this.Finance_Tracker.Name = "Finance_Tracker";
            this.Finance_Tracker.Size = new System.Drawing.Size(436, 194);
            this.Finance_Tracker.TabIndex = 6;
            this.Finance_Tracker.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1202, 693);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.pass_Confirm);
            this.Controls.Add(this.confirm_Passw);
            this.Controls.Add(this.confirm_Pass);
            this.Controls.Add(this.phoneNumber);
            this.Controls.Add(this.phoneMark);
            this.Controls.Add(this.pnLabel);
            this.Controls.Add(this.zipMark);
            this.Controls.Add(this.emailMark);
            this.Controls.Add(this.BsMark);
            this.Controls.Add(this.pdMark);
            this.Controls.Add(this.unMark);
            this.Controls.Add(this.lnMark);
            this.Controls.Add(this.FnMark);
            this.Controls.Add(this.ZC);
            this.Controls.Add(this.Businesslb);
            this.Controls.Add(this.Emaillb);
            this.Controls.Add(this.PD);
            this.Controls.Add(this.UN);
            this.Controls.Add(this.LN);
            this.Controls.Add(this.FN);
            this.Controls.Add(this.Finance_Tracker);
            this.Controls.Add(this.zipCode);
            this.Controls.Add(this.Business);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.First_Name);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.SignUp);
            this.Controls.Add(this.Account);
            this.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.ForeColor = System.Drawing.Color.White;
            this.Location = new System.Drawing.Point(960, 560);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form3";
            this.Text = "Finance Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompleteClose);
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Finance_Tracker)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SignUp;
        private System.Windows.Forms.TextBox Username;
        private System.Windows.Forms.TextBox First_Name;
        private System.Windows.Forms.TextBox Last_Name;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.TextBox Business;
        private System.Windows.Forms.Label Account;
        private System.Windows.Forms.LinkLabel Login;
        private System.Windows.Forms.TextBox zipCode;
        private System.Windows.Forms.PictureBox Finance_Tracker;
        private System.Windows.Forms.Label FN;
        private System.Windows.Forms.Label LN;
        private System.Windows.Forms.Label UN;
        private System.Windows.Forms.Label PD;
        private System.Windows.Forms.Label Emaillb;
        private System.Windows.Forms.Label Businesslb;
        private System.Windows.Forms.Label ZC;
        private System.Windows.Forms.Label FnMark;
        private System.Windows.Forms.Label lnMark;
        private System.Windows.Forms.Label unMark;
        private System.Windows.Forms.Label pdMark;
        private System.Windows.Forms.Label BsMark;
        private System.Windows.Forms.Label emailMark;
        private System.Windows.Forms.Label zipMark;
        private System.Windows.Forms.Label phoneMark;
        private System.Windows.Forms.Label pnLabel;
        private System.Windows.Forms.MaskedTextBox phoneNumber;
        private System.Windows.Forms.Label confirm_Pass;
        private System.Windows.Forms.TextBox confirm_Passw;
        private System.Windows.Forms.Label pass_Confirm;
    }
}

