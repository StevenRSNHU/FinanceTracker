﻿namespace Finance_Tracker_SE
{
    partial class Email_Change
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newEmail_Input = new System.Windows.Forms.TextBox();
            this.confirmNewEmail_Input = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.emMark = new System.Windows.Forms.Label();
            this.email_Confirm = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newEmail_Input
            // 
            this.newEmail_Input.Location = new System.Drawing.Point(177, 126);
            this.newEmail_Input.Name = "newEmail_Input";
            this.newEmail_Input.Size = new System.Drawing.Size(321, 20);
            this.newEmail_Input.TabIndex = 0;
            // 
            // confirmNewEmail_Input
            // 
            this.confirmNewEmail_Input.Location = new System.Drawing.Point(178, 179);
            this.confirmNewEmail_Input.Name = "confirmNewEmail_Input";
            this.confirmNewEmail_Input.Size = new System.Drawing.Size(321, 20);
            this.confirmNewEmail_Input.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(94, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "New Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(76, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Confirm Email:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(243, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 46);
            this.button1.TabIndex = 4;
            this.button1.Text = "Change Email";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // emMark
            // 
            this.emMark.AutoSize = true;
            this.emMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emMark.ForeColor = System.Drawing.Color.Red;
            this.emMark.Location = new System.Drawing.Point(174, 104);
            this.emMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.emMark.Name = "emMark";
            this.emMark.Size = new System.Drawing.Size(0, 19);
            this.emMark.TabIndex = 37;
            // 
            // email_Confirm
            // 
            this.email_Confirm.AutoSize = true;
            this.email_Confirm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_Confirm.ForeColor = System.Drawing.Color.Red;
            this.email_Confirm.Location = new System.Drawing.Point(174, 157);
            this.email_Confirm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.email_Confirm.Name = "email_Confirm";
            this.email_Confirm.Size = new System.Drawing.Size(0, 19);
            this.email_Confirm.TabIndex = 39;
            // 
            // Email_Change
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(32)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.email_Confirm);
            this.Controls.Add(this.emMark);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.confirmNewEmail_Input);
            this.Controls.Add(this.newEmail_Input);
            this.Name = "Email_Change";
            this.Text = "Email_Change";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox newEmail_Input;
        private System.Windows.Forms.TextBox confirmNewEmail_Input;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label emMark;
        private System.Windows.Forms.Label email_Confirm;
    }
}