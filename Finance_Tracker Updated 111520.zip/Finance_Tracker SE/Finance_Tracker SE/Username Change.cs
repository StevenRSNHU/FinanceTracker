﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Finance_Tracker_SE;
using Finance_Tracker_SE.Resources;
using Software_Engineering_Project;

namespace Finance_Tracker_SE
{
    public partial class Username_Change : Form
    {
        public Username_Change()
        {
            InitializeComponent();
        }
        int userId = Form2.userID;

        private void button1_Click(object sender, EventArgs e)
        {
            if (newUsername.Text.Length <= 0 || newUsername.Text.Length >= 31 || confirmUsername.Text != confirmUsername.Text)
            {
                if (confirmUsername.Text != newUsername.Text)
                {
                    username_Confirm.Text = ("* Usernames Do Not Match");
                    confirmUsername.Text = "";

                }
                else
                {
                    usMark.Text = ("* Invaild Username: input Username that is between 1 and 30 in length");
                    newUsername.Text = "";
                }
            }

            if (!(newUsername.Text.Length <= 0 || newUsername.Text.Length >= 31 || confirmUsername.Text != confirmUsername.Text))
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "update userinfo SET username ='" + newUsername.Text + "' Where id ='" + userId + "'"; // the command

                con.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Username Changed");

                con.Close();
                this.Close();

            }
        }
    }
}
