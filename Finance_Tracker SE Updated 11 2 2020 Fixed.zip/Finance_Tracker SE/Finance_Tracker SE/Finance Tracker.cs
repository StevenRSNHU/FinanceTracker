﻿/***

Program:  Finance Tracker

Purpose: To allow Business to keep Track of there Expensices,Sales and profit 

Author:  Tyler Scott, Aaliyah Ortiz, Steven Renfree

Date: October 12,2020

*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finance_trackerDataSet3.itempart' table. You can move, or remove it, as needed.
            this.itempartTableAdapter1.Fill(this.finance_trackerDataSet3.itempart);
            // TODO: This line of code loads data into the 'finance_trackerDataSet2.item' table. You can move, or remove it, as needed.
            this.itemTableAdapter1.Fill(this.finance_trackerDataSet2.item);
            // TODO: This line of code loads data into the 'finance_trackerDataSet1.itempart' table. You can move, or remove it, as needed.
            this.itempartTableAdapter.Fill(this.finance_trackerDataSet1.itempart);
            // TODO: This line of code loads data into the 'finance_trackerDataSet.item' table. You can move, or remove it, as needed.
            //this.itemTableAdapter.Fill(this.finance_trackerDataSet.item);

            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now;
            dateTimePicker3.Value = DateTime.Now;
           

        }

        private void Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Page_Click(object sender, EventArgs e)
        {
            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }

        private void DataInput_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = true;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }

        private void DataPage_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = true;
            Profile_Page.Visible = false;
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = true;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }
        private void Profile_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = true;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Graph_Page_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void FinancePanel_Paint(object sender, PaintEventArgs e)
        {
            
        }


        private void Item_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Input_Click_1(object sender, EventArgs e)
        {
        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void InputData_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Input_Click_2(object sender, EventArgs e)
        {
            //Clears the error labels
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
            spMark.Text = "";
            amMark.Text = "";
            asMark.Text = "";
            dateMark.Text = "";
            dataAdded.Text = "";
            int Month = 0, Year = 0;

            //Checks inputs
            if (ItemId.Text.Length <= 0)
            {
                ItemId.Text = "";
                idMark.Text = "* Item ID: Is Required";
            }
            if ((Item_Name.Text.Length >= 31) || (Item_Name.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemName length please input item name with 30 chars or less";
                Item_Name.Text = "";
            }

            if (Cost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost: Is Required";
                Cost.Text = "";
            }

            if (Selling_Price.Text.Length <= 0)
            {
                spMark.Text = "* Selling Price: Is Required";
                Selling_Price.Text = "";
            }

            if (Amount_Sold.Text.Length <= 0)
            {
                asMark.Text = "* Amount Sold: Is Required";
                Amount_Sold.Text = "";
            }

            if (Amount_Made.Text.Length <= 0)
            {
                amMark.Text = "* Amount Made: Is Required";
                Amount_Made.Text = "";
            }



            else
            {

                Month = Convert.ToInt32(dateTimePicker2.Value.ToString("MM"));
                Year = Convert.ToInt32(dateTimePicker1.Value.ToString("yyyy"));
                MessageBox.Show(Convert.ToString(Month));
                MessageBox.Show(Convert.ToString(Year));
                int userId = Form2.userID;

                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into item(document,userID,itemId,itemname,costToMake,sellingPrice,AmountSold,AmountMade,Month,Year) Values('" + "0" + "','" + userId + "','" + Item_Id.Text + "','" + Item_Name.Text + "','" + Convert.ToDouble(Cost.Text) + "','" + Convert.ToDouble(Selling_Price.Text) + "','" + Amount_Sold.Text + "','" + Amount_Made.Text + "','" + Month + "','" + Year + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                dataAdded.Text = "Data has been Inputed";
                con.Close();

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView1.DataSource;
            bs.Filter = "itemName like '%" + richTextBox1.Text + "%'";
            dataGridView1.DataSource = bs;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Data_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInfoPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView2.DataSource;
            bs.Filter = "itemName like '%" + richTextBox2.Text + "%'";
            dataGridView2.DataSource = bs;
        }

        private void partInputPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInputPanel_Paint(object sender, PaintEventArgs e)
        {

        }
       
        private void inputPartBttn_Click_1(object sender, EventArgs e)
        {
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
           

            if (ItemIdInput.Text.Length <= 0)
            {
                ItemIdInput.Text = "";
                idMark.Text = "* Item Id: Is Required";
            }
            if (PartId.Text.Length <= 0)
            {
                PartId.Text = "";
                idMark.Text = "* Part Id: Is Required";
            }
          
            if ((ItemNameInput.Text.Length >= 31) || (ItemNameInput.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemNameInput length please input item name with 30 chars or less";
                ItemNameInput.Text = "";
            }
            if ((PartName.Text.Length >= 31) || (PartName.Text.Length <= 0))
            {
                inMark.Text = "* Invalid PartName length please input item name with 30 chars or less";
                PartName.Text = "";
            }
            if (PartCost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost of Part: Is Required";
                PartCost.Text = "";
            }
            if(NumOfPartsInput.Text.Length <= 0)
            {
                NumOfPartsInput.Text = "";
                ictmMark.Text = "* # of Parts: Is Required";
            }
            
            else
            {
                int userId = Form2.userID;
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                var deliveryDate = Convert.ToString(dateTimePicker2.Value.ToString("yyyy-MM-dd"));
                cmd.CommandText = "Insert into itempart(document,userID,partId,itemId,itemName,partName,partCost,numofParts,partArrival) Values('" + "0" + "','" + userId + "','"  + PartId.Text + "','" + ItemIdInput.Text + "','" + ItemNameInput.Text + "','"  + PartName.Text + "','"+ Convert.ToDouble(PartCost.Text) + "','" + NumOfPartsInput.Text + "','" + Convert.ToString(deliveryDate) + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                partDataAdded.Text = "Data has been Inputed";
                con.Close();

            }
        }

        private void mainInput_Click(object sender, EventArgs e)
        {
            
            if (weekCost.Text.Length <= 0)
            {
                weekCost.Text = "";
                costMark.Text = "* Weekly Cost: Is Required";
            }
            if (weekSales.Text.Length <= 0)
            {
                weekSales.Text = "";
                saleMark.Text = "* week Sales: Is Required";
            }

            else
            {
                int userId = Form2.userID;
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                string currentDate = Convert.ToString(dateTimePicker3.Value.ToString("yyyy-MM-dd"));
                int day = 0, month = 0, year = 0, weeksProfit = 0;
                weeksProfit = Convert.ToInt32(weekSales.Text) - Convert.ToInt32(weekCost.Text);
                day = Convert.ToInt32(dateTimePicker3.Value.ToString("dd"));
                month = Convert.ToInt32(dateTimePicker3.Value.ToString("MM"));
                year = Convert.ToInt32(dateTimePicker3.Value.ToString("yyyy"));

                cmd.CommandText = "Insert into mainInput(document,userID,weekCost,weekSales,weekProfit,currentDate,day,month,year) Values('" + "0" + "','" + userId + "','"  + weekCost.Text + "','" + weekSales.Text + "','" + weeksProfit + "','" + currentDate + "','" + day + "','" + month + "','" + year + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                partDataAdded.Text = "Data has been Inputed";
                con.Close();

            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Searchlabel_Click(object sender, EventArgs e)
        {

        }

        private void MonthGraphBttn_Click(object sender, EventArgs e)
        {

        }

        private void YearGraphBttn_Click(object sender, EventArgs e)
        {
           
        }

        private void GraphData_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void InputItemInfoBttn_Click_1(object sender, EventArgs e)
        {
            itemInputPanel.Visible = true;
            partInputPanel.Visible = false;
            input_MD.Visible = false;
        }

        private void InputPartInfoBttn_Click_1(object sender, EventArgs e)
        {
            itemInputPanel.Visible = false;
            partInputPanel.Visible = true;
            input_MD.Visible = false;
        }

        private void mainInput_Button_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = false;
            partInputPanel.Visible = false;
            input_MD.Visible = true;
        }

        private void InputData_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void MonthGraphBttn_Click_1(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            MySqlDataReader dRead; // to read the data base
            double cost;
            int userId = Form2.userID;
            con.Open(); // opens connection
            int month = 11;


            cmd.CommandText = "SELECT weekCost FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
            using (dRead = cmd.ExecuteReader()) // executes the search command
            {
                if (dRead.Read())
                {

                    cost = Convert.ToDouble(dRead.GetValue(0).ToString());

                    GraphData.Series["Costs"].Points.AddXY("May", cost);
                }
                con.Close();
                dRead.Close();
            }
        }

        private void mainInput_Button_Click_1(object sender, EventArgs e)
        {
            itemInputPanel.Visible = false;
            partInputPanel.Visible = false;
            input_MD.Visible = true;
            Input_Page.Text = "Main Input";
        }

        private void InputItemInfoBttn_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = true;
            partInputPanel.Visible = false;
            input_MD.Visible = false;
            Input_Page.Text = "Item Input";
        }

        private void InputPartInfoBttn_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = false;
            partInputPanel.Visible = true;
            input_MD.Visible = false;
            Input_Page.Text = "Item Part Input";
        }
    }

}
