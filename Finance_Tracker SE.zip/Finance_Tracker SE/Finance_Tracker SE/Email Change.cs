﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Finance_Tracker_SE;
using Finance_Tracker_SE.Resources;
using Software_Engineering_Project;

namespace Finance_Tracker_SE
{
    public partial class Email_Change : Form
    {
        public Email_Change()
        {
            InitializeComponent();
        }
        int userId = Form2.userID;
        private void emMark_Click(object sender, EventArgs e)
        {

        }

        private void confirmNewEmail_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void email_Confirm_Click(object sender, EventArgs e)
        {

        }

        private void newEmail_Input_TextChanged(object sender, EventArgs e)
        {

        }

        private void changeEmail_Click(object sender, EventArgs e)
        {
            if (newEmail_Input.Text.Contains("@"))
            {
                if (newEmail_Input.Text.Contains(".com") || newEmail_Input.Text.Contains(".net") || newEmail_Input.Text.Contains("yahoo"))
                {
                    MessageBox.Show("Valid Email");
                }
            }
            else
            {
                emMark.Text = "* Not A valid Email";
            }

            if (newEmail_Input.Text.Length <= 0 || newEmail_Input.Text.Length >= 31 || confirmNewEmail_Input.Text != confirmNewEmail_Input.Text || password.Text.Length <= 0 || password.Text.Length >= 31)
            {
                if (confirmNewEmail_Input.Text != newEmail_Input.Text)
                {
                    email_Confirm.Text = ("* Emails Do Not Match");
                    confirmNewEmail_Input.Text = "";

                }
                else
                {
                    emMark.Text = ("* Invaild Email: input Email that is between 1 and 30 in length");
                    newEmail_Input.Text = "";
                }
            }

            if (!(newEmail_Input.Text.Length <= 0 || newEmail_Input.Text.Length >= 31 || confirmNewEmail_Input.Text != confirmNewEmail_Input.Text || password.Text.Length <= 0 || password.Text.Length >= 31))
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "update userinfo SET email ='" + newEmail_Input.Text + "' Where id ='" + userId + "' AND password ='" + password.Text + "'"; // the command

                con.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Email Changed");

                con.Close();
                this.Close();

            }
        }

        private void Email_Change_Load(object sender, EventArgs e)
        {

        }
    }
}
