﻿/***

Program:  Finance Tracker

Purpose: To allow Business to keep Track of there Expensices,Sales and profit 

Author:  Tyler Scott, Aaliyah Ortiz, Steven Renfree

Date: October 12,2020

*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Windows.Forms.DataVisualization.Charting;
using Finance_Tracker_SE;
using MySql.Data.MySqlClient;
using Finance_Tracker_SE.Resources;

namespace Software_Engineering_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            this.Exit.Image = Resource.ExitClose;
           // this.Home_Page.BackgroundImage = Resource1.HomePage2;
            //this.DataInput.BackgroundImage = Resource1.Input_Page2;
            //this.Profile.BackgroundImage = Resource1.Profile2;
            //this.DataPage.BackgroundImage = Resource1.SearchData;
            //this.Graph.BackgroundImage = Resource1.Graph_Page_2;

            int userId = Form2.userID;
            MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            MySqlDataReader dRead; // to read the data base
            cmd.CommandText = "SELECT username,firstName,lastName,email,nameOfBusiness FROM userinfo where id='" + userId + "'"; // the command
            string username = "";
            string firstName = "";
            string lastName = "";
            string email = "";
            string businessName = "";
            con.Open();

            using (dRead = cmd.ExecuteReader()) // executes the search command
            {
                if (dRead.Read())
                {
                    username = Convert.ToString(dRead.GetValue(0).ToString());
                    firstName = Convert.ToString(dRead.GetValue(1).ToString());
                    lastName = Convert.ToString(dRead.GetValue(2).ToString());
                    email = Convert.ToString(dRead.GetValue(3).ToString());
                    businessName = Convert.ToString(dRead.GetValue(4).ToString());
                }
            }
            con.Close();
            dRead.Close();

            HomePg.Text = "Welcome " + username + " to The HomePage";
            fullName_lbl.Text = firstName + " " + lastName;
            emailAddress_lbl.Text = email;
            username_lbl.Text = username;
            business_lbl.Text = businessName;

            // TODO: This line of code loads data into the 'finance_trackerDataSet3.itempart' table. You can move, or remove it, as needed.
            //this.itempartTableAdapter1.Fill(this.finance_trackerDataSet3.itempart);
            // TODO: This line of code loads data into the 'finance_trackerDataSet2.item' table. You can move, or remove it, as needed.
            this.itemTableAdapter1.Fill(this.finance_trackerDataSet2.item);
            // TODO: This line of code loads data into the 'finance_trackerDataSet1.itempart' table. You can move, or remove it, as needed.
            this.itempartTableAdapter.Fill(this.finance_trackerDataSet1.itempart);
            // TODO: This line of code loads data into the 'finance_trackerDataSet.item' table. You can move, or remove it, as needed.
            //this.itemTableAdapter.Fill(this.finance_trackerDataSet.item);

            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now;
           
           

        }

        private void Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Page_Click(object sender, EventArgs e)
        {
            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }

        private void DataInput_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = true;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }

        private void DataPage_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = true;
            Profile_Page.Visible = false;
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = true;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }
        private void Profile_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = true;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Graph_Page_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void FinancePanel_Paint(object sender, PaintEventArgs e)
        {
            
        }


        private void Item_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Input_Click_1(object sender, EventArgs e)
        {
        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void InputData_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Input_Click_2(object sender, EventArgs e)
        {
            //Clears the error labels
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
            spMark.Text = "";
            amMark.Text = "";
            asMark.Text = "";
            dateMark.Text = "";
            dataAdded.Text = "";
            int Month = 0, Year = 0;

            //Checks inputs
            if (ItemId.Text.Length <= 0)
            {
                ItemId.Text = "";
                idMark.Text = "* Item ID: Is Required";
            }
            if ((Item_Name.Text.Length >= 31) || (Item_Name.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemName length please input item name with 30 chars or less";
                Item_Name.Text = "";
            }

            if (Cost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost: Is Required";
                Cost.Text = "";
            }

            if (Selling_Price.Text.Length <= 0)
            {
                spMark.Text = "* Selling Price: Is Required";
                Selling_Price.Text = "";
            }

            if (Amount_Sold.Text.Length <= 0)
            {
                asMark.Text = "* Amount Sold: Is Required";
                Amount_Sold.Text = "";
            }

            if (Amount_Made.Text.Length <= 0)
            {
                amMark.Text = "* Amount Made: Is Required";
                Amount_Made.Text = "";
            }



            else
            {

                Month = Convert.ToInt32(dateTimePicker2.Value.ToString("MM"));
                Year = Convert.ToInt32(dateTimePicker1.Value.ToString("yyyy"));
                int userId = Form2.userID;

                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into item(document,userID,itemId,itemname,costToMake,sellingPrice,AmountSold,AmountMade,Month,Year) Values('" + "0" + "','" + userId + "','" + Item_Id.Text + "','" + Item_Name.Text + "','" + Convert.ToDouble(Cost.Text) + "','" + Convert.ToDouble(Selling_Price.Text) + "','" + Amount_Sold.Text + "','" + Amount_Made.Text + "','" + Month + "','" + Year + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                dataAdded.Text = "Data has been Inputed";
                con.Close();

                double cost = (Convert.ToDouble(Cost.Text) * Convert.ToDouble(Amount_Made.Text));
                double profit =(Convert.ToDouble(Amount_Sold.Text) * Convert.ToDouble(Selling_Price.Text)) - cost;
                double sales = (Convert.ToDouble(Amount_Sold.Text) * Convert.ToDouble(Selling_Price.Text));


                cmd.CommandText = "Insert into finalproduct(document,id,itemName,month,year,cost,sales,profit) Values('" + "0" + "','" + userId + "','" + Item_Name.Text + "','" + Convert.ToInt32(Month) + "','" + Convert.ToInt32(Year) + "','" + cost + "','" +  sales + "','" + profit + "')"; // th+e command
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView1.DataSource;
            bs.Filter = "itemName like '%" + richTextBox1.Text + "%'";
            dataGridView1.DataSource = bs;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Data_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInfoPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView2.DataSource;
            bs.Filter = "itemName like '%" + richTextBox2.Text + "%'";
            dataGridView2.DataSource = bs;
        }

        private void partInputPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInputPanel_Paint(object sender, PaintEventArgs e)
        {

        }
       
        private void inputPartBttn_Click_1(object sender, EventArgs e)
        {
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
           

            if (ItemIdInput.Text.Length <= 0)
            {
                ItemIdInput.Text = "";
                idMark.Text = "* Item Id: Is Required";
            }
            if (PartId.Text.Length <= 0)
            {
                PartId.Text = "";
                idMark.Text = "* Part Id: Is Required";
            }
          
            if ((ItemNameInput.Text.Length >= 31) || (ItemNameInput.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemNameInput length please input item name with 30 chars or less";
                ItemNameInput.Text = "";
            }
            if ((PartName.Text.Length >= 31) || (PartName.Text.Length <= 0))
            {
                inMark.Text = "* Invalid PartName length please input item name with 30 chars or less";
                PartName.Text = "";
            }
            if (PartCost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost of Part: Is Required";
                PartCost.Text = "";
            }
            if(NumOfPartsInput.Text.Length <= 0)
            {
                NumOfPartsInput.Text = "";
                ictmMark.Text = "* # of Parts: Is Required";
            }
            
            else
            {
                int userId = Form2.userID;
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                var deliveryDate = Convert.ToString(dateTimePicker2.Value.ToString("yyyy-MM-dd"));
                cmd.CommandText = "Insert into itempart(document,userID,partId,itemId,itemName,partName,partCost,numofParts,partArrival) Values('" + "0" + "','" + userId + "','"  + PartId.Text + "','" + ItemIdInput.Text + "','" + ItemNameInput.Text + "','"  + PartName.Text + "','"+ Convert.ToDouble(PartCost.Text) + "','" + NumOfPartsInput.Text + "','" + Convert.ToString(deliveryDate) + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                partDataAdded.Text = "Data has been Inputed";
                con.Close();

              /*  double cost = Convert.ToDouble(NumOfPartsInput.Text) * Convert.ToDouble(PartCost.Text);
                var month = Convert.ToString(dateTimePicker2.Value.ToString("MM"));
                var year = Convert.ToString(dateTimePicker2.Value.ToString("yyyy"));
                cmd.CommandText = "Insert into finalproduct(document,id,itemName,partName,month,year,cost,sales,profit) Values('" + "0" + "','" + userId + "','" + ItemNameInput.Text + "','" + PartName.Text + "','" + Convert.ToInt32(month) + "','" + Convert.ToInt32(year) + "','" + cost + "','" + " 0.0 " + "','" + " 0.0" + "')"; // th+e command
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close(); */

            }
        }

        
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Searchlabel_Click(object sender, EventArgs e)
        {

        }

        private void MonthGraphBttn_Click(object sender, EventArgs e)
        {

        }

        private void YearGraphBttn_Click(object sender, EventArgs e)
        {
           
        }

        private void GraphData_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }


        private void InputData_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void MonthGraphBttn_Click_1(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("server=localhost; user id=Guess; password = 200109; persistsecurityinfo=True; database=finance_tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            MySqlDataReader dRead; // to read the data base
            double cost = 0;
            double sales = 0;
            double profit = 0;
            int userId = Form2.userID;
            Graphpg.Text = "Monthly Data";

            GraphData.Series[0].Points.Clear();
            GraphData.Series[1].Points.Clear();
            GraphData.Series[2].Points.Clear();
            con.Open(); // opens connection

            for (int i = 0; i <= 12; i++)
            {
                int month = i;
                string Months = "1";
                con.Close();
                con.Open();

                if ((month == 1))
                {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        Months = "1";
                        GraphData.Series[0].Points.AddXY(Months, cost);
                    }
                    dRead.Close();
                    
                    cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[1].Points.AddXY(Months, sales);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[2].Points.AddXY(Months, profit);
                    }
                    dRead.Close();
                    
                }

                if ((month == 2))
                {

                    cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        Months = "2";
                        GraphData.Series[0].Points.AddXY(Months, cost);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[1].Points.AddXY(Months, sales);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
 
                        GraphData.Series[2].Points.AddXY(Months, profit);

                    }
                    dRead.Close();
                }
                if ((month == 3))
                {
                    cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        Months = "3";
                        GraphData.Series[0].Points.AddXY(Months, cost);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[1].Points.AddXY(Months, sales);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[2].Points.AddXY(Months, profit);
                    }
                    dRead.Close();
                }
                if ((month == 4))
                {
                    cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        Months = "4";
                        GraphData.Series[0].Points.AddXY(Months, cost);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[1].Points.AddXY(Months, sales);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[2].Points.AddXY(Months, profit);

                    }
                    dRead.Close();
                }
                   if ((month == 5))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "5";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }

                    if ((month == 6))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "6";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }
                    if ((month == 7))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "7";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }
                    if ((month == 8))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "8";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }

                    if ((month == 9))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "9";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }

                    if ((month == 10))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "10";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }
                    if ((month == 11))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "11";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }
                    if ((month == 12))
                    {
                        cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            Months = "12";
                            GraphData.Series[0].Points.AddXY(Months, cost);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[1].Points.AddXY(Months, sales);
                        }
                        dRead.Close();

                        cmd.CommandText = "SELECT weekProfit FROM mainInput where userID='" + userId + "' AND month ='" + month + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {

                                profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                            }
                            GraphData.Series[2].Points.AddXY(Months, profit);
                        }
                        dRead.Close();
                    }
                con.Close();
            }
        }
        private void YearGraphBttn_Click_1(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("server=localhost; user id=Guess; password = 200109; persistsecurityinfo=True; database=finance_tracker"); // makes con with the connection info
            MySqlCommand cmd = new MySqlCommand(); //makes cmd
            cmd.Connection = con; // makes command connection to con
            MySqlDataReader dRead; // to read the data base
            double cost = 0;
            double sales = 0;
            double profit = 0;
            int currentYear = DateTime.Today.Year;
            int pastYear = currentYear - 1;
            int userId = Form2.userID;
            Graphpg.Text = "Yearly Data";

            GraphData.Series[0].Points.Clear();
            GraphData.Series[1].Points.Clear();
            GraphData.Series[2].Points.Clear();
            con.Open(); // opens connection
                
                    cmd.CommandText = "SELECT cost FROM finalproduct where id='" + userId + "' AND year ='" + pastYear + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[0].Points.AddXY(pastYear, cost);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND year ='" + pastYear + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[1].Points.AddXY(pastYear, sales);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT profit FROM finalproduct where id='" + userId + "' AND year ='" + pastYear + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[2].Points.AddXY(pastYear, profit);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT weekCost FROM mainInput where userID='" + userId + "' AND year ='" + currentYear + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            cost = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        
                        GraphData.Series[0].Points.AddXY(currentYear, cost);
                    }
                    dRead.Close();

                    cmd.CommandText = "SELECT sales FROM finalproduct where id='" + userId + "' AND year ='" + currentYear + "'"; // the command
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read())
                        {

                            sales = Convert.ToDouble(dRead.GetValue(0).ToString());
                        }
                        GraphData.Series[1].Points.AddXY(currentYear, sales);
                    }
                    dRead.Close();

            cmd.CommandText = "SELECT profit FROM finalproduct where id='" + userId + "' AND year ='" + currentYear + "'"; // the command
            using (dRead = cmd.ExecuteReader()) // executes the search command
            {
                if (dRead.Read())
                {

                    profit = Convert.ToDouble(dRead.GetValue(0).ToString());
                }
                GraphData.Series[2].Points.AddXY(currentYear, profit);
            }
            dRead.Close();

        }


        private void InputItemInfoBttn_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = true;
            partInputPanel.Visible = false;
            Input_Page.Text = "Item Input";
        }

        private void InputPartInfoBttn_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = false;
            partInputPanel.Visible = true;
            Input_Page.Text = "Item Part Input";
        }

       /* void changeDoor()
        {

        } */

        private void GraphData_Click_1(object sender, EventArgs e)
        {

        }

        private void Exit_MouseHover(object sender, EventArgs e)
        {
            this.Exit.Image = Resource.ExitOpen;
            SoundPlayer door = new SoundPlayer(Resource.sound_door);
            door.Play();

        }

        private void Exit_MouseLeave(object sender, EventArgs e)
        {
            
            this.Exit.Image = Resource.ExitClose; 
        }

        private void passChange_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Password_Change p1 = new Password_Change();
            p1.Show();
        }

        private void emailChange_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Email_Change p2 = new Email_Change();
            p2.Show();
        }

        private void usernameChange_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Username_Change p3 = new Username_Change();
            p3.Show();
        }

        private void DataPage_ItemInfoBttn_Click(object sender, EventArgs e)
        {
            itemInfoPanel.Visible = true;
            itemPartPanel.Visible = false;
            profitSalesPanel.Visible = false;
        }

        private void DataPage_ItemPartBttn_Click(object sender, EventArgs e)
        {
            itemInfoPanel.Visible = false;
            itemPartPanel.Visible = true;
            profitSalesPanel.Visible = false;
        }

        private void DataPage_ProfitBttn_Click(object sender, EventArgs e)
        {
            itemInfoPanel.Visible = false;
            itemPartPanel.Visible = false;
            profitSalesPanel.Visible = true;
        }

        private void ViewData_ProfitBttn_Click(object sender, EventArgs e)
        {

            var listItemName = itemName_ComboBox.SelectedIndex;
            decimal itemCostMake, itemSellingPrice;
            int itemAmountSold, itemAmountMade;


            if (itemName_ComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a value");
            }
            else
            {
                //int profitMonth = 0, profitYear = 0;
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                MySqlDataReader dbRead; // to read the data base

                //start of week calender convertor
                int startOfWeekMonth = Convert.ToInt32(dateTimePicker_StartWeek.Value.ToString("MM"));
                int startOfWeekYear = Convert.ToInt32(dateTimePicker_StartWeek.Value.ToString("yyyy"));

                //end of week calender convertor
                int endOfWeekMonth = Convert.ToInt32(dateTimePicker_EndWeek.Value.ToString("MM"));
                int endOfWeekYear = Convert.ToInt32(dateTimePicker_EndWeek.Value.ToString("yyyy"));

                SearchUsingDateTimePicker(); //validation for date time pickers

                cmd.CommandText = "SELECT costToMake,sellingPrice,AmountSold,AmountMade,Month,Year FROM item WHERE itemName ='" + listItemName + "'and Month BETWEEN '" + startOfWeekMonth + "' and '" + endOfWeekMonth + "' and Year BETWEEN '" + startOfWeekYear + "' and '" + endOfWeekYear + "'"; //add month and year
                //create connections from fields to database


                con.Open();
                dbRead = cmd.ExecuteReader();
                while (dbRead.Read())
                {

                    itemCostMake = Convert.ToDecimal(dbRead["costToMake"]);
                    itemSellingPrice = Convert.ToDecimal(dbRead["sellingPrice"]);
                    itemAmountSold = Convert.ToInt32(dbRead["AmountSold"].ToString());
                    itemAmountMade = Convert.ToInt32(dbRead["AmountMade"].ToString());

                    decimal totalSales = itemSellingPrice * itemAmountSold; //totalSales_Data
                    decimal costOfGoods = itemCostMake * itemAmountSold;
                    decimal grossProfit = totalSales - costOfGoods; //GrossProfit_Data
                    decimal totalExpense = totalSales - grossProfit;
                    decimal totalProfit = totalSales - totalExpense; //totalProfit_Data

                    decimal grossProfitMargin = grossProfit / totalSales; //GrossProfitMargin_Data
                    decimal markupPercent = ((itemSellingPrice - itemCostMake) / itemCostMake) / 100; //MarkPercent_Data


                    totalSales_Data.Text = totalSales.ToString();
                    totalProfit_Data.Text = totalProfit.ToString();
                    GrossProfit_Data.Text = grossProfit.ToString();
                    GrossProfitMargin_Data.Text = grossProfitMargin.ToString();

                    MarkPercent_Data.Text = string.Format("{0:p}", markupPercent);
                    MarkPercent_Data.Text = markupPercent.ToString("p");

                    totalSales_Data.Text = "$" + totalSales + "";


                    /*
                    ProfitSales_Chart.Series["Profit"].Points.AddXY("Total Profit", totalProfit);
                    ProfitSales_Chart.Series["Profit"].Points.AddXY("Gross Profit", grossProfit);
                    ProfitSales_Chart.Series["Profit"].Points.AddXY("Gross Profit Margin", grossProfitMargin);
                    ProfitSales_Chart.Series["Sales"].Points.AddXY("Total Sales", totalSales);
                    */

                }

                // DataAdded_Main.Text = "Data has been Inputed";
                con.Close();
            }
        }

        private void SearchUsingDateTimePicker()
        {

            string startDate = this.dateTimePicker_StartWeek.Value.ToShortDateString();
            string endDate = this.dateTimePicker_EndWeek.Value.ToShortDateString();

            string keyword = string.Empty;

            DateRange_Lbl.Text = "";

            DateTime startWeek = Convert.ToDateTime(dateTimePicker_StartWeek.Text);
            DateTime endWeek = Convert.ToDateTime(dateTimePicker_EndWeek.Text);

            if (startWeek > endWeek)
            {
                DateRange_Lbl.Text = "* Fix the date range";
            }
            else
            {
                TimeSpan ts = endWeek.Subtract(startWeek);
                int days = Convert.ToInt32(ts.Days);
            }
        }

        private void Profile_Page_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void usernameLbl_Click(object sender, EventArgs e)
        {

        }
    }

}
