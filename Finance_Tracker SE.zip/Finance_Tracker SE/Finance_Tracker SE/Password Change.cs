﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Finance_Tracker_SE;
using Finance_Tracker_SE.Resources;
using Software_Engineering_Project;

namespace Finance_Tracker_SE
{
    public partial class Password_Change : Form
    {
        public Password_Change()
        {
            InitializeComponent();

        }
        int userId = Form2.userID;
        private void passChange_Click(object sender, EventArgs e)
        {
            if (oldPassword.Text == "")
            {
                pdMark.Text = "* Requires Password";
            }
            else
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                MySqlDataReader dRead; // to read the data base
                string password = " ";
                con.Open(); // opens connection

                        cmd.CommandText = "SELECT password FROM userinfo where id='" + userId + "'"; // the command
                        using (dRead = cmd.ExecuteReader()) // executes the search command
                        {
                            if (dRead.Read())
                            {
                                password = Convert.ToString(dRead.GetValue(0).ToString());
                            }
                        }
                        con.Close();
                        dRead.Close();
                if (oldPassword.Text == password)
                {
                    if (Password.Text.Length <= 0 || Password.Text.Length >= 31 || confirm_Passw.Text != Password.Text)
                    {
                        if (confirm_Passw.Text != Password.Text)
                        {
                            pass_Confirm.Text = ("* Passwords Do Not Match");
                            confirm_Passw.Text = "";

                        }
                        else
                        {
                            pdMark.Text = ("* Invaild Password: input Password that is between 1 and 30 in length");
                            Password.Text = "";
                        }
                    }
                    if (!(Password.Text.Length <= 0 || Password.Text.Length >= 31 || confirm_Passw.Text != Password.Text))
                    {
                        cmd.Connection = con; // makes command connection to con
                        cmd.CommandText = "update userinfo SET password ='" + Password.Text + "' Where id ='" + userId + "'"; // the command

                        con.Open();
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Password Changed");

                        con.Close();
                        this.Close();

                    }
                }
                else 
                {
                    passMark.Text = "* Incorrect Password";
                }
            }
            }

        private void Password_Change_Load(object sender, EventArgs e)
        {

        }
    }
}
