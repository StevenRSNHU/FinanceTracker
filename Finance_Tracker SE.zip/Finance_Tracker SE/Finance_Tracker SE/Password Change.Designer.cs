﻿namespace Finance_Tracker_SE
{
    partial class Password_Change
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pass_Confirm = new System.Windows.Forms.Label();
            this.confirm_Passw = new System.Windows.Forms.TextBox();
            this.confirm_Pass = new System.Windows.Forms.Label();
            this.pdMark = new System.Windows.Forms.Label();
            this.PD = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.TextBox();
            this.passChange = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.oldPassword = new System.Windows.Forms.TextBox();
            this.passMark = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pass_Confirm
            // 
            this.pass_Confirm.AutoSize = true;
            this.pass_Confirm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_Confirm.ForeColor = System.Drawing.Color.Red;
            this.pass_Confirm.Location = new System.Drawing.Point(285, 203);
            this.pass_Confirm.Name = "pass_Confirm";
            this.pass_Confirm.Size = new System.Drawing.Size(0, 22);
            this.pass_Confirm.TabIndex = 38;
            // 
            // confirm_Passw
            // 
            this.confirm_Passw.Location = new System.Drawing.Point(291, 228);
            this.confirm_Passw.MaxLength = 30;
            this.confirm_Passw.Name = "confirm_Passw";
            this.confirm_Passw.PasswordChar = '*';
            this.confirm_Passw.Size = new System.Drawing.Size(297, 22);
            this.confirm_Passw.TabIndex = 34;
            // 
            // confirm_Pass
            // 
            this.confirm_Pass.AutoSize = true;
            this.confirm_Pass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirm_Pass.ForeColor = System.Drawing.Color.Transparent;
            this.confirm_Pass.Location = new System.Drawing.Point(116, 231);
            this.confirm_Pass.Name = "confirm_Pass";
            this.confirm_Pass.Size = new System.Drawing.Size(169, 22);
            this.confirm_Pass.TabIndex = 37;
            this.confirm_Pass.Text = " Confirm Password:";
            // 
            // pdMark
            // 
            this.pdMark.AutoSize = true;
            this.pdMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pdMark.ForeColor = System.Drawing.Color.Red;
            this.pdMark.Location = new System.Drawing.Point(285, 141);
            this.pdMark.Name = "pdMark";
            this.pdMark.Size = new System.Drawing.Size(0, 22);
            this.pdMark.TabIndex = 36;
            // 
            // PD
            // 
            this.PD.AutoSize = true;
            this.PD.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PD.ForeColor = System.Drawing.Color.Transparent;
            this.PD.Location = new System.Drawing.Point(189, 174);
            this.PD.Name = "PD";
            this.PD.Size = new System.Drawing.Size(94, 22);
            this.PD.TabIndex = 35;
            this.PD.Text = "Password:";
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(289, 166);
            this.Password.MaxLength = 30;
            this.Password.Name = "Password";
            this.Password.PasswordChar = '*';
            this.Password.Size = new System.Drawing.Size(297, 22);
            this.Password.TabIndex = 33;
            // 
            // passChange
            // 
            this.passChange.Location = new System.Drawing.Point(325, 318);
            this.passChange.Name = "passChange";
            this.passChange.Size = new System.Drawing.Size(203, 54);
            this.passChange.TabIndex = 39;
            this.passChange.Text = "Change Password";
            this.passChange.UseVisualStyleBackColor = true;
            this.passChange.Click += new System.EventHandler(this.passChange_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(160, 107);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 21);
            this.label3.TabIndex = 52;
            this.label3.Text = "Old Password:";
            // 
            // oldPassword
            // 
            this.oldPassword.Location = new System.Drawing.Point(289, 107);
            this.oldPassword.Margin = new System.Windows.Forms.Padding(4);
            this.oldPassword.MaxLength = 31;
            this.oldPassword.Name = "oldPassword";
            this.oldPassword.PasswordChar = '*';
            this.oldPassword.Size = new System.Drawing.Size(297, 22);
            this.oldPassword.TabIndex = 51;
            // 
            // passMark
            // 
            this.passMark.AutoSize = true;
            this.passMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passMark.ForeColor = System.Drawing.Color.Red;
            this.passMark.Location = new System.Drawing.Point(287, 81);
            this.passMark.Name = "passMark";
            this.passMark.Size = new System.Drawing.Size(0, 22);
            this.passMark.TabIndex = 53;
            // 
            // Password_Change
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(32)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.passMark);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.oldPassword);
            this.Controls.Add(this.passChange);
            this.Controls.Add(this.pass_Confirm);
            this.Controls.Add(this.confirm_Passw);
            this.Controls.Add(this.confirm_Pass);
            this.Controls.Add(this.pdMark);
            this.Controls.Add(this.PD);
            this.Controls.Add(this.Password);
            this.Name = "Password_Change";
            this.Text = "Password_Change";
            this.Load += new System.EventHandler(this.Password_Change_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pass_Confirm;
        private System.Windows.Forms.TextBox confirm_Passw;
        private System.Windows.Forms.Label confirm_Pass;
        private System.Windows.Forms.Label pdMark;
        private System.Windows.Forms.Label PD;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Button passChange;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox oldPassword;
        private System.Windows.Forms.Label passMark;
    }
}