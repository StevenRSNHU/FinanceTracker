﻿namespace Software_Engineering_Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Side1 = new System.Windows.Forms.Panel();
            this.Profile = new System.Windows.Forms.Button();
            this.DataPage = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Graph = new System.Windows.Forms.Button();
            this.DataInput = new System.Windows.Forms.Button();
            this.Home_Page = new System.Windows.Forms.Button();
            this.FinancePanel = new System.Windows.Forms.Panel();
            this.FinanceTracker = new System.Windows.Forms.Label();
            this.HomePage = new System.Windows.Forms.Panel();
            this.HomePg = new System.Windows.Forms.Label();
            this.Graph_Page = new System.Windows.Forms.Panel();
            this.Graphpg = new System.Windows.Forms.Label();
            this.Data = new System.Windows.Forms.Panel();
            this.itemPartPanel = new System.Windows.Forms.Panel();
            this.itemSearchLbl = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.partIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itempartBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet1 = new Finance_Tracker_SE.finance_trackerDataSet1();
            this.itemInfoPanel = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costToMakeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellingPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountSoldDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountMadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.monthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finance_trackerDataSet = new Finance_Tracker_SE.finance_trackerDataSet();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Searchlabel = new System.Windows.Forms.Label();
            this.profitSalesPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.profitSalesBttn = new System.Windows.Forms.Button();
            this.itemPartsBttn = new System.Windows.Forms.Button();
            this.itemInfoBttn = new System.Windows.Forms.Button();
            this.Data_Search = new System.Windows.Forms.Label();
            this.InputData = new System.Windows.Forms.Panel();
            this.dataAdded = new System.Windows.Forms.Label();
            this.ysMark = new System.Windows.Forms.Label();
            this.msMark = new System.Windows.Forms.Label();
            this.asMark = new System.Windows.Forms.Label();
            this.amMark = new System.Windows.Forms.Label();
            this.spMark = new System.Windows.Forms.Label();
            this.ictmMark = new System.Windows.Forms.Label();
            this.inMark = new System.Windows.Forms.Label();
            this.idMark = new System.Windows.Forms.Label();
            this.MonthSold = new System.Windows.Forms.Label();
            this.YearSold = new System.Windows.Forms.Label();
            this.AmountSold = new System.Windows.Forms.Label();
            this.AmountMade = new System.Windows.Forms.Label();
            this.SoldPrice = new System.Windows.Forms.Label();
            this.CostItem = new System.Windows.Forms.Label();
            this.ItemName = new System.Windows.Forms.Label();
            this.ItemId = new System.Windows.Forms.Label();
            this.Amount_Made = new System.Windows.Forms.TextBox();
            this.Input = new System.Windows.Forms.Button();
            this.Year = new System.Windows.Forms.TextBox();
            this.Month = new System.Windows.Forms.TextBox();
            this.Selling_Price = new System.Windows.Forms.TextBox();
            this.Amount_Sold = new System.Windows.Forms.TextBox();
            this.Cost = new System.Windows.Forms.TextBox();
            this.Item_Name = new System.Windows.Forms.TextBox();
            this.Item_Id = new System.Windows.Forms.TextBox();
            this.Input_Page = new System.Windows.Forms.Label();
            this.itemTableAdapter = new Finance_Tracker_SE.finance_trackerDataSetTableAdapters.itemTableAdapter();
            this.Profile_Page = new System.Windows.Forms.Panel();
            this.Profilelab = new System.Windows.Forms.Label();
            this.itempartTableAdapter = new Finance_Tracker_SE.finance_trackerDataSet1TableAdapters.itempartTableAdapter();
            this.itemInputPanel = new System.Windows.Forms.Panel();
            this.partInputPanel = new System.Windows.Forms.Panel();
            this.InputItemInfoBttn = new System.Windows.Forms.Button();
            this.InputPartInfoBttn = new System.Windows.Forms.Button();
            this.ItemIdInput = new System.Windows.Forms.TextBox();
            this.PartId = new System.Windows.Forms.TextBox();
            this.PartCost = new System.Windows.Forms.TextBox();
            this.ItemNameInput = new System.Windows.Forms.TextBox();
            this.PartName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.inputPartBttn = new System.Windows.Forms.Button();
            this.partDataAdded = new System.Windows.Forms.Label();
            this.Side1.SuspendLayout();
            this.FinancePanel.SuspendLayout();
            this.HomePage.SuspendLayout();
            this.Graph_Page.SuspendLayout();
            this.Data.SuspendLayout();
            this.itemPartPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itempartBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet1)).BeginInit();
            this.itemInfoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet)).BeginInit();
            this.profitSalesPanel.SuspendLayout();
            this.InputData.SuspendLayout();
            this.Profile_Page.SuspendLayout();
            this.itemInputPanel.SuspendLayout();
            this.partInputPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Side1
            // 
            this.Side1.BackColor = System.Drawing.Color.Transparent;
            this.Side1.Controls.Add(this.Profile);
            this.Side1.Controls.Add(this.DataPage);
            this.Side1.Controls.Add(this.Exit);
            this.Side1.Controls.Add(this.Graph);
            this.Side1.Controls.Add(this.DataInput);
            this.Side1.Controls.Add(this.Home_Page);
            this.Side1.Controls.Add(this.FinancePanel);
            this.Side1.Location = new System.Drawing.Point(0, 0);
            this.Side1.Margin = new System.Windows.Forms.Padding(2);
            this.Side1.Name = "Side1";
            this.Side1.Size = new System.Drawing.Size(149, 628);
            this.Side1.TabIndex = 1;
            // 
            // Profile
            // 
            this.Profile.BackColor = System.Drawing.Color.Transparent;
            this.Profile.FlatAppearance.BorderSize = 0;
            this.Profile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Profile.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Profile.ForeColor = System.Drawing.Color.White;
            this.Profile.Image = ((System.Drawing.Image)(resources.GetObject("Profile.Image")));
            this.Profile.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Profile.Location = new System.Drawing.Point(-2, 144);
            this.Profile.Margin = new System.Windows.Forms.Padding(2);
            this.Profile.Name = "Profile";
            this.Profile.Size = new System.Drawing.Size(149, 111);
            this.Profile.TabIndex = 6;
            this.Profile.Text = "Profile";
            this.Profile.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Profile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Profile.UseVisualStyleBackColor = false;
            this.Profile.Click += new System.EventHandler(this.Profile_Click);
            // 
            // DataPage
            // 
            this.DataPage.BackColor = System.Drawing.Color.Transparent;
            this.DataPage.FlatAppearance.BorderSize = 0;
            this.DataPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataPage.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataPage.ForeColor = System.Drawing.Color.White;
            this.DataPage.Image = ((System.Drawing.Image)(resources.GetObject("DataPage.Image")));
            this.DataPage.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataPage.Location = new System.Drawing.Point(2, 353);
            this.DataPage.Margin = new System.Windows.Forms.Padding(2);
            this.DataPage.Name = "DataPage";
            this.DataPage.Size = new System.Drawing.Size(149, 92);
            this.DataPage.TabIndex = 5;
            this.DataPage.Text = "Data Page";
            this.DataPage.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataPage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataPage.UseVisualStyleBackColor = false;
            this.DataPage.Click += new System.EventHandler(this.DataPage_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Image = ((System.Drawing.Image)(resources.GetObject("Exit.Image")));
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Exit.Location = new System.Drawing.Point(2, 534);
            this.Exit.Margin = new System.Windows.Forms.Padding(2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(145, 93);
            this.Exit.TabIndex = 4;
            this.Exit.Text = "Exit";
            this.Exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Graph
            // 
            this.Graph.BackColor = System.Drawing.Color.Transparent;
            this.Graph.FlatAppearance.BorderSize = 0;
            this.Graph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Graph.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graph.ForeColor = System.Drawing.Color.White;
            this.Graph.Image = ((System.Drawing.Image)(resources.GetObject("Graph.Image")));
            this.Graph.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Graph.Location = new System.Drawing.Point(1, 448);
            this.Graph.Margin = new System.Windows.Forms.Padding(2);
            this.Graph.Name = "Graph";
            this.Graph.Size = new System.Drawing.Size(147, 82);
            this.Graph.TabIndex = 3;
            this.Graph.Text = "Graph";
            this.Graph.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Graph.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Graph.UseVisualStyleBackColor = false;
            this.Graph.Click += new System.EventHandler(this.Graph_Click);
            // 
            // DataInput
            // 
            this.DataInput.BackColor = System.Drawing.Color.Transparent;
            this.DataInput.FlatAppearance.BorderSize = 0;
            this.DataInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataInput.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.DataInput.ForeColor = System.Drawing.Color.White;
            this.DataInput.Image = ((System.Drawing.Image)(resources.GetObject("DataInput.Image")));
            this.DataInput.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DataInput.Location = new System.Drawing.Point(-2, 258);
            this.DataInput.Margin = new System.Windows.Forms.Padding(2);
            this.DataInput.Name = "DataInput";
            this.DataInput.Size = new System.Drawing.Size(149, 92);
            this.DataInput.TabIndex = 2;
            this.DataInput.Text = "Data Input";
            this.DataInput.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DataInput.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DataInput.UseVisualStyleBackColor = false;
            this.DataInput.Click += new System.EventHandler(this.DataInput_Click);
            // 
            // Home_Page
            // 
            this.Home_Page.BackColor = System.Drawing.Color.Transparent;
            this.Home_Page.FlatAppearance.BorderSize = 0;
            this.Home_Page.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home_Page.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Home_Page.ForeColor = System.Drawing.Color.White;
            this.Home_Page.Image = ((System.Drawing.Image)(resources.GetObject("Home_Page.Image")));
            this.Home_Page.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Home_Page.Location = new System.Drawing.Point(0, 56);
            this.Home_Page.Margin = new System.Windows.Forms.Padding(2);
            this.Home_Page.Name = "Home_Page";
            this.Home_Page.Size = new System.Drawing.Size(149, 80);
            this.Home_Page.TabIndex = 1;
            this.Home_Page.Text = "Home Page";
            this.Home_Page.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Home_Page.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Home_Page.UseVisualStyleBackColor = false;
            this.Home_Page.Click += new System.EventHandler(this.Home_Page_Click);
            // 
            // FinancePanel
            // 
            this.FinancePanel.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.FinancePanel.Controls.Add(this.FinanceTracker);
            this.FinancePanel.Location = new System.Drawing.Point(0, 0);
            this.FinancePanel.Margin = new System.Windows.Forms.Padding(2);
            this.FinancePanel.Name = "FinancePanel";
            this.FinancePanel.Size = new System.Drawing.Size(149, 60);
            this.FinancePanel.TabIndex = 0;
            this.FinancePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.FinancePanel_Paint);
            // 
            // FinanceTracker
            // 
            this.FinanceTracker.AutoSize = true;
            this.FinanceTracker.Font = new System.Drawing.Font("Times New Roman", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.FinanceTracker.ForeColor = System.Drawing.Color.White;
            this.FinanceTracker.Location = new System.Drawing.Point(8, 11);
            this.FinanceTracker.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FinanceTracker.Name = "FinanceTracker";
            this.FinanceTracker.Size = new System.Drawing.Size(143, 22);
            this.FinanceTracker.TabIndex = 0;
            this.FinanceTracker.Text = "Finance Tracker";
            // 
            // HomePage
            // 
            this.HomePage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.HomePage.Controls.Add(this.HomePg);
            this.HomePage.Location = new System.Drawing.Point(151, 0);
            this.HomePage.Margin = new System.Windows.Forms.Padding(2);
            this.HomePage.Name = "HomePage";
            this.HomePage.Size = new System.Drawing.Size(830, 628);
            this.HomePage.TabIndex = 2;
            // 
            // HomePg
            // 
            this.HomePg.AutoSize = true;
            this.HomePg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.HomePg.ForeColor = System.Drawing.Color.White;
            this.HomePg.Location = new System.Drawing.Point(225, 7);
            this.HomePg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HomePg.Name = "HomePg";
            this.HomePg.Size = new System.Drawing.Size(355, 34);
            this.HomePg.TabIndex = 18;
            this.HomePg.Text = "Welcome to the Home Page";
            // 
            // Graph_Page
            // 
            this.Graph_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Graph_Page.Controls.Add(this.Graphpg);
            this.Graph_Page.Location = new System.Drawing.Point(152, 0);
            this.Graph_Page.Margin = new System.Windows.Forms.Padding(2);
            this.Graph_Page.Name = "Graph_Page";
            this.Graph_Page.Size = new System.Drawing.Size(830, 628);
            this.Graph_Page.TabIndex = 36;
            this.Graph_Page.Paint += new System.Windows.Forms.PaintEventHandler(this.Graph_Page_Paint);
            // 
            // Graphpg
            // 
            this.Graphpg.AutoSize = true;
            this.Graphpg.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Graphpg.ForeColor = System.Drawing.Color.White;
            this.Graphpg.Location = new System.Drawing.Point(275, 7);
            this.Graphpg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Graphpg.Name = "Graphpg";
            this.Graphpg.Size = new System.Drawing.Size(165, 34);
            this.Graphpg.TabIndex = 18;
            this.Graphpg.Text = "Graph Page";
            // 
            // Data
            // 
            this.Data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Data.Controls.Add(this.itemPartPanel);
            this.Data.Controls.Add(this.itemInfoPanel);
            this.Data.Controls.Add(this.profitSalesPanel);
            this.Data.Controls.Add(this.profitSalesBttn);
            this.Data.Controls.Add(this.itemPartsBttn);
            this.Data.Controls.Add(this.itemInfoBttn);
            this.Data.Controls.Add(this.Data_Search);
            this.Data.Location = new System.Drawing.Point(150, 0);
            this.Data.Margin = new System.Windows.Forms.Padding(2);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(830, 628);
            this.Data.TabIndex = 37;
            this.Data.Paint += new System.Windows.Forms.PaintEventHandler(this.Data_Paint);
            // 
            // itemPartPanel
            // 
            this.itemPartPanel.Controls.Add(this.itemSearchLbl);
            this.itemPartPanel.Controls.Add(this.richTextBox2);
            this.itemPartPanel.Controls.Add(this.dataGridView2);
            this.itemPartPanel.Location = new System.Drawing.Point(35, 123);
            this.itemPartPanel.Name = "itemPartPanel";
            this.itemPartPanel.Size = new System.Drawing.Size(752, 470);
            this.itemPartPanel.TabIndex = 30;
            this.itemPartPanel.Visible = false;
            // 
            // itemSearchLbl
            // 
            this.itemSearchLbl.AutoSize = true;
            this.itemSearchLbl.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemSearchLbl.ForeColor = System.Drawing.Color.White;
            this.itemSearchLbl.Location = new System.Drawing.Point(433, 1);
            this.itemSearchLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.itemSearchLbl.Name = "itemSearchLbl";
            this.itemSearchLbl.Size = new System.Drawing.Size(83, 25);
            this.itemSearchLbl.TabIndex = 26;
            this.itemSearchLbl.Text = "Search:";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(520, 4);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(229, 22);
            this.richTextBox2.TabIndex = 25;
            this.richTextBox2.Text = "";
            this.richTextBox2.TextChanged += new System.EventHandler(this.richTextBox2_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.partIdDataGridViewTextBoxColumn,
            this.itemIdDataGridViewTextBoxColumn,
            this.itemNameDataGridViewTextBoxColumn,
            this.partNameDataGridViewTextBoxColumn,
            this.partCostDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.itempartBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(0, 39);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(749, 454);
            this.dataGridView2.TabIndex = 0;
            // 
            // partIdDataGridViewTextBoxColumn
            // 
            this.partIdDataGridViewTextBoxColumn.DataPropertyName = "partId";
            this.partIdDataGridViewTextBoxColumn.HeaderText = "Part ID";
            this.partIdDataGridViewTextBoxColumn.Name = "partIdDataGridViewTextBoxColumn";
            this.partIdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itemIdDataGridViewTextBoxColumn
            // 
            this.itemIdDataGridViewTextBoxColumn.DataPropertyName = "itemId";
            this.itemIdDataGridViewTextBoxColumn.HeaderText = "Item ID";
            this.itemIdDataGridViewTextBoxColumn.Name = "itemIdDataGridViewTextBoxColumn";
            this.itemIdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itemNameDataGridViewTextBoxColumn
            // 
            this.itemNameDataGridViewTextBoxColumn.DataPropertyName = "itemName";
            this.itemNameDataGridViewTextBoxColumn.HeaderText = "Name of Item";
            this.itemNameDataGridViewTextBoxColumn.Name = "itemNameDataGridViewTextBoxColumn";
            this.itemNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // partNameDataGridViewTextBoxColumn
            // 
            this.partNameDataGridViewTextBoxColumn.DataPropertyName = "partName";
            this.partNameDataGridViewTextBoxColumn.HeaderText = "Name of Part";
            this.partNameDataGridViewTextBoxColumn.Name = "partNameDataGridViewTextBoxColumn";
            this.partNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // partCostDataGridViewTextBoxColumn
            // 
            this.partCostDataGridViewTextBoxColumn.DataPropertyName = "partCost";
            this.partCostDataGridViewTextBoxColumn.HeaderText = "Cost of Part";
            this.partCostDataGridViewTextBoxColumn.Name = "partCostDataGridViewTextBoxColumn";
            this.partCostDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itempartBindingSource
            // 
            this.itempartBindingSource.DataMember = "itempart";
            this.itempartBindingSource.DataSource = this.finance_trackerDataSet1;
            // 
            // finance_trackerDataSet1
            // 
            this.finance_trackerDataSet1.DataSetName = "finance_trackerDataSet1";
            this.finance_trackerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemInfoPanel
            // 
            this.itemInfoPanel.Controls.Add(this.dataGridView1);
            this.itemInfoPanel.Controls.Add(this.richTextBox1);
            this.itemInfoPanel.Controls.Add(this.Searchlabel);
            this.itemInfoPanel.Location = new System.Drawing.Point(36, 124);
            this.itemInfoPanel.Name = "itemInfoPanel";
            this.itemInfoPanel.Size = new System.Drawing.Size(751, 468);
            this.itemInfoPanel.TabIndex = 29;
            this.itemInfoPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.itemInfoPanel_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.costToMakeDataGridViewTextBoxColumn,
            this.sellingPriceDataGridViewTextBoxColumn,
            this.amountSoldDataGridViewTextBoxColumn,
            this.amountMadeDataGridViewTextBoxColumn,
            this.monthDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.itemBindingSource;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(3, 43);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(748, 452);
            this.dataGridView1.TabIndex = 19;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Item Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // costToMakeDataGridViewTextBoxColumn
            // 
            this.costToMakeDataGridViewTextBoxColumn.DataPropertyName = "costToMake";
            this.costToMakeDataGridViewTextBoxColumn.HeaderText = "Cost to Make";
            this.costToMakeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.costToMakeDataGridViewTextBoxColumn.Name = "costToMakeDataGridViewTextBoxColumn";
            this.costToMakeDataGridViewTextBoxColumn.ReadOnly = true;
            this.costToMakeDataGridViewTextBoxColumn.Width = 125;
            // 
            // sellingPriceDataGridViewTextBoxColumn
            // 
            this.sellingPriceDataGridViewTextBoxColumn.DataPropertyName = "sellingPrice";
            this.sellingPriceDataGridViewTextBoxColumn.HeaderText = "Selling Price";
            this.sellingPriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sellingPriceDataGridViewTextBoxColumn.Name = "sellingPriceDataGridViewTextBoxColumn";
            this.sellingPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.sellingPriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountSoldDataGridViewTextBoxColumn
            // 
            this.amountSoldDataGridViewTextBoxColumn.DataPropertyName = "AmountSold";
            this.amountSoldDataGridViewTextBoxColumn.HeaderText = "Amount Sold";
            this.amountSoldDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountSoldDataGridViewTextBoxColumn.Name = "amountSoldDataGridViewTextBoxColumn";
            this.amountSoldDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountSoldDataGridViewTextBoxColumn.Width = 125;
            // 
            // amountMadeDataGridViewTextBoxColumn
            // 
            this.amountMadeDataGridViewTextBoxColumn.DataPropertyName = "AmountMade";
            this.amountMadeDataGridViewTextBoxColumn.HeaderText = "Amount Made";
            this.amountMadeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amountMadeDataGridViewTextBoxColumn.Name = "amountMadeDataGridViewTextBoxColumn";
            this.amountMadeDataGridViewTextBoxColumn.ReadOnly = true;
            this.amountMadeDataGridViewTextBoxColumn.Width = 125;
            // 
            // monthDataGridViewTextBoxColumn
            // 
            this.monthDataGridViewTextBoxColumn.DataPropertyName = "Month";
            this.monthDataGridViewTextBoxColumn.HeaderText = "Month";
            this.monthDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.monthDataGridViewTextBoxColumn.Name = "monthDataGridViewTextBoxColumn";
            this.monthDataGridViewTextBoxColumn.ReadOnly = true;
            this.monthDataGridViewTextBoxColumn.Width = 125;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.ReadOnly = true;
            this.yearDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemBindingSource
            // 
            this.itemBindingSource.DataMember = "item";
            this.itemBindingSource.DataSource = this.finance_trackerDataSet;
            // 
            // finance_trackerDataSet
            // 
            this.finance_trackerDataSet.DataSetName = "finance_trackerDataSet";
            this.finance_trackerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(520, 6);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(229, 22);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Searchlabel
            // 
            this.Searchlabel.AutoSize = true;
            this.Searchlabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchlabel.ForeColor = System.Drawing.Color.White;
            this.Searchlabel.Location = new System.Drawing.Point(433, 3);
            this.Searchlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Searchlabel.Name = "Searchlabel";
            this.Searchlabel.Size = new System.Drawing.Size(83, 25);
            this.Searchlabel.TabIndex = 24;
            this.Searchlabel.Text = "Search:";
            // 
            // profitSalesPanel
            // 
            this.profitSalesPanel.Controls.Add(this.label2);
            this.profitSalesPanel.Location = new System.Drawing.Point(35, 125);
            this.profitSalesPanel.Name = "profitSalesPanel";
            this.profitSalesPanel.Size = new System.Drawing.Size(752, 468);
            this.profitSalesPanel.TabIndex = 31;
            this.profitSalesPanel.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(23, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "profits / sales panel";
            // 
            // profitSalesBttn
            // 
            this.profitSalesBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.profitSalesBttn.FlatAppearance.BorderSize = 0;
            this.profitSalesBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.profitSalesBttn.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profitSalesBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.profitSalesBttn.Location = new System.Drawing.Point(300, 85);
            this.profitSalesBttn.Name = "profitSalesBttn";
            this.profitSalesBttn.Size = new System.Drawing.Size(118, 32);
            this.profitSalesBttn.TabIndex = 28;
            this.profitSalesBttn.Text = "Profits / Sales";
            this.profitSalesBttn.UseVisualStyleBackColor = false;
            this.profitSalesBttn.Click += new System.EventHandler(this.profitSalesBttn_Click);
            // 
            // itemPartsBttn
            // 
            this.itemPartsBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.itemPartsBttn.FlatAppearance.BorderSize = 0;
            this.itemPartsBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.itemPartsBttn.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemPartsBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.itemPartsBttn.Location = new System.Drawing.Point(165, 85);
            this.itemPartsBttn.Name = "itemPartsBttn";
            this.itemPartsBttn.Size = new System.Drawing.Size(121, 32);
            this.itemPartsBttn.TabIndex = 26;
            this.itemPartsBttn.Text = "Item Parts";
            this.itemPartsBttn.UseVisualStyleBackColor = false;
            this.itemPartsBttn.Click += new System.EventHandler(this.itemPartsBttn_Click);
            // 
            // itemInfoBttn
            // 
            this.itemInfoBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.itemInfoBttn.FlatAppearance.BorderSize = 0;
            this.itemInfoBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.itemInfoBttn.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemInfoBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.itemInfoBttn.Location = new System.Drawing.Point(33, 85);
            this.itemInfoBttn.Name = "itemInfoBttn";
            this.itemInfoBttn.Size = new System.Drawing.Size(118, 32);
            this.itemInfoBttn.TabIndex = 25;
            this.itemInfoBttn.Text = "Item Info";
            this.itemInfoBttn.UseVisualStyleBackColor = false;
            this.itemInfoBttn.Click += new System.EventHandler(this.itemInfoBttn_Click);
            // 
            // Data_Search
            // 
            this.Data_Search.AutoSize = true;
            this.Data_Search.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Data_Search.ForeColor = System.Drawing.Color.White;
            this.Data_Search.Location = new System.Drawing.Point(225, 7);
            this.Data_Search.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Data_Search.Name = "Data_Search";
            this.Data_Search.Size = new System.Drawing.Size(340, 34);
            this.Data_Search.TabIndex = 18;
            this.Data_Search.Text = "Welcome to the Data Page";
            // 
            // InputData
            // 
            this.InputData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.InputData.Controls.Add(this.InputPartInfoBttn);
            this.InputData.Controls.Add(this.InputItemInfoBttn);
            this.InputData.Controls.Add(this.partInputPanel);
            this.InputData.Controls.Add(this.itemInputPanel);
            this.InputData.Controls.Add(this.Input_Page);
            this.InputData.Location = new System.Drawing.Point(152, 0);
            this.InputData.Margin = new System.Windows.Forms.Padding(2);
            this.InputData.Name = "InputData";
            this.InputData.Size = new System.Drawing.Size(830, 628);
            this.InputData.TabIndex = 38;
            this.InputData.Paint += new System.Windows.Forms.PaintEventHandler(this.InputData_Paint);
            // 
            // dataAdded
            // 
            this.dataAdded.AutoSize = true;
            this.dataAdded.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataAdded.ForeColor = System.Drawing.Color.White;
            this.dataAdded.Location = new System.Drawing.Point(266, 256);
            this.dataAdded.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.dataAdded.Name = "dataAdded";
            this.dataAdded.Size = new System.Drawing.Size(0, 19);
            this.dataAdded.TabIndex = 43;
            // 
            // ysMark
            // 
            this.ysMark.AutoSize = true;
            this.ysMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ysMark.ForeColor = System.Drawing.Color.Red;
            this.ysMark.Location = new System.Drawing.Point(463, 128);
            this.ysMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ysMark.Name = "ysMark";
            this.ysMark.Size = new System.Drawing.Size(0, 19);
            this.ysMark.TabIndex = 42;
            // 
            // msMark
            // 
            this.msMark.AutoSize = true;
            this.msMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msMark.ForeColor = System.Drawing.Color.Red;
            this.msMark.Location = new System.Drawing.Point(187, 128);
            this.msMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.msMark.Name = "msMark";
            this.msMark.Size = new System.Drawing.Size(0, 19);
            this.msMark.TabIndex = 41;
            // 
            // asMark
            // 
            this.asMark.AutoSize = true;
            this.asMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asMark.ForeColor = System.Drawing.Color.Red;
            this.asMark.Location = new System.Drawing.Point(463, 85);
            this.asMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.asMark.Name = "asMark";
            this.asMark.Size = new System.Drawing.Size(0, 19);
            this.asMark.TabIndex = 40;
            // 
            // amMark
            // 
            this.amMark.AutoSize = true;
            this.amMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amMark.ForeColor = System.Drawing.Color.Red;
            this.amMark.Location = new System.Drawing.Point(187, 85);
            this.amMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.amMark.Name = "amMark";
            this.amMark.Size = new System.Drawing.Size(0, 19);
            this.amMark.TabIndex = 39;
            // 
            // spMark
            // 
            this.spMark.AutoSize = true;
            this.spMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spMark.ForeColor = System.Drawing.Color.Red;
            this.spMark.Location = new System.Drawing.Point(463, 44);
            this.spMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.spMark.Name = "spMark";
            this.spMark.Size = new System.Drawing.Size(0, 19);
            this.spMark.TabIndex = 38;
            // 
            // ictmMark
            // 
            this.ictmMark.AutoSize = true;
            this.ictmMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ictmMark.ForeColor = System.Drawing.Color.Red;
            this.ictmMark.Location = new System.Drawing.Point(187, 44);
            this.ictmMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ictmMark.Name = "ictmMark";
            this.ictmMark.Size = new System.Drawing.Size(0, 19);
            this.ictmMark.TabIndex = 37;
            // 
            // inMark
            // 
            this.inMark.AutoSize = true;
            this.inMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inMark.ForeColor = System.Drawing.Color.Red;
            this.inMark.Location = new System.Drawing.Point(477, 14);
            this.inMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.inMark.Name = "inMark";
            this.inMark.Size = new System.Drawing.Size(0, 19);
            this.inMark.TabIndex = 36;
            // 
            // idMark
            // 
            this.idMark.AutoSize = true;
            this.idMark.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idMark.ForeColor = System.Drawing.Color.Red;
            this.idMark.Location = new System.Drawing.Point(201, 13);
            this.idMark.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.idMark.Name = "idMark";
            this.idMark.Size = new System.Drawing.Size(0, 19);
            this.idMark.TabIndex = 35;
            // 
            // MonthSold
            // 
            this.MonthSold.AutoSize = true;
            this.MonthSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonthSold.ForeColor = System.Drawing.Color.Transparent;
            this.MonthSold.Location = new System.Drawing.Point(88, 146);
            this.MonthSold.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MonthSold.Name = "MonthSold";
            this.MonthSold.Size = new System.Drawing.Size(84, 19);
            this.MonthSold.TabIndex = 34;
            this.MonthSold.Text = "Month Sold:";
            // 
            // YearSold
            // 
            this.YearSold.AutoSize = true;
            this.YearSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YearSold.ForeColor = System.Drawing.Color.Transparent;
            this.YearSold.Location = new System.Drawing.Point(381, 147);
            this.YearSold.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.YearSold.Name = "YearSold";
            this.YearSold.Size = new System.Drawing.Size(72, 19);
            this.YearSold.TabIndex = 33;
            this.YearSold.Text = "Year Sold:";
            // 
            // AmountSold
            // 
            this.AmountSold.AutoSize = true;
            this.AmountSold.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountSold.ForeColor = System.Drawing.Color.Transparent;
            this.AmountSold.Location = new System.Drawing.Point(366, 104);
            this.AmountSold.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.AmountSold.Name = "AmountSold";
            this.AmountSold.Size = new System.Drawing.Size(92, 19);
            this.AmountSold.TabIndex = 32;
            this.AmountSold.Text = "Amount Sold:";
            // 
            // AmountMade
            // 
            this.AmountMade.AutoSize = true;
            this.AmountMade.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmountMade.ForeColor = System.Drawing.Color.Transparent;
            this.AmountMade.Location = new System.Drawing.Point(80, 104);
            this.AmountMade.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.AmountMade.Name = "AmountMade";
            this.AmountMade.Size = new System.Drawing.Size(100, 19);
            this.AmountMade.TabIndex = 31;
            this.AmountMade.Text = "Amount Made:";
            // 
            // SoldPrice
            // 
            this.SoldPrice.AutoSize = true;
            this.SoldPrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoldPrice.ForeColor = System.Drawing.Color.Transparent;
            this.SoldPrice.Location = new System.Drawing.Point(381, 63);
            this.SoldPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.SoldPrice.Name = "SoldPrice";
            this.SoldPrice.Size = new System.Drawing.Size(75, 19);
            this.SoldPrice.TabIndex = 30;
            this.SoldPrice.Text = "Sold Price:";
            // 
            // CostItem
            // 
            this.CostItem.AutoSize = true;
            this.CostItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostItem.ForeColor = System.Drawing.Color.Transparent;
            this.CostItem.Location = new System.Drawing.Point(52, 64);
            this.CostItem.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CostItem.Name = "CostItem";
            this.CostItem.Size = new System.Drawing.Size(125, 19);
            this.CostItem.TabIndex = 29;
            this.CostItem.Text = "Item Cost to make:";
            // 
            // ItemName
            // 
            this.ItemName.AutoSize = true;
            this.ItemName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemName.ForeColor = System.Drawing.Color.Transparent;
            this.ItemName.Location = new System.Drawing.Point(381, 23);
            this.ItemName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ItemName.Name = "ItemName";
            this.ItemName.Size = new System.Drawing.Size(80, 19);
            this.ItemName.TabIndex = 28;
            this.ItemName.Text = "Item Name:";
            // 
            // ItemId
            // 
            this.ItemId.AutoSize = true;
            this.ItemId.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemId.ForeColor = System.Drawing.Color.Transparent;
            this.ItemId.Location = new System.Drawing.Point(116, 22);
            this.ItemId.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ItemId.Name = "ItemId";
            this.ItemId.Size = new System.Drawing.Size(56, 19);
            this.ItemId.TabIndex = 27;
            this.ItemId.Text = "Item Id:";
            // 
            // Amount_Made
            // 
            this.Amount_Made.Location = new System.Drawing.Point(190, 104);
            this.Amount_Made.Margin = new System.Windows.Forms.Padding(2);
            this.Amount_Made.Name = "Amount_Made";
            this.Amount_Made.Size = new System.Drawing.Size(134, 20);
            this.Amount_Made.TabIndex = 5;
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(263, 277);
            this.Input.Margin = new System.Windows.Forms.Padding(2);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(200, 37);
            this.Input.TabIndex = 9;
            this.Input.Text = "Input Data";
            this.Input.UseVisualStyleBackColor = true;
            this.Input.Click += new System.EventHandler(this.Input_Click);
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(462, 147);
            this.Year.Margin = new System.Windows.Forms.Padding(2);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(134, 20);
            this.Year.TabIndex = 8;
            // 
            // Month
            // 
            this.Month.Location = new System.Drawing.Point(190, 147);
            this.Month.Margin = new System.Windows.Forms.Padding(2);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(134, 20);
            this.Month.TabIndex = 7;
            // 
            // Selling_Price
            // 
            this.Selling_Price.Location = new System.Drawing.Point(462, 64);
            this.Selling_Price.Margin = new System.Windows.Forms.Padding(2);
            this.Selling_Price.Name = "Selling_Price";
            this.Selling_Price.Size = new System.Drawing.Size(134, 20);
            this.Selling_Price.TabIndex = 4;
            // 
            // Amount_Sold
            // 
            this.Amount_Sold.Location = new System.Drawing.Point(462, 104);
            this.Amount_Sold.Margin = new System.Windows.Forms.Padding(2);
            this.Amount_Sold.Name = "Amount_Sold";
            this.Amount_Sold.Size = new System.Drawing.Size(134, 20);
            this.Amount_Sold.TabIndex = 6;
            // 
            // Cost
            // 
            this.Cost.Location = new System.Drawing.Point(190, 64);
            this.Cost.Margin = new System.Windows.Forms.Padding(2);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(134, 20);
            this.Cost.TabIndex = 3;
            // 
            // Item_Name
            // 
            this.Item_Name.Location = new System.Drawing.Point(462, 23);
            this.Item_Name.Margin = new System.Windows.Forms.Padding(2);
            this.Item_Name.Name = "Item_Name";
            this.Item_Name.Size = new System.Drawing.Size(134, 20);
            this.Item_Name.TabIndex = 2;
            // 
            // Item_Id
            // 
            this.Item_Id.Location = new System.Drawing.Point(190, 23);
            this.Item_Id.Margin = new System.Windows.Forms.Padding(2);
            this.Item_Id.Name = "Item_Id";
            this.Item_Id.Size = new System.Drawing.Size(134, 20);
            this.Item_Id.TabIndex = 1;
            // 
            // Input_Page
            // 
            this.Input_Page.AutoSize = true;
            this.Input_Page.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Input_Page.ForeColor = System.Drawing.Color.White;
            this.Input_Page.Location = new System.Drawing.Point(352, 37);
            this.Input_Page.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Input_Page.Name = "Input_Page";
            this.Input_Page.Size = new System.Drawing.Size(152, 34);
            this.Input_Page.TabIndex = 17;
            this.Input_Page.Text = "Input Page";
            // 
            // itemTableAdapter
            // 
            this.itemTableAdapter.ClearBeforeFill = true;
            // 
            // Profile_Page
            // 
            this.Profile_Page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.Profile_Page.Controls.Add(this.Profilelab);
            this.Profile_Page.Location = new System.Drawing.Point(152, 0);
            this.Profile_Page.Margin = new System.Windows.Forms.Padding(2);
            this.Profile_Page.Name = "Profile_Page";
            this.Profile_Page.Size = new System.Drawing.Size(830, 628);
            this.Profile_Page.TabIndex = 39;
            // 
            // Profilelab
            // 
            this.Profilelab.AutoSize = true;
            this.Profilelab.Font = new System.Drawing.Font("Times New Roman", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Profilelab.ForeColor = System.Drawing.Color.White;
            this.Profilelab.Location = new System.Drawing.Point(225, 7);
            this.Profilelab.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Profilelab.Name = "Profilelab";
            this.Profilelab.Size = new System.Drawing.Size(383, 34);
            this.Profilelab.TabIndex = 18;
            this.Profilelab.Text = "Welcome to your Profile Page";
            // 
            // itempartTableAdapter
            // 
            this.itempartTableAdapter.ClearBeforeFill = true;
            // 
            // itemInputPanel
            // 
            this.itemInputPanel.Controls.Add(this.Amount_Made);
            this.itemInputPanel.Controls.Add(this.dataAdded);
            this.itemInputPanel.Controls.Add(this.Item_Id);
            this.itemInputPanel.Controls.Add(this.ysMark);
            this.itemInputPanel.Controls.Add(this.Item_Name);
            this.itemInputPanel.Controls.Add(this.msMark);
            this.itemInputPanel.Controls.Add(this.Cost);
            this.itemInputPanel.Controls.Add(this.asMark);
            this.itemInputPanel.Controls.Add(this.Amount_Sold);
            this.itemInputPanel.Controls.Add(this.amMark);
            this.itemInputPanel.Controls.Add(this.Selling_Price);
            this.itemInputPanel.Controls.Add(this.spMark);
            this.itemInputPanel.Controls.Add(this.Month);
            this.itemInputPanel.Controls.Add(this.ictmMark);
            this.itemInputPanel.Controls.Add(this.Year);
            this.itemInputPanel.Controls.Add(this.inMark);
            this.itemInputPanel.Controls.Add(this.Input);
            this.itemInputPanel.Controls.Add(this.idMark);
            this.itemInputPanel.Controls.Add(this.ItemId);
            this.itemInputPanel.Controls.Add(this.MonthSold);
            this.itemInputPanel.Controls.Add(this.ItemName);
            this.itemInputPanel.Controls.Add(this.YearSold);
            this.itemInputPanel.Controls.Add(this.CostItem);
            this.itemInputPanel.Controls.Add(this.AmountSold);
            this.itemInputPanel.Controls.Add(this.SoldPrice);
            this.itemInputPanel.Controls.Add(this.AmountMade);
            this.itemInputPanel.Location = new System.Drawing.Point(65, 135);
            this.itemInputPanel.Name = "itemInputPanel";
            this.itemInputPanel.Size = new System.Drawing.Size(692, 433);
            this.itemInputPanel.TabIndex = 44;
            this.itemInputPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.itemInputPanel_Paint);
            // 
            // partInputPanel
            // 
            this.partInputPanel.Controls.Add(this.partDataAdded);
            this.partInputPanel.Controls.Add(this.inputPartBttn);
            this.partInputPanel.Controls.Add(this.label6);
            this.partInputPanel.Controls.Add(this.label5);
            this.partInputPanel.Controls.Add(this.label4);
            this.partInputPanel.Controls.Add(this.label3);
            this.partInputPanel.Controls.Add(this.label1);
            this.partInputPanel.Controls.Add(this.PartName);
            this.partInputPanel.Controls.Add(this.ItemNameInput);
            this.partInputPanel.Controls.Add(this.PartCost);
            this.partInputPanel.Controls.Add(this.PartId);
            this.partInputPanel.Controls.Add(this.ItemIdInput);
            this.partInputPanel.Location = new System.Drawing.Point(65, 135);
            this.partInputPanel.Name = "partInputPanel";
            this.partInputPanel.Size = new System.Drawing.Size(692, 433);
            this.partInputPanel.TabIndex = 45;
            this.partInputPanel.Visible = false;
            this.partInputPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.partInputPanel_Paint);
            // 
            // InputItemInfoBttn
            // 
            this.InputItemInfoBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.InputItemInfoBttn.FlatAppearance.BorderSize = 0;
            this.InputItemInfoBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InputItemInfoBttn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputItemInfoBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.InputItemInfoBttn.Location = new System.Drawing.Point(65, 100);
            this.InputItemInfoBttn.Name = "InputItemInfoBttn";
            this.InputItemInfoBttn.Size = new System.Drawing.Size(103, 29);
            this.InputItemInfoBttn.TabIndex = 46;
            this.InputItemInfoBttn.Text = "Item Info";
            this.InputItemInfoBttn.UseVisualStyleBackColor = false;
            this.InputItemInfoBttn.Click += new System.EventHandler(this.InputItemInfoBttn_Click);
            // 
            // InputPartInfoBttn
            // 
            this.InputPartInfoBttn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.InputPartInfoBttn.FlatAppearance.BorderSize = 0;
            this.InputPartInfoBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InputPartInfoBttn.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputPartInfoBttn.ForeColor = System.Drawing.Color.Goldenrod;
            this.InputPartInfoBttn.Location = new System.Drawing.Point(172, 100);
            this.InputPartInfoBttn.Name = "InputPartInfoBttn";
            this.InputPartInfoBttn.Size = new System.Drawing.Size(103, 29);
            this.InputPartInfoBttn.TabIndex = 47;
            this.InputPartInfoBttn.Text = "Item Part";
            this.InputPartInfoBttn.UseVisualStyleBackColor = false;
            this.InputPartInfoBttn.Click += new System.EventHandler(this.InputPartInfoBttn_Click);
            // 
            // ItemIdInput
            // 
            this.ItemIdInput.Location = new System.Drawing.Point(190, 29);
            this.ItemIdInput.Name = "ItemIdInput";
            this.ItemIdInput.Size = new System.Drawing.Size(134, 20);
            this.ItemIdInput.TabIndex = 0;
            // 
            // PartId
            // 
            this.PartId.Location = new System.Drawing.Point(190, 67);
            this.PartId.Name = "PartId";
            this.PartId.Size = new System.Drawing.Size(134, 20);
            this.PartId.TabIndex = 1;
            // 
            // PartCost
            // 
            this.PartCost.Location = new System.Drawing.Point(191, 104);
            this.PartCost.Name = "PartCost";
            this.PartCost.Size = new System.Drawing.Size(134, 20);
            this.PartCost.TabIndex = 2;
            // 
            // ItemNameInput
            // 
            this.ItemNameInput.Location = new System.Drawing.Point(462, 28);
            this.ItemNameInput.Name = "ItemNameInput";
            this.ItemNameInput.Size = new System.Drawing.Size(134, 20);
            this.ItemNameInput.TabIndex = 3;
            // 
            // PartName
            // 
            this.PartName.Location = new System.Drawing.Point(462, 67);
            this.PartName.Name = "PartName";
            this.PartName.Size = new System.Drawing.Size(134, 20);
            this.PartName.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(118, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Item Id:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(118, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Part Id:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(86, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "Cost of Part:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(374, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "Item Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(375, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 19);
            this.label6.TabIndex = 9;
            this.label6.Text = "Part Name:";
            // 
            // inputPartBttn
            // 
            this.inputPartBttn.Location = new System.Drawing.Point(263, 277);
            this.inputPartBttn.Margin = new System.Windows.Forms.Padding(2);
            this.inputPartBttn.Name = "inputPartBttn";
            this.inputPartBttn.Size = new System.Drawing.Size(200, 37);
            this.inputPartBttn.TabIndex = 10;
            this.inputPartBttn.Text = "Input Data";
            this.inputPartBttn.UseVisualStyleBackColor = true;
            this.inputPartBttn.Click += new System.EventHandler(this.inputPartBttn_Click);
            // 
            // partDataAdded
            // 
            this.partDataAdded.AutoSize = true;
            this.partDataAdded.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.partDataAdded.ForeColor = System.Drawing.Color.White;
            this.partDataAdded.Location = new System.Drawing.Point(266, 256);
            this.partDataAdded.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.partDataAdded.Name = "partDataAdded";
            this.partDataAdded.Size = new System.Drawing.Size(0, 14);
            this.partDataAdded.TabIndex = 43;
            this.partDataAdded.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(980, 627);
            this.Controls.Add(this.InputData);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.HomePage);
            this.Controls.Add(this.Profile_Page);
            this.Controls.Add(this.Graph_Page);
            this.Controls.Add(this.Side1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Finance Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompleteClosing);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.Enter += new System.EventHandler(this.Form1_Load_1);
            this.Side1.ResumeLayout(false);
            this.FinancePanel.ResumeLayout(false);
            this.FinancePanel.PerformLayout();
            this.HomePage.ResumeLayout(false);
            this.HomePage.PerformLayout();
            this.Graph_Page.ResumeLayout(false);
            this.Graph_Page.PerformLayout();
            this.Data.ResumeLayout(false);
            this.Data.PerformLayout();
            this.itemPartPanel.ResumeLayout(false);
            this.itemPartPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itempartBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet1)).EndInit();
            this.itemInfoPanel.ResumeLayout(false);
            this.itemInfoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finance_trackerDataSet)).EndInit();
            this.profitSalesPanel.ResumeLayout(false);
            this.profitSalesPanel.PerformLayout();
            this.InputData.ResumeLayout(false);
            this.InputData.PerformLayout();
            this.Profile_Page.ResumeLayout(false);
            this.Profile_Page.PerformLayout();
            this.itemInputPanel.ResumeLayout(false);
            this.itemInputPanel.PerformLayout();
            this.partInputPanel.ResumeLayout(false);
            this.partInputPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel Side1;
        private System.Windows.Forms.Panel FinancePanel;
        private System.Windows.Forms.Button Home_Page;
        private System.Windows.Forms.Button DataInput;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Graph;
        private System.Windows.Forms.Label FinanceTracker;
        private System.Windows.Forms.Panel HomePage;
        private System.Windows.Forms.Panel Graph_Page;
        private System.Windows.Forms.Label HomePg;
        private System.Windows.Forms.Label Graphpg;
        private System.Windows.Forms.Button DataPage;
        private System.Windows.Forms.Panel Data;
        private System.Windows.Forms.Label Data_Search;
        private System.Windows.Forms.Label Searchlabel;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel InputData;
        private System.Windows.Forms.Label MonthSold;
        private System.Windows.Forms.Label YearSold;
        private System.Windows.Forms.Label AmountSold;
        private System.Windows.Forms.Label AmountMade;
        private System.Windows.Forms.Label SoldPrice;
        private System.Windows.Forms.Label CostItem;
        private System.Windows.Forms.Label ItemName;
        private System.Windows.Forms.Label ItemId;
        private System.Windows.Forms.TextBox Amount_Made;
        private System.Windows.Forms.Button Input;
        private System.Windows.Forms.TextBox Year;
        private System.Windows.Forms.TextBox Month;
        private System.Windows.Forms.TextBox Selling_Price;
        private System.Windows.Forms.TextBox Amount_Sold;
        private System.Windows.Forms.TextBox Cost;
        private System.Windows.Forms.TextBox Item_Name;
        private System.Windows.Forms.TextBox Item_Id;
        private System.Windows.Forms.Label Input_Page;
        private System.Windows.Forms.Label ictmMark;
        private System.Windows.Forms.Label inMark;
        private System.Windows.Forms.Label idMark;
        private System.Windows.Forms.Label msMark;
        private System.Windows.Forms.Label asMark;
        private System.Windows.Forms.Label amMark;
        private System.Windows.Forms.Label spMark;
        private System.Windows.Forms.Label ysMark;
        private System.Windows.Forms.Label dataAdded;
        private Finance_Tracker_SE.finance_trackerDataSet finance_trackerDataSet;
        private System.Windows.Forms.BindingSource itemBindingSource;
        private Finance_Tracker_SE.finance_trackerDataSetTableAdapters.itemTableAdapter itemTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costToMakeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellingPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountSoldDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountMadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn monthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Profile;
        private System.Windows.Forms.Panel Profile_Page;
        private System.Windows.Forms.Label Profilelab;
        private System.Windows.Forms.Button profitSalesBttn;
        private System.Windows.Forms.Button itemPartsBttn;
        private System.Windows.Forms.Button itemInfoBttn;
        private System.Windows.Forms.Panel itemInfoPanel;
        private System.Windows.Forms.Panel itemPartPanel;
        private System.Windows.Forms.Panel profitSalesPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Finance_Tracker_SE.finance_trackerDataSet1 finance_trackerDataSet1;
        private System.Windows.Forms.BindingSource itempartBindingSource;
        private Finance_Tracker_SE.finance_trackerDataSet1TableAdapters.itempartTableAdapter itempartTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn partIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label itemSearchLbl;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Panel partInputPanel;
        private System.Windows.Forms.Panel itemInputPanel;
        private System.Windows.Forms.Button InputPartInfoBttn;
        private System.Windows.Forms.Button InputItemInfoBttn;
        private System.Windows.Forms.Button inputPartBttn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PartName;
        private System.Windows.Forms.TextBox ItemNameInput;
        private System.Windows.Forms.TextBox PartCost;
        private System.Windows.Forms.TextBox PartId;
        private System.Windows.Forms.TextBox ItemIdInput;
        private System.Windows.Forms.Label partDataAdded;
    }
}

