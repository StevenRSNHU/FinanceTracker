﻿/***

Program:  Finance Tracker

Purpose: To allow Business to keep Track of there Expensices,Sales and profit 

Author:  Tyler Scott, Aaliyah Ortiz, Steven Renfree

Date: October 12,2020

*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Software_Engineering_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();    

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finance_trackerDataSet1.itempart' table. You can move, or remove it, as needed.
            this.itempartTableAdapter.Fill(this.finance_trackerDataSet1.itempart);
            // TODO: This line of code loads data into the 'finance_trackerDataSet.item' table. You can move, or remove it, as needed.
            this.itemTableAdapter.Fill(this.finance_trackerDataSet.item);

            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
 
            
        }

        private void Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Home_Page_Click(object sender, EventArgs e)
        {
            HomePage.Visible = true;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }

        private void DataInput_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = true;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }

        private void DataPage_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = true;
            Profile_Page.Visible = false;
        }

        private void Graph_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = true;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = false;
        }
        private void Profile_Click(object sender, EventArgs e)
        {
            HomePage.Visible = false;
            Graph_Page.Visible = false;
            InputData.Visible = false;
            Data.Visible = false;
            Profile_Page.Visible = true;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void Graph_Page_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void FinancePanel_Paint(object sender, PaintEventArgs e)
        {
            
        }


        private void Item_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Input_Click_1(object sender, EventArgs e)
        {
        }

        private void CompleteClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void InputData_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Input_Click(object sender, EventArgs e)
        {
            //Clears the error labels
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
            spMark.Text = "";
            amMark.Text = "";
            asMark.Text = "";
            msMark.Text = "";
            ysMark.Text = "";
            dataAdded.Text = "";

            //Checks inputs
            if (ItemId.Text.Length <= 0)
            {
                ItemId.Text = "";
                idMark.Text = "* Item ID: Is Required";
            }
            if ((Item_Name.Text.Length >= 31) || (Item_Name.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemName length please input item name with 30 chars or less";
                Item_Name.Text = "";
            }

            if (Cost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost: Is Required";
                Cost.Text = "";
            }

            if (Selling_Price.Text.Length <= 0)
            {
                spMark.Text = "* Selling Price: Is Required";
                Selling_Price.Text = "";
            }

            if (Amount_Sold.Text.Length <= 0)
            {
                asMark.Text = "* Amount Sold: Is Required";
                Amount_Sold.Text = "";
            }

            if (Amount_Made.Text.Length <= 0)
            {
                amMark.Text = "* Amount Made: Is Required";
                Amount_Made.Text = "";
            }

            if (Month.Text.Length <= 0 || Month.Text.Length >= 31 || Convert.ToInt32(Month.Text) >= 13 || Convert.ToInt32(Month.Text) <= 0)
            {
                msMark.Text = "* Month: Input Range between 0 and 30 in length or a number between 1 and 12";
                Cost.Text = "";
            }

            if (Year.Text.Length <= 0)
            {
                ysMark.Text = "* Year: Is Required";
                Selling_Price.Text = "";
            }
            else 
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into item(document,id,name,costToMake,sellingPrice,AmountSold,AmountMade,Month,Year) Values('" +"0" + "','" + Item_Id.Text + "','" + Item_Name.Text + "','" + Convert.ToDouble(Cost.Text) + "','" + Convert.ToDouble(Selling_Price.Text) + "','" + Amount_Sold.Text + "','" + Amount_Made.Text + "','" + Month.Text + "','" + Year.Text + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                dataAdded.Text = "Data has been Inputed";
                con.Close();

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView1.DataSource;
            bs.Filter = "name like '%" + richTextBox1.Text + "%'";
            dataGridView1.DataSource = bs;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Data_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInfoPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInfoBttn_Click(object sender, EventArgs e)
        {
            itemInfoPanel.Visible = true;
            itemPartPanel.Visible = false;
            profitSalesPanel.Visible = false;
        }

        private void itemPartsBttn_Click(object sender, EventArgs e)
        {
            itemInfoPanel.Visible = false;
            itemPartPanel.Visible = true;
            profitSalesPanel.Visible = false;
        }

        private void profitSalesBttn_Click(object sender, EventArgs e)
        {
            itemInfoPanel.Visible = false;
            itemPartPanel.Visible = false;
            profitSalesPanel.Visible = true;
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView2.DataSource;
            bs.Filter = "itemName like '%" + richTextBox2.Text + "%'";
            dataGridView2.DataSource = bs;
        }

        private void partInputPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void itemInputPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void InputItemInfoBttn_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = true;
            partInputPanel.Visible = false;
        }

        private void InputPartInfoBttn_Click(object sender, EventArgs e)
        {
            itemInputPanel.Visible = false;
            partInputPanel.Visible = true;
        }

        private void inputPartBttn_Click(object sender, EventArgs e)
        {
            idMark.Text = "";
            inMark.Text = "";
            ictmMark.Text = "";
            

            if (ItemIdInput.Text.Length <= 0)
            {
                ItemIdInput.Text = "";
                idMark.Text = "* Item Id: Is Required";
            }
            if (PartId.Text.Length <= 0)
            {
                PartId.Text = "";
                idMark.Text = "* Part Id: Is Required";
            }
            if ((ItemNameInput.Text.Length >= 31) || (ItemNameInput.Text.Length <= 0))
            {
                inMark.Text = "* Invalid ItemNameInput length please input item name with 30 chars or less";
                ItemNameInput.Text = "";
            }
            if ((PartName.Text.Length >= 31) || (PartName.Text.Length <= 0))
            {
                inMark.Text = "* Invalid PartName length please input item name with 30 chars or less";
                PartName.Text = "";
            }
            if (PartCost.Text.Length <= 0)
            {
                ictmMark.Text = "* Cost of Part: Is Required";
                PartCost.Text = "";
            }
            else
            {
                MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                MySqlCommand cmd = new MySqlCommand(); //makes cmd
                cmd.Connection = con; // makes command connection to con
                cmd.CommandText = "Insert into itempart(document,partId,itemId,itemName,partName,partCost) Values('" + "0" + "','" + ItemIdInput.Text + "','" + PartId.Text + "','" + ItemNameInput.Text + "','"  + PartName.Text + "','"+ Convert.ToDouble(PartCost.Text) + "')"; // the command
                con.Open();
                cmd.ExecuteNonQuery();
                partDataAdded.Text = "Data has been Inputed";
                con.Close();

            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }

}
