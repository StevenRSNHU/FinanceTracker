﻿namespace Finance_Tracker_SE
{


    partial class finance_trackerDataSet
    {
    }
}
