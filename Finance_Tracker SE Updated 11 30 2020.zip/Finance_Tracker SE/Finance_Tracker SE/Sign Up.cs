﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;


namespace Software_Engineering_Project
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
        }


        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void SignUp_Click(object sender, EventArgs e)
        {
            FnMark.Text = "";
            lnMark.Text = "";
            unMark.Text = "";
            pdMark.Text = "";
            emailMark.Text = "";
            zipMark.Text = "";
            BsMark.Text = "";
            phoneMark.Text = "";
            confirm_Passw.Text = "";

            //Validates The user signup inputs
            if (Email.Text.Contains("@"))
            {
                if (Email.Text.Contains(".com") || Email.Text.Contains(".net") || Email.Text.Contains("yahoo"))
                {
                    MessageBox.Show("Valid Email");
                }
            }
            else
            {
                emailMark.Text = "* Not A valid Email";
            }

            if (First_Name.Text.Length <= 0 || First_Name.Text.Length >= 31)
            {
               FnMark.Text = ("* Invaild Username: input username that is between 1 and 30 in length");
                First_Name.Text = "";
            }

            if (Last_Name.Text.Length <= 0 || Last_Name.Text.Length >= 31)
            {
                lnMark.Text = ("* Invaild Password: input Password that is between 1 and 30 in length");
                Last_Name.Text = "";
            }

            if (Username.Text.Length <= 0 || Username.Text.Length >= 31)
            {
                unMark.Text = ("* Invaild Username: input username that is between 1 and 30 in length");
                Username.Text = "";
            }

            if (Password.Text.Length <= 0 || Password.Text.Length >= 31 || confirm_Passw.Text != Password.Text)
            {
                if (confirm_Passw.Text != Password.Text)
                {
                    pass_Confirm.Text = ("* Passwords Do Not Match");
                    confirm_Passw.Text = "";
                   
                }
                else
                {
                    pdMark.Text = ("* Invaild Password: input Password that is between 1 and 30 in length");
                    Password.Text = "";
                }
            }

            if (Email.Text.Length <= 0 || Email.Text.Length >= 31)
            {
                emailMark.Text = ("* Invaild Email: input Email that is between 1 and 30 in length");
                Email.Text = "";
            }

            if (zipCode.Text.Length != 5)
            {
                zipMark.Text = ("* Invaild Zipcode : input the 5 digit Zipcode");
                zipCode.Text = "";
            }

            if (Business.Text.Length <= 0 || Business.Text.Length >= 31)
            {
                BsMark.Text = ("* Invaild Business: input Business name that is between 1 and 30 in length");
                Business.Text = "";
            }

            if (phoneNumber.Text.Length <= 0 || phoneNumber.Text.Length >= 11)
            {
                phoneMark.Text = ("* Invaild Phone Number: input Phone Number that is between 1 and 10 in length");
                phoneMark.Text = "";
            }

                // If the input requirements are meet 
                if(emailMark.Text == "* Not A valid Email")
                {

                }
            else 
            {
               if (!((First_Name.Text.Length <= 0 || First_Name.Text.Length >= 31) || (Last_Name.Text.Length <= 0 || Last_Name.Text.Length >= 31) || (Username.Text.Length <= 0 || Username.Text.Length >= 31) || (Password.Text.Length <= 0 || Password.Text.Length >= 31 || Password.Text != confirm_Passw.Text) || (Email.Text.Length <= 0 || Email.Text.Length >= 31 ) || (zipCode.Text.Length != 5)) || (Business.Text.Length <= 0 || Business.Text.Length >= 31) || (phoneNumber.Text.Length <= 0 || phoneNumber.Text.Length >= 11))
                {
                    MySqlConnection con = new MySqlConnection("server=localhost;user id=Guess; password = 200109; persistsecurityinfo=True;database=finance_tracker"); // makes con with the connection info
                    MySqlCommand cmd = new MySqlCommand(); //makes cmd
                    cmd.Connection = con; // makes command connection to con
                    cmd.CommandText = "SELECT * FROM userinfo where username='" + Username.Text + "'"; // the camand
                    MySqlDataReader dRead; // to read the data base

                    con.Open();
                    using (dRead = cmd.ExecuteReader()) // executes the search command
                    {
                        if (dRead.Read()) // Checks if username  is taken
                        {
                            unMark.Text = ("* Username has already been taken. ");
                            con.Close();
                            dRead.Close();
                        }
                        else
                        {
                            dRead.Close();
                            cmd.CommandText = "Insert into userinfo(firstName,lastName,username,password,email,zipCode,nameOfBusiness, phoneNumber) Values('" + First_Name.Text + "','" + Last_Name.Text + "','" + Username.Text + "','" + Password.Text + "','" + Email.Text + "','" + Convert.ToInt32(zipCode.Text) + "','" + Business.Text + "','" + phoneNumber.Text + "')"; // the command
                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Account Created");

                            con.Close();

                            Form2 f2 = new Form2(); //Brings them to log in so they can sign in with the new sign in
                            f2.Show();
                            this.Hide();
                        }
                        
                    }
            }
        }

    }

        private void Login_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) // If they already have an account
        {
            Form2 f2 = new Form2();  
            f2.Show();
            this.Hide();
        }

        private void CompleteClose(object sender, FormClosingEventArgs e) // If they close the form
        {
            Application.Exit();
        }

        private void Account_Click(object sender, EventArgs e)
        {

        }

        private void Finance_Tracker_Click(object sender, EventArgs e)
        {

        }
    }    
}
